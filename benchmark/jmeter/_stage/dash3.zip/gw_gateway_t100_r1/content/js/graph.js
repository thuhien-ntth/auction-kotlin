/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 12.0, "minX": 0.0, "maxY": 10961.0, "series": [{"data": [[0.0, 12.0], [0.1, 22.0], [0.2, 26.0], [0.3, 28.0], [0.4, 30.0], [0.5, 31.0], [0.6, 32.0], [0.7, 33.0], [0.8, 34.0], [0.9, 35.0], [1.0, 36.0], [1.1, 36.0], [1.2, 37.0], [1.3, 38.0], [1.4, 38.0], [1.5, 39.0], [1.6, 39.0], [1.7, 40.0], [1.8, 41.0], [1.9, 41.0], [2.0, 42.0], [2.1, 42.0], [2.2, 42.0], [2.3, 43.0], [2.4, 43.0], [2.5, 44.0], [2.6, 44.0], [2.7, 45.0], [2.8, 45.0], [2.9, 45.0], [3.0, 46.0], [3.1, 46.0], [3.2, 46.0], [3.3, 47.0], [3.4, 47.0], [3.5, 48.0], [3.6, 48.0], [3.7, 48.0], [3.8, 48.0], [3.9, 49.0], [4.0, 49.0], [4.1, 49.0], [4.2, 50.0], [4.3, 50.0], [4.4, 50.0], [4.5, 50.0], [4.6, 51.0], [4.7, 51.0], [4.8, 51.0], [4.9, 51.0], [5.0, 52.0], [5.1, 52.0], [5.2, 52.0], [5.3, 52.0], [5.4, 53.0], [5.5, 53.0], [5.6, 53.0], [5.7, 53.0], [5.8, 54.0], [5.9, 54.0], [6.0, 54.0], [6.1, 54.0], [6.2, 54.0], [6.3, 55.0], [6.4, 55.0], [6.5, 55.0], [6.6, 55.0], [6.7, 56.0], [6.8, 56.0], [6.9, 56.0], [7.0, 56.0], [7.1, 56.0], [7.2, 56.0], [7.3, 57.0], [7.4, 57.0], [7.5, 57.0], [7.6, 57.0], [7.7, 57.0], [7.8, 58.0], [7.9, 58.0], [8.0, 58.0], [8.1, 58.0], [8.2, 58.0], [8.3, 59.0], [8.4, 59.0], [8.5, 59.0], [8.6, 59.0], [8.7, 59.0], [8.8, 59.0], [8.9, 60.0], [9.0, 60.0], [9.1, 60.0], [9.2, 60.0], [9.3, 60.0], [9.4, 60.0], [9.5, 61.0], [9.6, 61.0], [9.7, 61.0], [9.8, 61.0], [9.9, 61.0], [10.0, 62.0], [10.1, 62.0], [10.2, 62.0], [10.3, 62.0], [10.4, 62.0], [10.5, 62.0], [10.6, 63.0], [10.7, 63.0], [10.8, 63.0], [10.9, 63.0], [11.0, 63.0], [11.1, 64.0], [11.2, 64.0], [11.3, 64.0], [11.4, 64.0], [11.5, 64.0], [11.6, 64.0], [11.7, 65.0], [11.8, 65.0], [11.9, 65.0], [12.0, 65.0], [12.1, 65.0], [12.2, 65.0], [12.3, 66.0], [12.4, 66.0], [12.5, 66.0], [12.6, 66.0], [12.7, 66.0], [12.8, 66.0], [12.9, 67.0], [13.0, 67.0], [13.1, 67.0], [13.2, 67.0], [13.3, 67.0], [13.4, 67.0], [13.5, 68.0], [13.6, 68.0], [13.7, 68.0], [13.8, 68.0], [13.9, 68.0], [14.0, 68.0], [14.1, 68.0], [14.2, 69.0], [14.3, 69.0], [14.4, 69.0], [14.5, 69.0], [14.6, 69.0], [14.7, 69.0], [14.8, 69.0], [14.9, 70.0], [15.0, 70.0], [15.1, 70.0], [15.2, 70.0], [15.3, 70.0], [15.4, 70.0], [15.5, 70.0], [15.6, 71.0], [15.7, 71.0], [15.8, 71.0], [15.9, 71.0], [16.0, 71.0], [16.1, 71.0], [16.2, 71.0], [16.3, 71.0], [16.4, 72.0], [16.5, 72.0], [16.6, 72.0], [16.7, 72.0], [16.8, 72.0], [16.9, 72.0], [17.0, 72.0], [17.1, 73.0], [17.2, 73.0], [17.3, 73.0], [17.4, 73.0], [17.5, 73.0], [17.6, 73.0], [17.7, 73.0], [17.8, 73.0], [17.9, 74.0], [18.0, 74.0], [18.1, 74.0], [18.2, 74.0], [18.3, 74.0], [18.4, 74.0], [18.5, 74.0], [18.6, 75.0], [18.7, 75.0], [18.8, 75.0], [18.9, 75.0], [19.0, 75.0], [19.1, 75.0], [19.2, 75.0], [19.3, 76.0], [19.4, 76.0], [19.5, 76.0], [19.6, 76.0], [19.7, 76.0], [19.8, 76.0], [19.9, 76.0], [20.0, 77.0], [20.1, 77.0], [20.2, 77.0], [20.3, 77.0], [20.4, 77.0], [20.5, 77.0], [20.6, 77.0], [20.7, 77.0], [20.8, 78.0], [20.9, 78.0], [21.0, 78.0], [21.1, 78.0], [21.2, 78.0], [21.3, 78.0], [21.4, 78.0], [21.5, 78.0], [21.6, 79.0], [21.7, 79.0], [21.8, 79.0], [21.9, 79.0], [22.0, 79.0], [22.1, 79.0], [22.2, 79.0], [22.3, 79.0], [22.4, 80.0], [22.5, 80.0], [22.6, 80.0], [22.7, 80.0], [22.8, 80.0], [22.9, 80.0], [23.0, 80.0], [23.1, 80.0], [23.2, 81.0], [23.3, 81.0], [23.4, 81.0], [23.5, 81.0], [23.6, 81.0], [23.7, 81.0], [23.8, 81.0], [23.9, 81.0], [24.0, 82.0], [24.1, 82.0], [24.2, 82.0], [24.3, 82.0], [24.4, 82.0], [24.5, 82.0], [24.6, 82.0], [24.7, 82.0], [24.8, 83.0], [24.9, 83.0], [25.0, 83.0], [25.1, 83.0], [25.2, 83.0], [25.3, 83.0], [25.4, 83.0], [25.5, 83.0], [25.6, 83.0], [25.7, 84.0], [25.8, 84.0], [25.9, 84.0], [26.0, 84.0], [26.1, 84.0], [26.2, 84.0], [26.3, 84.0], [26.4, 84.0], [26.5, 85.0], [26.6, 85.0], [26.7, 85.0], [26.8, 85.0], [26.9, 85.0], [27.0, 85.0], [27.1, 85.0], [27.2, 85.0], [27.3, 86.0], [27.4, 86.0], [27.5, 86.0], [27.6, 86.0], [27.7, 86.0], [27.8, 86.0], [27.9, 86.0], [28.0, 87.0], [28.1, 87.0], [28.2, 87.0], [28.3, 87.0], [28.4, 87.0], [28.5, 87.0], [28.6, 87.0], [28.7, 87.0], [28.8, 88.0], [28.9, 88.0], [29.0, 88.0], [29.1, 88.0], [29.2, 88.0], [29.3, 88.0], [29.4, 88.0], [29.5, 88.0], [29.6, 88.0], [29.7, 89.0], [29.8, 89.0], [29.9, 89.0], [30.0, 89.0], [30.1, 89.0], [30.2, 89.0], [30.3, 89.0], [30.4, 90.0], [30.5, 90.0], [30.6, 90.0], [30.7, 90.0], [30.8, 90.0], [30.9, 90.0], [31.0, 90.0], [31.1, 91.0], [31.2, 91.0], [31.3, 91.0], [31.4, 91.0], [31.5, 91.0], [31.6, 91.0], [31.7, 91.0], [31.8, 91.0], [31.9, 92.0], [32.0, 92.0], [32.1, 92.0], [32.2, 92.0], [32.3, 92.0], [32.4, 92.0], [32.5, 92.0], [32.6, 92.0], [32.7, 93.0], [32.8, 93.0], [32.9, 93.0], [33.0, 93.0], [33.1, 93.0], [33.2, 93.0], [33.3, 93.0], [33.4, 93.0], [33.5, 94.0], [33.6, 94.0], [33.7, 94.0], [33.8, 94.0], [33.9, 94.0], [34.0, 94.0], [34.1, 94.0], [34.2, 94.0], [34.3, 94.0], [34.4, 95.0], [34.5, 95.0], [34.6, 95.0], [34.7, 95.0], [34.8, 95.0], [34.9, 95.0], [35.0, 95.0], [35.1, 95.0], [35.2, 96.0], [35.3, 96.0], [35.4, 96.0], [35.5, 96.0], [35.6, 96.0], [35.7, 96.0], [35.8, 96.0], [35.9, 96.0], [36.0, 97.0], [36.1, 97.0], [36.2, 97.0], [36.3, 97.0], [36.4, 97.0], [36.5, 97.0], [36.6, 97.0], [36.7, 97.0], [36.8, 97.0], [36.9, 98.0], [37.0, 98.0], [37.1, 98.0], [37.2, 98.0], [37.3, 98.0], [37.4, 98.0], [37.5, 98.0], [37.6, 98.0], [37.7, 99.0], [37.8, 99.0], [37.9, 99.0], [38.0, 99.0], [38.1, 99.0], [38.2, 99.0], [38.3, 99.0], [38.4, 99.0], [38.5, 99.0], [38.6, 100.0], [38.7, 100.0], [38.8, 100.0], [38.9, 100.0], [39.0, 100.0], [39.1, 100.0], [39.2, 100.0], [39.3, 100.0], [39.4, 101.0], [39.5, 101.0], [39.6, 101.0], [39.7, 101.0], [39.8, 101.0], [39.9, 101.0], [40.0, 101.0], [40.1, 101.0], [40.2, 102.0], [40.3, 102.0], [40.4, 102.0], [40.5, 102.0], [40.6, 102.0], [40.7, 102.0], [40.8, 102.0], [40.9, 102.0], [41.0, 103.0], [41.1, 103.0], [41.2, 103.0], [41.3, 103.0], [41.4, 103.0], [41.5, 103.0], [41.6, 103.0], [41.7, 104.0], [41.8, 104.0], [41.9, 104.0], [42.0, 104.0], [42.1, 104.0], [42.2, 104.0], [42.3, 104.0], [42.4, 104.0], [42.5, 105.0], [42.6, 105.0], [42.7, 105.0], [42.8, 105.0], [42.9, 105.0], [43.0, 105.0], [43.1, 105.0], [43.2, 105.0], [43.3, 106.0], [43.4, 106.0], [43.5, 106.0], [43.6, 106.0], [43.7, 106.0], [43.8, 106.0], [43.9, 106.0], [44.0, 106.0], [44.1, 106.0], [44.2, 107.0], [44.3, 107.0], [44.4, 107.0], [44.5, 107.0], [44.6, 107.0], [44.7, 107.0], [44.8, 107.0], [44.9, 107.0], [45.0, 108.0], [45.1, 108.0], [45.2, 108.0], [45.3, 108.0], [45.4, 108.0], [45.5, 108.0], [45.6, 108.0], [45.7, 108.0], [45.8, 109.0], [45.9, 109.0], [46.0, 109.0], [46.1, 109.0], [46.2, 109.0], [46.3, 109.0], [46.4, 109.0], [46.5, 110.0], [46.6, 110.0], [46.7, 110.0], [46.8, 110.0], [46.9, 110.0], [47.0, 110.0], [47.1, 110.0], [47.2, 110.0], [47.3, 111.0], [47.4, 111.0], [47.5, 111.0], [47.6, 111.0], [47.7, 111.0], [47.8, 111.0], [47.9, 111.0], [48.0, 111.0], [48.1, 112.0], [48.2, 112.0], [48.3, 112.0], [48.4, 112.0], [48.5, 112.0], [48.6, 112.0], [48.7, 112.0], [48.8, 113.0], [48.9, 113.0], [49.0, 113.0], [49.1, 113.0], [49.2, 113.0], [49.3, 113.0], [49.4, 113.0], [49.5, 114.0], [49.6, 114.0], [49.7, 114.0], [49.8, 114.0], [49.9, 114.0], [50.0, 114.0], [50.1, 115.0], [50.2, 115.0], [50.3, 115.0], [50.4, 115.0], [50.5, 115.0], [50.6, 115.0], [50.7, 115.0], [50.8, 116.0], [50.9, 116.0], [51.0, 116.0], [51.1, 116.0], [51.2, 116.0], [51.3, 116.0], [51.4, 116.0], [51.5, 117.0], [51.6, 117.0], [51.7, 117.0], [51.8, 117.0], [51.9, 117.0], [52.0, 117.0], [52.1, 118.0], [52.2, 118.0], [52.3, 118.0], [52.4, 118.0], [52.5, 118.0], [52.6, 118.0], [52.7, 118.0], [52.8, 119.0], [52.9, 119.0], [53.0, 119.0], [53.1, 119.0], [53.2, 119.0], [53.3, 119.0], [53.4, 119.0], [53.5, 120.0], [53.6, 120.0], [53.7, 120.0], [53.8, 120.0], [53.9, 120.0], [54.0, 120.0], [54.1, 120.0], [54.2, 121.0], [54.3, 121.0], [54.4, 121.0], [54.5, 121.0], [54.6, 121.0], [54.7, 121.0], [54.8, 121.0], [54.9, 122.0], [55.0, 122.0], [55.1, 122.0], [55.2, 122.0], [55.3, 122.0], [55.4, 122.0], [55.5, 122.0], [55.6, 123.0], [55.7, 123.0], [55.8, 123.0], [55.9, 123.0], [56.0, 123.0], [56.1, 123.0], [56.2, 124.0], [56.3, 124.0], [56.4, 124.0], [56.5, 124.0], [56.6, 124.0], [56.7, 124.0], [56.8, 125.0], [56.9, 125.0], [57.0, 125.0], [57.1, 125.0], [57.2, 125.0], [57.3, 125.0], [57.4, 125.0], [57.5, 126.0], [57.6, 126.0], [57.7, 126.0], [57.8, 126.0], [57.9, 126.0], [58.0, 126.0], [58.1, 127.0], [58.2, 127.0], [58.3, 127.0], [58.4, 127.0], [58.5, 127.0], [58.6, 127.0], [58.7, 128.0], [58.8, 128.0], [58.9, 128.0], [59.0, 128.0], [59.1, 128.0], [59.2, 128.0], [59.3, 129.0], [59.4, 129.0], [59.5, 129.0], [59.6, 129.0], [59.7, 129.0], [59.8, 129.0], [59.9, 130.0], [60.0, 130.0], [60.1, 130.0], [60.2, 130.0], [60.3, 130.0], [60.4, 130.0], [60.5, 131.0], [60.6, 131.0], [60.7, 131.0], [60.8, 131.0], [60.9, 131.0], [61.0, 132.0], [61.1, 132.0], [61.2, 132.0], [61.3, 132.0], [61.4, 132.0], [61.5, 133.0], [61.6, 133.0], [61.7, 133.0], [61.8, 133.0], [61.9, 133.0], [62.0, 133.0], [62.1, 134.0], [62.2, 134.0], [62.3, 134.0], [62.4, 134.0], [62.5, 134.0], [62.6, 134.0], [62.7, 135.0], [62.8, 135.0], [62.9, 135.0], [63.0, 135.0], [63.1, 135.0], [63.2, 135.0], [63.3, 136.0], [63.4, 136.0], [63.5, 136.0], [63.6, 136.0], [63.7, 136.0], [63.8, 137.0], [63.9, 137.0], [64.0, 137.0], [64.1, 137.0], [64.2, 137.0], [64.3, 137.0], [64.4, 138.0], [64.5, 138.0], [64.6, 138.0], [64.7, 138.0], [64.8, 138.0], [64.9, 139.0], [65.0, 139.0], [65.1, 139.0], [65.2, 139.0], [65.3, 139.0], [65.4, 139.0], [65.5, 140.0], [65.6, 140.0], [65.7, 140.0], [65.8, 140.0], [65.9, 140.0], [66.0, 141.0], [66.1, 141.0], [66.2, 141.0], [66.3, 141.0], [66.4, 141.0], [66.5, 142.0], [66.6, 142.0], [66.7, 142.0], [66.8, 142.0], [66.9, 142.0], [67.0, 142.0], [67.1, 143.0], [67.2, 143.0], [67.3, 143.0], [67.4, 143.0], [67.5, 143.0], [67.6, 143.0], [67.7, 144.0], [67.8, 144.0], [67.9, 144.0], [68.0, 144.0], [68.1, 144.0], [68.2, 145.0], [68.3, 145.0], [68.4, 145.0], [68.5, 145.0], [68.6, 145.0], [68.7, 146.0], [68.8, 146.0], [68.9, 146.0], [69.0, 146.0], [69.1, 146.0], [69.2, 147.0], [69.3, 147.0], [69.4, 147.0], [69.5, 147.0], [69.6, 147.0], [69.7, 148.0], [69.8, 148.0], [69.9, 148.0], [70.0, 148.0], [70.1, 148.0], [70.2, 149.0], [70.3, 149.0], [70.4, 149.0], [70.5, 149.0], [70.6, 149.0], [70.7, 150.0], [70.8, 150.0], [70.9, 150.0], [71.0, 150.0], [71.1, 151.0], [71.2, 151.0], [71.3, 151.0], [71.4, 151.0], [71.5, 151.0], [71.6, 152.0], [71.7, 152.0], [71.8, 152.0], [71.9, 152.0], [72.0, 152.0], [72.1, 153.0], [72.2, 153.0], [72.3, 153.0], [72.4, 153.0], [72.5, 154.0], [72.6, 154.0], [72.7, 154.0], [72.8, 154.0], [72.9, 155.0], [73.0, 155.0], [73.1, 155.0], [73.2, 155.0], [73.3, 156.0], [73.4, 156.0], [73.5, 156.0], [73.6, 156.0], [73.7, 157.0], [73.8, 157.0], [73.9, 157.0], [74.0, 157.0], [74.1, 157.0], [74.2, 158.0], [74.3, 158.0], [74.4, 158.0], [74.5, 158.0], [74.6, 159.0], [74.7, 159.0], [74.8, 159.0], [74.9, 159.0], [75.0, 160.0], [75.1, 160.0], [75.2, 160.0], [75.3, 160.0], [75.4, 161.0], [75.5, 161.0], [75.6, 161.0], [75.7, 161.0], [75.8, 162.0], [75.9, 162.0], [76.0, 162.0], [76.1, 162.0], [76.2, 163.0], [76.3, 163.0], [76.4, 163.0], [76.5, 163.0], [76.6, 164.0], [76.7, 164.0], [76.8, 164.0], [76.9, 165.0], [77.0, 165.0], [77.1, 165.0], [77.2, 165.0], [77.3, 166.0], [77.4, 166.0], [77.5, 166.0], [77.6, 167.0], [77.7, 167.0], [77.8, 167.0], [77.9, 167.0], [78.0, 168.0], [78.1, 168.0], [78.2, 168.0], [78.3, 169.0], [78.4, 169.0], [78.5, 169.0], [78.6, 170.0], [78.7, 170.0], [78.8, 170.0], [78.9, 170.0], [79.0, 171.0], [79.1, 171.0], [79.2, 171.0], [79.3, 171.0], [79.4, 172.0], [79.5, 172.0], [79.6, 172.0], [79.7, 173.0], [79.8, 173.0], [79.9, 173.0], [80.0, 174.0], [80.1, 174.0], [80.2, 174.0], [80.3, 175.0], [80.4, 175.0], [80.5, 175.0], [80.6, 176.0], [80.7, 176.0], [80.8, 176.0], [80.9, 177.0], [81.0, 177.0], [81.1, 178.0], [81.2, 178.0], [81.3, 178.0], [81.4, 179.0], [81.5, 179.0], [81.6, 179.0], [81.7, 180.0], [81.8, 180.0], [81.9, 181.0], [82.0, 181.0], [82.1, 181.0], [82.2, 182.0], [82.3, 182.0], [82.4, 182.0], [82.5, 183.0], [82.6, 183.0], [82.7, 183.0], [82.8, 184.0], [82.9, 184.0], [83.0, 184.0], [83.1, 185.0], [83.2, 185.0], [83.3, 186.0], [83.4, 186.0], [83.5, 186.0], [83.6, 187.0], [83.7, 187.0], [83.8, 188.0], [83.9, 188.0], [84.0, 188.0], [84.1, 189.0], [84.2, 189.0], [84.3, 190.0], [84.4, 190.0], [84.5, 190.0], [84.6, 191.0], [84.7, 191.0], [84.8, 191.0], [84.9, 192.0], [85.0, 192.0], [85.1, 193.0], [85.2, 193.0], [85.3, 193.0], [85.4, 194.0], [85.5, 194.0], [85.6, 195.0], [85.7, 195.0], [85.8, 196.0], [85.9, 196.0], [86.0, 196.0], [86.1, 197.0], [86.2, 197.0], [86.3, 198.0], [86.4, 198.0], [86.5, 198.0], [86.6, 199.0], [86.7, 199.0], [86.8, 199.0], [86.9, 200.0], [87.0, 200.0], [87.1, 201.0], [87.2, 201.0], [87.3, 202.0], [87.4, 202.0], [87.5, 203.0], [87.6, 203.0], [87.7, 204.0], [87.8, 204.0], [87.9, 205.0], [88.0, 205.0], [88.1, 206.0], [88.2, 206.0], [88.3, 207.0], [88.4, 207.0], [88.5, 208.0], [88.6, 208.0], [88.7, 209.0], [88.8, 209.0], [88.9, 210.0], [89.0, 210.0], [89.1, 211.0], [89.2, 212.0], [89.3, 212.0], [89.4, 212.0], [89.5, 213.0], [89.6, 213.0], [89.7, 214.0], [89.8, 215.0], [89.9, 215.0], [90.0, 216.0], [90.1, 217.0], [90.2, 217.0], [90.3, 218.0], [90.4, 218.0], [90.5, 219.0], [90.6, 219.0], [90.7, 220.0], [90.8, 221.0], [90.9, 221.0], [91.0, 222.0], [91.1, 222.0], [91.2, 223.0], [91.3, 224.0], [91.4, 224.0], [91.5, 225.0], [91.6, 226.0], [91.7, 227.0], [91.8, 227.0], [91.9, 228.0], [92.0, 229.0], [92.1, 230.0], [92.2, 231.0], [92.3, 232.0], [92.4, 232.0], [92.5, 233.0], [92.6, 234.0], [92.7, 235.0], [92.8, 236.0], [92.9, 236.0], [93.0, 237.0], [93.1, 238.0], [93.2, 239.0], [93.3, 240.0], [93.4, 240.0], [93.5, 241.0], [93.6, 242.0], [93.7, 243.0], [93.8, 244.0], [93.9, 245.0], [94.0, 246.0], [94.1, 247.0], [94.2, 248.0], [94.3, 249.0], [94.4, 250.0], [94.5, 252.0], [94.6, 253.0], [94.7, 254.0], [94.8, 255.0], [94.9, 256.0], [95.0, 257.0], [95.1, 258.0], [95.2, 260.0], [95.3, 261.0], [95.4, 262.0], [95.5, 264.0], [95.6, 265.0], [95.7, 266.0], [95.8, 268.0], [95.9, 269.0], [96.0, 271.0], [96.1, 273.0], [96.2, 275.0], [96.3, 277.0], [96.4, 279.0], [96.5, 281.0], [96.6, 282.0], [96.7, 285.0], [96.8, 287.0], [96.9, 289.0], [97.0, 291.0], [97.1, 293.0], [97.2, 296.0], [97.3, 299.0], [97.4, 301.0], [97.5, 305.0], [97.6, 309.0], [97.7, 312.0], [97.8, 316.0], [97.9, 319.0], [98.0, 322.0], [98.1, 324.0], [98.2, 329.0], [98.3, 334.0], [98.4, 338.0], [98.5, 346.0], [98.6, 354.0], [98.7, 364.0], [98.8, 377.0], [98.9, 397.0], [99.0, 410.0], [99.1, 437.0], [99.2, 470.0], [99.3, 604.0], [99.4, 1422.0], [99.5, 1519.0], [99.6, 1610.0], [99.7, 1638.0], [99.8, 10543.0], [99.9, 10636.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 19550.0, "series": [{"data": [[0.0, 15627.0], [600.0, 6.0], [10600.0, 48.0], [10500.0, 31.0], [10400.0, 2.0], [10700.0, 11.0], [700.0, 1.0], [10800.0, 4.0], [10900.0, 4.0], [200.0, 4262.0], [800.0, 1.0], [900.0, 1.0], [1000.0, 1.0], [1100.0, 1.0], [300.0, 647.0], [1200.0, 1.0], [1300.0, 1.0], [1400.0, 66.0], [1500.0, 31.0], [100.0, 19550.0], [400.0, 121.0], [1600.0, 69.0], [1700.0, 6.0], [500.0, 30.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 10900.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 109.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 40208.0, "series": [{"data": [[0.0, 40208.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 109.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 205.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 84.20529489353743, "minX": 1.79110362E12, "maxY": 99.84191520663376, "series": [{"data": [[1.79110362E12, 84.20529489353743], [1.79110368E12, 99.84191520663376]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110368E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 40.482758620689665, "minX": 1.0, "maxY": 1395.4074074074067, "series": [{"data": [[4.0, 120.33333333333333], [7.0, 161.0], [8.0, 319.6363636363636], [9.0, 61.46153846153846], [10.0, 54.06666666666668], [11.0, 84.27272727272728], [12.0, 46.78125], [13.0, 40.482758620689665], [14.0, 42.5625], [15.0, 44.92857142857143], [16.0, 71.25806451612902], [17.0, 151.0], [18.0, 137.55555555555554], [19.0, 53.53333333333333], [20.0, 60.925925925925924], [21.0, 59.25999999999999], [22.0, 69.56666666666668], [23.0, 68.43333333333332], [24.0, 67.28947368421055], [25.0, 63.28], [26.0, 50.75510204081632], [27.0, 51.35185185185185], [28.0, 44.39999999999999], [29.0, 69.1578947368421], [30.0, 69.77142857142856], [31.0, 64.82258064516128], [32.0, 60.62222222222223], [33.0, 81.46511627906978], [34.0, 59.06779661016949], [35.0, 59.465517241379295], [36.0, 55.6060606060606], [37.0, 60.23333333333332], [38.0, 64.74999999999999], [39.0, 77.4107142857143], [40.0, 76.28846153846155], [41.0, 74.26], [42.0, 64.84146341463418], [43.0, 49.52941176470588], [44.0, 75.88571428571429], [45.0, 85.94520547945208], [46.0, 77.98412698412702], [47.0, 92.16216216216215], [48.0, 93.6938775510204], [49.0, 96.4230769230769], [50.0, 97.4833333333333], [51.0, 78.66666666666667], [52.0, 142.94444444444443], [53.0, 127.28571428571428], [54.0, 112.23255813953489], [55.0, 126.82456140350878], [56.0, 105.2727272727273], [57.0, 113.95744680851062], [58.0, 86.77464788732397], [59.0, 91.87931034482757], [60.0, 122.31034482758619], [61.0, 136.76086956521743], [62.0, 157.48275862068965], [63.0, 103.73684210526315], [64.0, 127.04545454545456], [65.0, 125.55384615384617], [66.0, 114.5], [67.0, 127.57534246575341], [68.0, 105.2608695652174], [69.0, 129.72000000000003], [70.0, 100.55421686746989], [71.0, 81.05882352941178], [72.0, 94.41666666666667], [79.0, 97.18181818181819], [77.0, 94.0], [82.0, 99.6], [85.0, 1395.4074074074067], [86.0, 504.5802469135805], [87.0, 125.5217391304348], [84.0, 94.83333333333333], [88.0, 139.7444444444444], [89.0, 111.44], [90.0, 133.09523809523805], [91.0, 132.97435897435895], [92.0, 134.98214285714278], [93.0, 161.29999999999998], [94.0, 264.6315789473685], [95.0, 301.6521739130434], [96.0, 307.11904761904765], [97.0, 185.7941176470588], [98.0, 224.50877192982452], [99.0, 255.92307692307693], [100.0, 163.01518402824965], [1.0, 174.0]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[95.74618725630486, 160.0378559794689]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 82789.2, "minX": 1.79110362E12, "maxY": 273828.2, "series": [{"data": [[1.79110362E12, 97184.4], [1.79110368E12, 273828.2]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79110362E12, 82789.2], [1.79110368E12, 233282.4]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110368E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 151.39410212926254, "minX": 1.79110362E12, "maxY": 163.10542329811477, "series": [{"data": [[1.79110362E12, 151.39410212926254], [1.79110368E12, 163.10542329811477]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110368E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 150.15762200866746, "minX": 1.79110362E12, "maxY": 161.40467433462598, "series": [{"data": [[1.79110362E12, 150.15762200866746], [1.79110368E12, 161.40467433462598]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110368E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.008358967500334333, "minX": 1.79110362E12, "maxY": 0.05370265686828757, "series": [{"data": [[1.79110362E12, 0.05370265686828757], [1.79110368E12, 0.008358967500334333]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110368E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 12.0, "minX": 1.79110362E12, "maxY": 10961.0, "series": [{"data": [[1.79110362E12, 1532.0], [1.79110368E12, 10961.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79110362E12, 242.0], [1.79110368E12, 192.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79110362E12, 498.40000000000146], [1.79110368E12, 1542.4200000015335]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79110362E12, 290.0], [1.79110368E12, 236.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79110362E12, 16.0], [1.79110368E12, 12.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79110362E12, 131.5], [1.79110368E12, 103.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110368E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 48.0, "minX": 61.0, "maxY": 1576.0, "series": [{"data": [[526.0, 79.0], [519.0, 110.0], [537.0, 182.0], [516.0, 169.0], [524.0, 183.0], [557.0, 62.0], [555.0, 173.0], [547.0, 176.0], [564.0, 175.0], [554.0, 163.5], [544.0, 128.0], [585.0, 178.0], [618.0, 154.0], [628.0, 152.0], [645.0, 151.0], [646.0, 138.0], [674.0, 141.0], [698.0, 145.0], [672.0, 146.0], [689.0, 144.0], [692.0, 132.0], [706.0, 131.0], [721.0, 131.0], [730.0, 116.0], [750.0, 121.5], [767.0, 121.0], [759.0, 124.0], [740.0, 115.5], [775.0, 127.0], [783.0, 113.0], [779.0, 107.0], [817.0, 113.0], [818.0, 115.0], [845.0, 102.0], [937.0, 97.0], [955.0, 96.0], [941.0, 106.0], [939.0, 98.0], [935.0, 97.0], [960.0, 99.0], [972.0, 92.5], [970.0, 95.5], [1005.0, 91.0], [994.0, 97.0], [1003.0, 93.0], [1053.0, 86.0], [1026.0, 94.0], [1028.0, 94.0], [61.0, 66.0], [108.0, 161.5], [179.0, 1576.0], [209.0, 230.0], [271.0, 48.0], [310.0, 248.0], [312.0, 96.0], [447.0, 58.0], [484.0, 134.5], [491.0, 217.0], [497.0, 111.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1053.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 48.0, "minX": 61.0, "maxY": 1574.0, "series": [{"data": [[526.0, 77.5], [519.0, 109.0], [537.0, 181.0], [516.0, 169.0], [524.0, 182.0], [557.0, 61.0], [555.0, 170.0], [547.0, 175.0], [564.0, 173.5], [554.0, 162.0], [544.0, 128.0], [585.0, 176.0], [618.0, 152.0], [628.0, 150.5], [645.0, 149.0], [646.0, 137.0], [674.0, 140.5], [698.0, 144.0], [672.0, 145.5], [689.0, 144.0], [692.0, 131.0], [706.0, 130.0], [721.0, 130.0], [730.0, 115.0], [750.0, 121.0], [767.0, 120.0], [759.0, 124.0], [740.0, 115.0], [775.0, 127.0], [783.0, 113.0], [779.0, 106.0], [817.0, 112.0], [818.0, 114.0], [845.0, 101.0], [937.0, 97.0], [955.0, 95.0], [941.0, 106.0], [939.0, 97.0], [935.0, 96.0], [960.0, 99.0], [972.0, 91.0], [970.0, 95.0], [1005.0, 90.0], [994.0, 96.5], [1003.0, 93.0], [1053.0, 85.0], [1026.0, 93.0], [1028.0, 93.0], [61.0, 66.0], [108.0, 161.5], [179.0, 1574.0], [209.0, 221.0], [271.0, 48.0], [310.0, 246.5], [312.0, 96.0], [447.0, 58.0], [484.0, 133.0], [491.0, 217.0], [497.0, 110.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1053.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 178.56666666666666, "minX": 1.79110362E12, "maxY": 496.8, "series": [{"data": [[1.79110362E12, 178.56666666666666], [1.79110368E12, 496.8]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110368E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 176.9, "minX": 1.79110362E12, "maxY": 498.46666666666664, "series": [{"data": [[1.79110362E12, 176.9], [1.79110368E12, 498.46666666666664]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110368E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 176.9, "minX": 1.79110362E12, "maxY": 498.46666666666664, "series": [{"data": [[1.79110362E12, 176.9], [1.79110368E12, 498.46666666666664]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110368E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 176.9, "minX": 1.79110362E12, "maxY": 498.46666666666664, "series": [{"data": [[1.79110362E12, 176.9], [1.79110368E12, 498.46666666666664]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110368E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

