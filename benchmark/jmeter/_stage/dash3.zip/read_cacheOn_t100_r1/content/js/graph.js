/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 11.0, "minX": 0.0, "maxY": 1063.0, "series": [{"data": [[0.0, 11.0], [0.1, 18.0], [0.2, 20.0], [0.3, 23.0], [0.4, 25.0], [0.5, 27.0], [0.6, 28.0], [0.7, 30.0], [0.8, 31.0], [0.9, 32.0], [1.0, 33.0], [1.1, 34.0], [1.2, 34.0], [1.3, 35.0], [1.4, 36.0], [1.5, 37.0], [1.6, 38.0], [1.7, 39.0], [1.8, 40.0], [1.9, 40.0], [2.0, 41.0], [2.1, 42.0], [2.2, 42.0], [2.3, 43.0], [2.4, 43.0], [2.5, 44.0], [2.6, 44.0], [2.7, 45.0], [2.8, 45.0], [2.9, 46.0], [3.0, 46.0], [3.1, 47.0], [3.2, 47.0], [3.3, 48.0], [3.4, 48.0], [3.5, 49.0], [3.6, 49.0], [3.7, 49.0], [3.8, 50.0], [3.9, 50.0], [4.0, 50.0], [4.1, 51.0], [4.2, 51.0], [4.3, 51.0], [4.4, 52.0], [4.5, 52.0], [4.6, 52.0], [4.7, 53.0], [4.8, 53.0], [4.9, 53.0], [5.0, 54.0], [5.1, 54.0], [5.2, 54.0], [5.3, 55.0], [5.4, 55.0], [5.5, 55.0], [5.6, 55.0], [5.7, 56.0], [5.8, 56.0], [5.9, 56.0], [6.0, 56.0], [6.1, 57.0], [6.2, 57.0], [6.3, 57.0], [6.4, 58.0], [6.5, 58.0], [6.6, 58.0], [6.7, 58.0], [6.8, 59.0], [6.9, 59.0], [7.0, 59.0], [7.1, 59.0], [7.2, 60.0], [7.3, 60.0], [7.4, 60.0], [7.5, 60.0], [7.6, 60.0], [7.7, 61.0], [7.8, 61.0], [7.9, 61.0], [8.0, 61.0], [8.1, 62.0], [8.2, 62.0], [8.3, 62.0], [8.4, 62.0], [8.5, 63.0], [8.6, 63.0], [8.7, 63.0], [8.8, 63.0], [8.9, 64.0], [9.0, 64.0], [9.1, 64.0], [9.2, 64.0], [9.3, 64.0], [9.4, 65.0], [9.5, 65.0], [9.6, 65.0], [9.7, 65.0], [9.8, 65.0], [9.9, 66.0], [10.0, 66.0], [10.1, 66.0], [10.2, 66.0], [10.3, 66.0], [10.4, 67.0], [10.5, 67.0], [10.6, 67.0], [10.7, 67.0], [10.8, 67.0], [10.9, 68.0], [11.0, 68.0], [11.1, 68.0], [11.2, 68.0], [11.3, 68.0], [11.4, 68.0], [11.5, 69.0], [11.6, 69.0], [11.7, 69.0], [11.8, 69.0], [11.9, 69.0], [12.0, 70.0], [12.1, 70.0], [12.2, 70.0], [12.3, 70.0], [12.4, 70.0], [12.5, 70.0], [12.6, 71.0], [12.7, 71.0], [12.8, 71.0], [12.9, 71.0], [13.0, 71.0], [13.1, 72.0], [13.2, 72.0], [13.3, 72.0], [13.4, 72.0], [13.5, 72.0], [13.6, 72.0], [13.7, 73.0], [13.8, 73.0], [13.9, 73.0], [14.0, 73.0], [14.1, 73.0], [14.2, 74.0], [14.3, 74.0], [14.4, 74.0], [14.5, 74.0], [14.6, 74.0], [14.7, 74.0], [14.8, 74.0], [14.9, 75.0], [15.0, 75.0], [15.1, 75.0], [15.2, 75.0], [15.3, 75.0], [15.4, 75.0], [15.5, 76.0], [15.6, 76.0], [15.7, 76.0], [15.8, 76.0], [15.9, 76.0], [16.0, 76.0], [16.1, 77.0], [16.2, 77.0], [16.3, 77.0], [16.4, 77.0], [16.5, 77.0], [16.6, 77.0], [16.7, 78.0], [16.8, 78.0], [16.9, 78.0], [17.0, 78.0], [17.1, 78.0], [17.2, 78.0], [17.3, 78.0], [17.4, 79.0], [17.5, 79.0], [17.6, 79.0], [17.7, 79.0], [17.8, 79.0], [17.9, 79.0], [18.0, 80.0], [18.1, 80.0], [18.2, 80.0], [18.3, 80.0], [18.4, 80.0], [18.5, 80.0], [18.6, 80.0], [18.7, 81.0], [18.8, 81.0], [18.9, 81.0], [19.0, 81.0], [19.1, 81.0], [19.2, 81.0], [19.3, 81.0], [19.4, 82.0], [19.5, 82.0], [19.6, 82.0], [19.7, 82.0], [19.8, 82.0], [19.9, 82.0], [20.0, 82.0], [20.1, 83.0], [20.2, 83.0], [20.3, 83.0], [20.4, 83.0], [20.5, 83.0], [20.6, 83.0], [20.7, 83.0], [20.8, 84.0], [20.9, 84.0], [21.0, 84.0], [21.1, 84.0], [21.2, 84.0], [21.3, 84.0], [21.4, 84.0], [21.5, 85.0], [21.6, 85.0], [21.7, 85.0], [21.8, 85.0], [21.9, 85.0], [22.0, 85.0], [22.1, 85.0], [22.2, 85.0], [22.3, 86.0], [22.4, 86.0], [22.5, 86.0], [22.6, 86.0], [22.7, 86.0], [22.8, 86.0], [22.9, 86.0], [23.0, 86.0], [23.1, 87.0], [23.2, 87.0], [23.3, 87.0], [23.4, 87.0], [23.5, 87.0], [23.6, 87.0], [23.7, 88.0], [23.8, 88.0], [23.9, 88.0], [24.0, 88.0], [24.1, 88.0], [24.2, 88.0], [24.3, 88.0], [24.4, 89.0], [24.5, 89.0], [24.6, 89.0], [24.7, 89.0], [24.8, 89.0], [24.9, 89.0], [25.0, 89.0], [25.1, 90.0], [25.2, 90.0], [25.3, 90.0], [25.4, 90.0], [25.5, 90.0], [25.6, 90.0], [25.7, 90.0], [25.8, 90.0], [25.9, 91.0], [26.0, 91.0], [26.1, 91.0], [26.2, 91.0], [26.3, 91.0], [26.4, 91.0], [26.5, 92.0], [26.6, 92.0], [26.7, 92.0], [26.8, 92.0], [26.9, 92.0], [27.0, 92.0], [27.1, 92.0], [27.2, 92.0], [27.3, 93.0], [27.4, 93.0], [27.5, 93.0], [27.6, 93.0], [27.7, 93.0], [27.8, 93.0], [27.9, 93.0], [28.0, 93.0], [28.1, 94.0], [28.2, 94.0], [28.3, 94.0], [28.4, 94.0], [28.5, 94.0], [28.6, 94.0], [28.7, 94.0], [28.8, 95.0], [28.9, 95.0], [29.0, 95.0], [29.1, 95.0], [29.2, 95.0], [29.3, 95.0], [29.4, 95.0], [29.5, 96.0], [29.6, 96.0], [29.7, 96.0], [29.8, 96.0], [29.9, 96.0], [30.0, 96.0], [30.1, 96.0], [30.2, 96.0], [30.3, 97.0], [30.4, 97.0], [30.5, 97.0], [30.6, 97.0], [30.7, 97.0], [30.8, 97.0], [30.9, 97.0], [31.0, 97.0], [31.1, 98.0], [31.2, 98.0], [31.3, 98.0], [31.4, 98.0], [31.5, 98.0], [31.6, 98.0], [31.7, 98.0], [31.8, 98.0], [31.9, 99.0], [32.0, 99.0], [32.1, 99.0], [32.2, 99.0], [32.3, 99.0], [32.4, 99.0], [32.5, 99.0], [32.6, 99.0], [32.7, 100.0], [32.8, 100.0], [32.9, 100.0], [33.0, 100.0], [33.1, 100.0], [33.2, 100.0], [33.3, 100.0], [33.4, 100.0], [33.5, 101.0], [33.6, 101.0], [33.7, 101.0], [33.8, 101.0], [33.9, 101.0], [34.0, 101.0], [34.1, 101.0], [34.2, 101.0], [34.3, 102.0], [34.4, 102.0], [34.5, 102.0], [34.6, 102.0], [34.7, 102.0], [34.8, 102.0], [34.9, 102.0], [35.0, 103.0], [35.1, 103.0], [35.2, 103.0], [35.3, 103.0], [35.4, 103.0], [35.5, 103.0], [35.6, 103.0], [35.7, 103.0], [35.8, 104.0], [35.9, 104.0], [36.0, 104.0], [36.1, 104.0], [36.2, 104.0], [36.3, 104.0], [36.4, 104.0], [36.5, 104.0], [36.6, 105.0], [36.7, 105.0], [36.8, 105.0], [36.9, 105.0], [37.0, 105.0], [37.1, 105.0], [37.2, 105.0], [37.3, 105.0], [37.4, 106.0], [37.5, 106.0], [37.6, 106.0], [37.7, 106.0], [37.8, 106.0], [37.9, 106.0], [38.0, 106.0], [38.1, 106.0], [38.2, 107.0], [38.3, 107.0], [38.4, 107.0], [38.5, 107.0], [38.6, 107.0], [38.7, 107.0], [38.8, 107.0], [38.9, 107.0], [39.0, 108.0], [39.1, 108.0], [39.2, 108.0], [39.3, 108.0], [39.4, 108.0], [39.5, 108.0], [39.6, 108.0], [39.7, 108.0], [39.8, 109.0], [39.9, 109.0], [40.0, 109.0], [40.1, 109.0], [40.2, 109.0], [40.3, 109.0], [40.4, 109.0], [40.5, 110.0], [40.6, 110.0], [40.7, 110.0], [40.8, 110.0], [40.9, 110.0], [41.0, 110.0], [41.1, 110.0], [41.2, 111.0], [41.3, 111.0], [41.4, 111.0], [41.5, 111.0], [41.6, 111.0], [41.7, 111.0], [41.8, 111.0], [41.9, 111.0], [42.0, 112.0], [42.1, 112.0], [42.2, 112.0], [42.3, 112.0], [42.4, 112.0], [42.5, 112.0], [42.6, 112.0], [42.7, 113.0], [42.8, 113.0], [42.9, 113.0], [43.0, 113.0], [43.1, 113.0], [43.2, 113.0], [43.3, 113.0], [43.4, 114.0], [43.5, 114.0], [43.6, 114.0], [43.7, 114.0], [43.8, 114.0], [43.9, 114.0], [44.0, 114.0], [44.1, 115.0], [44.2, 115.0], [44.3, 115.0], [44.4, 115.0], [44.5, 115.0], [44.6, 115.0], [44.7, 115.0], [44.8, 115.0], [44.9, 116.0], [45.0, 116.0], [45.1, 116.0], [45.2, 116.0], [45.3, 116.0], [45.4, 116.0], [45.5, 116.0], [45.6, 116.0], [45.7, 117.0], [45.8, 117.0], [45.9, 117.0], [46.0, 117.0], [46.1, 117.0], [46.2, 117.0], [46.3, 117.0], [46.4, 117.0], [46.5, 118.0], [46.6, 118.0], [46.7, 118.0], [46.8, 118.0], [46.9, 118.0], [47.0, 118.0], [47.1, 118.0], [47.2, 119.0], [47.3, 119.0], [47.4, 119.0], [47.5, 119.0], [47.6, 119.0], [47.7, 119.0], [47.8, 119.0], [47.9, 120.0], [48.0, 120.0], [48.1, 120.0], [48.2, 120.0], [48.3, 120.0], [48.4, 120.0], [48.5, 120.0], [48.6, 121.0], [48.7, 121.0], [48.8, 121.0], [48.9, 121.0], [49.0, 121.0], [49.1, 121.0], [49.2, 121.0], [49.3, 122.0], [49.4, 122.0], [49.5, 122.0], [49.6, 122.0], [49.7, 122.0], [49.8, 122.0], [49.9, 122.0], [50.0, 123.0], [50.1, 123.0], [50.2, 123.0], [50.3, 123.0], [50.4, 123.0], [50.5, 123.0], [50.6, 123.0], [50.7, 124.0], [50.8, 124.0], [50.9, 124.0], [51.0, 124.0], [51.1, 124.0], [51.2, 124.0], [51.3, 125.0], [51.4, 125.0], [51.5, 125.0], [51.6, 125.0], [51.7, 125.0], [51.8, 125.0], [51.9, 125.0], [52.0, 125.0], [52.1, 126.0], [52.2, 126.0], [52.3, 126.0], [52.4, 126.0], [52.5, 126.0], [52.6, 126.0], [52.7, 127.0], [52.8, 127.0], [52.9, 127.0], [53.0, 127.0], [53.1, 127.0], [53.2, 127.0], [53.3, 128.0], [53.4, 128.0], [53.5, 128.0], [53.6, 128.0], [53.7, 128.0], [53.8, 128.0], [53.9, 128.0], [54.0, 129.0], [54.1, 129.0], [54.2, 129.0], [54.3, 129.0], [54.4, 129.0], [54.5, 129.0], [54.6, 129.0], [54.7, 130.0], [54.8, 130.0], [54.9, 130.0], [55.0, 130.0], [55.1, 130.0], [55.2, 130.0], [55.3, 130.0], [55.4, 131.0], [55.5, 131.0], [55.6, 131.0], [55.7, 131.0], [55.8, 131.0], [55.9, 131.0], [56.0, 132.0], [56.1, 132.0], [56.2, 132.0], [56.3, 132.0], [56.4, 132.0], [56.5, 132.0], [56.6, 132.0], [56.7, 133.0], [56.8, 133.0], [56.9, 133.0], [57.0, 133.0], [57.1, 133.0], [57.2, 133.0], [57.3, 133.0], [57.4, 134.0], [57.5, 134.0], [57.6, 134.0], [57.7, 134.0], [57.8, 134.0], [57.9, 134.0], [58.0, 135.0], [58.1, 135.0], [58.2, 135.0], [58.3, 135.0], [58.4, 135.0], [58.5, 135.0], [58.6, 135.0], [58.7, 136.0], [58.8, 136.0], [58.9, 136.0], [59.0, 136.0], [59.1, 136.0], [59.2, 137.0], [59.3, 137.0], [59.4, 137.0], [59.5, 137.0], [59.6, 137.0], [59.7, 137.0], [59.8, 137.0], [59.9, 138.0], [60.0, 138.0], [60.1, 138.0], [60.2, 138.0], [60.3, 138.0], [60.4, 138.0], [60.5, 139.0], [60.6, 139.0], [60.7, 139.0], [60.8, 139.0], [60.9, 139.0], [61.0, 139.0], [61.1, 140.0], [61.2, 140.0], [61.3, 140.0], [61.4, 140.0], [61.5, 140.0], [61.6, 141.0], [61.7, 141.0], [61.8, 141.0], [61.9, 141.0], [62.0, 141.0], [62.1, 142.0], [62.2, 142.0], [62.3, 142.0], [62.4, 142.0], [62.5, 142.0], [62.6, 143.0], [62.7, 143.0], [62.8, 143.0], [62.9, 143.0], [63.0, 143.0], [63.1, 143.0], [63.2, 144.0], [63.3, 144.0], [63.4, 144.0], [63.5, 144.0], [63.6, 144.0], [63.7, 145.0], [63.8, 145.0], [63.9, 145.0], [64.0, 145.0], [64.1, 145.0], [64.2, 145.0], [64.3, 146.0], [64.4, 146.0], [64.5, 146.0], [64.6, 146.0], [64.7, 146.0], [64.8, 147.0], [64.9, 147.0], [65.0, 147.0], [65.1, 147.0], [65.2, 147.0], [65.3, 148.0], [65.4, 148.0], [65.5, 148.0], [65.6, 148.0], [65.7, 148.0], [65.8, 149.0], [65.9, 149.0], [66.0, 149.0], [66.1, 149.0], [66.2, 149.0], [66.3, 149.0], [66.4, 150.0], [66.5, 150.0], [66.6, 150.0], [66.7, 150.0], [66.8, 150.0], [66.9, 151.0], [67.0, 151.0], [67.1, 151.0], [67.2, 151.0], [67.3, 151.0], [67.4, 152.0], [67.5, 152.0], [67.6, 152.0], [67.7, 152.0], [67.8, 152.0], [67.9, 153.0], [68.0, 153.0], [68.1, 153.0], [68.2, 153.0], [68.3, 153.0], [68.4, 154.0], [68.5, 154.0], [68.6, 154.0], [68.7, 154.0], [68.8, 154.0], [68.9, 155.0], [69.0, 155.0], [69.1, 155.0], [69.2, 155.0], [69.3, 155.0], [69.4, 156.0], [69.5, 156.0], [69.6, 156.0], [69.7, 156.0], [69.8, 157.0], [69.9, 157.0], [70.0, 157.0], [70.1, 157.0], [70.2, 157.0], [70.3, 158.0], [70.4, 158.0], [70.5, 158.0], [70.6, 158.0], [70.7, 158.0], [70.8, 159.0], [70.9, 159.0], [71.0, 159.0], [71.1, 159.0], [71.2, 160.0], [71.3, 160.0], [71.4, 160.0], [71.5, 160.0], [71.6, 161.0], [71.7, 161.0], [71.8, 161.0], [71.9, 161.0], [72.0, 162.0], [72.1, 162.0], [72.2, 162.0], [72.3, 162.0], [72.4, 163.0], [72.5, 163.0], [72.6, 163.0], [72.7, 163.0], [72.8, 163.0], [72.9, 164.0], [73.0, 164.0], [73.1, 164.0], [73.2, 164.0], [73.3, 165.0], [73.4, 165.0], [73.5, 165.0], [73.6, 165.0], [73.7, 166.0], [73.8, 166.0], [73.9, 166.0], [74.0, 166.0], [74.1, 167.0], [74.2, 167.0], [74.3, 167.0], [74.4, 167.0], [74.5, 168.0], [74.6, 168.0], [74.7, 168.0], [74.8, 168.0], [74.9, 168.0], [75.0, 169.0], [75.1, 169.0], [75.2, 169.0], [75.3, 169.0], [75.4, 170.0], [75.5, 170.0], [75.6, 170.0], [75.7, 170.0], [75.8, 171.0], [75.9, 171.0], [76.0, 171.0], [76.1, 172.0], [76.2, 172.0], [76.3, 172.0], [76.4, 172.0], [76.5, 173.0], [76.6, 173.0], [76.7, 173.0], [76.8, 174.0], [76.9, 174.0], [77.0, 174.0], [77.1, 174.0], [77.2, 175.0], [77.3, 175.0], [77.4, 175.0], [77.5, 176.0], [77.6, 176.0], [77.7, 176.0], [77.8, 177.0], [77.9, 177.0], [78.0, 177.0], [78.1, 177.0], [78.2, 178.0], [78.3, 178.0], [78.4, 178.0], [78.5, 179.0], [78.6, 179.0], [78.7, 179.0], [78.8, 180.0], [78.9, 180.0], [79.0, 180.0], [79.1, 181.0], [79.2, 181.0], [79.3, 181.0], [79.4, 182.0], [79.5, 182.0], [79.6, 182.0], [79.7, 182.0], [79.8, 183.0], [79.9, 183.0], [80.0, 183.0], [80.1, 184.0], [80.2, 184.0], [80.3, 184.0], [80.4, 184.0], [80.5, 185.0], [80.6, 185.0], [80.7, 185.0], [80.8, 186.0], [80.9, 186.0], [81.0, 186.0], [81.1, 187.0], [81.2, 187.0], [81.3, 187.0], [81.4, 188.0], [81.5, 188.0], [81.6, 189.0], [81.7, 189.0], [81.8, 189.0], [81.9, 190.0], [82.0, 190.0], [82.1, 190.0], [82.2, 191.0], [82.3, 191.0], [82.4, 192.0], [82.5, 192.0], [82.6, 192.0], [82.7, 193.0], [82.8, 193.0], [82.9, 193.0], [83.0, 194.0], [83.1, 194.0], [83.2, 195.0], [83.3, 195.0], [83.4, 196.0], [83.5, 196.0], [83.6, 196.0], [83.7, 197.0], [83.8, 197.0], [83.9, 198.0], [84.0, 198.0], [84.1, 198.0], [84.2, 199.0], [84.3, 199.0], [84.4, 200.0], [84.5, 200.0], [84.6, 200.0], [84.7, 201.0], [84.8, 201.0], [84.9, 202.0], [85.0, 202.0], [85.1, 203.0], [85.2, 203.0], [85.3, 203.0], [85.4, 204.0], [85.5, 204.0], [85.6, 205.0], [85.7, 205.0], [85.8, 206.0], [85.9, 207.0], [86.0, 207.0], [86.1, 207.0], [86.2, 208.0], [86.3, 209.0], [86.4, 209.0], [86.5, 210.0], [86.6, 210.0], [86.7, 210.0], [86.8, 211.0], [86.9, 211.0], [87.0, 212.0], [87.1, 212.0], [87.2, 213.0], [87.3, 214.0], [87.4, 214.0], [87.5, 215.0], [87.6, 215.0], [87.7, 216.0], [87.8, 216.0], [87.9, 217.0], [88.0, 218.0], [88.1, 218.0], [88.2, 219.0], [88.3, 219.0], [88.4, 220.0], [88.5, 221.0], [88.6, 221.0], [88.7, 222.0], [88.8, 223.0], [88.9, 223.0], [89.0, 224.0], [89.1, 224.0], [89.2, 225.0], [89.3, 225.0], [89.4, 226.0], [89.5, 227.0], [89.6, 227.0], [89.7, 228.0], [89.8, 229.0], [89.9, 230.0], [90.0, 230.0], [90.1, 231.0], [90.2, 232.0], [90.3, 232.0], [90.4, 233.0], [90.5, 234.0], [90.6, 234.0], [90.7, 235.0], [90.8, 236.0], [90.9, 237.0], [91.0, 237.0], [91.1, 238.0], [91.2, 239.0], [91.3, 240.0], [91.4, 241.0], [91.5, 241.0], [91.6, 242.0], [91.7, 243.0], [91.8, 244.0], [91.9, 245.0], [92.0, 246.0], [92.1, 247.0], [92.2, 248.0], [92.3, 249.0], [92.4, 250.0], [92.5, 251.0], [92.6, 252.0], [92.7, 254.0], [92.8, 255.0], [92.9, 256.0], [93.0, 257.0], [93.1, 258.0], [93.2, 259.0], [93.3, 260.0], [93.4, 261.0], [93.5, 262.0], [93.6, 263.0], [93.7, 264.0], [93.8, 265.0], [93.9, 266.0], [94.0, 267.0], [94.1, 269.0], [94.2, 270.0], [94.3, 270.0], [94.4, 272.0], [94.5, 273.0], [94.6, 275.0], [94.7, 276.0], [94.8, 277.0], [94.9, 279.0], [95.0, 281.0], [95.1, 282.0], [95.2, 284.0], [95.3, 286.0], [95.4, 287.0], [95.5, 289.0], [95.6, 291.0], [95.7, 293.0], [95.8, 294.0], [95.9, 297.0], [96.0, 299.0], [96.1, 300.0], [96.2, 302.0], [96.3, 304.0], [96.4, 307.0], [96.5, 309.0], [96.6, 312.0], [96.7, 314.0], [96.8, 315.0], [96.9, 318.0], [97.0, 320.0], [97.1, 323.0], [97.2, 326.0], [97.3, 329.0], [97.4, 332.0], [97.5, 334.0], [97.6, 337.0], [97.7, 341.0], [97.8, 344.0], [97.9, 346.0], [98.0, 349.0], [98.1, 352.0], [98.2, 357.0], [98.3, 361.0], [98.4, 364.0], [98.5, 370.0], [98.6, 376.0], [98.7, 381.0], [98.8, 387.0], [98.9, 395.0], [99.0, 402.0], [99.1, 408.0], [99.2, 418.0], [99.3, 426.0], [99.4, 437.0], [99.5, 455.0], [99.6, 470.0], [99.7, 498.0], [99.8, 527.0], [99.9, 594.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 25948.0, "series": [{"data": [[0.0, 16401.0], [300.0, 1455.0], [600.0, 26.0], [700.0, 23.0], [100.0, 25948.0], [200.0, 5854.0], [400.0, 379.0], [500.0, 99.0], [1000.0, 1.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 148.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 50038.0, "series": [{"data": [[0.0, 50038.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 148.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 23.33222866611431, "minX": 1.79110002E12, "maxY": 99.49311403943324, "series": [{"data": [[1.79110002E12, 23.33222866611431], [1.79110014E12, 99.49311403943324], [1.79110008E12, 96.54343268133479]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110014E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 24.312499999999996, "minX": 1.0, "maxY": 362.4255319148936, "series": [{"data": [[2.0, 125.0], [3.0, 44.23529411764706], [4.0, 26.928571428571423], [5.0, 24.91666666666667], [6.0, 24.312499999999996], [7.0, 31.24074074074074], [8.0, 28.944444444444443], [9.0, 34.69387755102039], [10.0, 39.20754716981131], [11.0, 42.310344827586206], [12.0, 46.18000000000001], [13.0, 45.77586206896551], [14.0, 39.22222222222223], [15.0, 35.775000000000006], [16.0, 50.00000000000001], [17.0, 45.920634920634896], [18.0, 56.17021276595745], [19.0, 63.682539682539655], [20.0, 74.18032786885244], [21.0, 78.17777777777773], [22.0, 62.449999999999996], [23.0, 66.55223880597015], [24.0, 59.064935064935064], [25.0, 77.77906976744185], [26.0, 57.89010989010989], [27.0, 64.42666666666666], [28.0, 54.58558558558558], [29.0, 68.32584269662924], [30.0, 77.62337662337661], [31.0, 69.14084507042253], [32.0, 76.05319148936171], [33.0, 69.13861386138619], [34.0, 83.31578947368422], [35.0, 127.87719298245617], [36.0, 110.98648648648644], [37.0, 124.875], [38.0, 146.4509803921569], [39.0, 131.35000000000002], [40.0, 120.16901408450705], [41.0, 137.16176470588235], [42.0, 97.14583333333333], [43.0, 109.8955223880597], [44.0, 83.27722772277231], [45.0, 101.73076923076923], [46.0, 124.42682926829274], [47.0, 129.62820512820517], [48.0, 152.54999999999995], [49.0, 185.86567164179098], [50.0, 195.05882352941177], [51.0, 194.38961038961037], [52.0, 144.97058823529412], [53.0, 106.5555555555556], [54.0, 118.97333333333334], [55.0, 150.26506024096386], [56.0, 133.66233766233765], [57.0, 102.52845528455285], [58.0, 108.18018018018023], [59.0, 123.81147540983605], [60.0, 207.11111111111111], [61.0, 171.37804878048777], [62.0, 192.5737704918032], [63.0, 140.63095238095238], [64.0, 150.79646017699116], [65.0, 161.09615384615384], [66.0, 188.79999999999995], [67.0, 342.2], [68.0, 362.4255319148936], [69.0, 254.5084745762712], [70.0, 257.44680851063833], [71.0, 244.28571428571442], [72.0, 161.67307692307693], [73.0, 235.5], [74.0, 210.65517241379317], [75.0, 187.42253521126767], [76.0, 169.7662337662337], [77.0, 130.81578947368425], [78.0, 134.90178571428572], [79.0, 139.83838383838383], [80.0, 167.07142857142858], [81.0, 211.40322580645162], [82.0, 242.91919191919195], [83.0, 160.98333333333338], [84.0, 221.32307692307697], [85.0, 293.8181818181818], [86.0, 281.5263157894736], [87.0, 265.92], [88.0, 309.1228070175438], [89.0, 317.10869565217394], [90.0, 355.68421052631567], [91.0, 111.29999999999998], [92.0, 314.35294117647067], [93.0, 260.98076923076934], [94.0, 287.3055555555556], [95.0, 253.59649122807014], [96.0, 335.33333333333337], [97.0, 192.29752066115705], [98.0, 182.3595505617978], [99.0, 209.7380952380952], [100.0, 138.06315522098777], [1.0, 104.0]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[93.61513171003769, 138.79936635715148]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 18829.2, "minX": 1.79110002E12, "maxY": 348786.85, "series": [{"data": [[1.79110002E12, 22353.7], [1.79110014E12, 93417.95], [1.79110008E12, 348786.85]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79110002E12, 18829.2], [1.79110014E12, 78725.4], [1.79110008E12, 293896.2]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110014E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 66.3989229494616, "minX": 1.79110002E12, "maxY": 149.60121022320254, "series": [{"data": [[1.79110002E12, 66.3989229494616], [1.79110014E12, 115.79054790448838], [1.79110008E12, 149.60121022320254]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110014E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 65.42502071251052, "minX": 1.79110002E12, "maxY": 148.27705087714668, "series": [{"data": [[1.79110002E12, 65.42502071251052], [1.79110014E12, 114.89012186664013], [1.79110008E12, 148.27705087714668]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110014E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.009793253536452648, "minX": 1.79110002E12, "maxY": 0.11474730737365381, "series": [{"data": [[1.79110002E12, 0.11474730737365381], [1.79110014E12, 0.011691271178044183], [1.79110008E12, 0.009793253536452648]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110014E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 11.0, "minX": 1.79110002E12, "maxY": 1063.0, "series": [{"data": [[1.79110002E12, 239.0], [1.79110014E12, 511.0], [1.79110008E12, 1063.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79110002E12, 119.0], [1.79110014E12, 180.0], [1.79110008E12, 203.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79110002E12, 197.0], [1.79110014E12, 273.0599999999995], [1.79110008E12, 350.9800000000032]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79110002E12, 151.25], [1.79110014E12, 207.29999999999927], [1.79110008E12, 240.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79110002E12, 11.0], [1.79110014E12, 15.0], [1.79110008E12, 16.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79110002E12, 57.0], [1.79110014E12, 107.0], [1.79110008E12, 119.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110014E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 22.0, "minX": 84.0, "maxY": 307.5, "series": [{"data": [[548.0, 170.5], [575.0, 158.0], [598.0, 165.5], [577.0, 169.0], [614.0, 150.5], [610.0, 157.0], [638.0, 150.0], [649.0, 149.0], [646.0, 149.5], [670.0, 132.0], [651.0, 140.0], [669.0, 123.0], [690.0, 125.0], [703.0, 126.0], [672.0, 140.5], [686.0, 126.0], [681.0, 133.0], [692.0, 131.0], [675.0, 137.0], [707.0, 134.0], [708.0, 125.0], [745.0, 129.0], [750.0, 115.0], [740.0, 123.0], [739.0, 118.0], [749.0, 126.0], [758.0, 127.5], [773.0, 120.0], [789.0, 110.0], [815.0, 117.0], [828.0, 115.0], [816.0, 119.0], [826.0, 112.0], [813.0, 118.0], [838.0, 112.5], [842.0, 113.0], [861.0, 99.0], [840.0, 113.5], [843.0, 88.0], [876.0, 112.0], [883.0, 105.0], [872.0, 107.0], [894.0, 104.0], [912.0, 113.0], [922.0, 97.0], [916.0, 98.0], [957.0, 100.0], [960.0, 92.5], [963.0, 90.0], [1016.0, 91.0], [84.0, 22.0], [219.0, 272.0], [256.0, 29.0], [284.0, 283.0], [302.0, 53.0], [297.0, 118.0], [293.0, 144.0], [312.0, 38.0], [306.0, 307.5], [329.0, 222.0], [351.0, 64.0], [355.0, 282.0], [369.0, 143.0], [372.0, 198.0], [385.0, 73.0], [414.0, 97.0], [409.0, 122.0], [400.0, 247.5], [427.0, 102.0], [417.0, 235.0], [426.0, 194.0], [445.0, 209.0], [462.0, 116.0], [475.0, 184.0], [511.0, 132.0], [507.0, 184.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1016.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 22.0, "minX": 84.0, "maxY": 306.0, "series": [{"data": [[548.0, 168.0], [575.0, 157.0], [598.0, 164.0], [577.0, 168.0], [614.0, 149.5], [610.0, 157.0], [638.0, 149.0], [649.0, 148.0], [646.0, 149.0], [670.0, 131.0], [651.0, 139.0], [669.0, 121.0], [690.0, 123.0], [703.0, 123.0], [672.0, 139.0], [686.0, 125.0], [681.0, 133.0], [692.0, 130.0], [675.0, 136.0], [707.0, 133.0], [708.0, 124.0], [745.0, 129.0], [750.0, 114.0], [740.0, 122.0], [739.0, 118.0], [749.0, 125.0], [758.0, 126.0], [773.0, 119.0], [789.0, 108.0], [815.0, 117.0], [828.0, 114.0], [816.0, 118.0], [826.0, 111.5], [813.0, 117.0], [838.0, 112.0], [842.0, 111.5], [861.0, 98.0], [840.0, 112.0], [843.0, 87.0], [876.0, 110.0], [883.0, 104.0], [872.0, 106.0], [894.0, 103.0], [912.0, 112.0], [922.0, 96.0], [916.0, 97.0], [957.0, 99.0], [960.0, 91.0], [963.0, 88.0], [1016.0, 90.0], [84.0, 22.0], [219.0, 271.0], [256.0, 28.0], [284.0, 279.0], [302.0, 53.0], [297.0, 117.0], [293.0, 143.0], [312.0, 37.0], [306.0, 306.0], [329.0, 219.0], [351.0, 62.0], [355.0, 280.0], [369.0, 140.0], [372.0, 198.0], [385.0, 73.0], [414.0, 95.5], [409.0, 120.0], [400.0, 239.5], [427.0, 101.0], [417.0, 234.0], [426.0, 193.0], [445.0, 208.0], [462.0, 114.5], [475.0, 183.0], [511.0, 130.0], [507.0, 183.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1016.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 40.916666666666664, "minX": 1.79110002E12, "maxY": 628.9666666666667, "series": [{"data": [[1.79110002E12, 40.916666666666664], [1.79110014E12, 166.55], [1.79110008E12, 628.9666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110014E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 40.233333333333334, "minX": 1.79110002E12, "maxY": 627.9833333333333, "series": [{"data": [[1.79110002E12, 40.233333333333334], [1.79110014E12, 168.21666666666667], [1.79110008E12, 627.9833333333333]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110014E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 40.233333333333334, "minX": 1.79110002E12, "maxY": 627.9833333333333, "series": [{"data": [[1.79110002E12, 40.233333333333334], [1.79110014E12, 168.21666666666667], [1.79110008E12, 627.9833333333333]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110014E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 40.233333333333334, "minX": 1.79110002E12, "maxY": 627.9833333333333, "series": [{"data": [[1.79110002E12, 40.233333333333334], [1.79110014E12, 168.21666666666667], [1.79110008E12, 627.9833333333333]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110014E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

