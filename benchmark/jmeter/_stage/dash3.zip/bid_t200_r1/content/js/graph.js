/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 706.0, "minX": 0.0, "maxY": 1656.0, "series": [{"data": [[0.0, 706.0], [0.1, 706.0], [0.2, 706.0], [0.3, 706.0], [0.4, 706.0], [0.5, 707.0], [0.6, 707.0], [0.7, 707.0], [0.8, 707.0], [0.9, 707.0], [1.0, 708.0], [1.1, 708.0], [1.2, 708.0], [1.3, 708.0], [1.4, 708.0], [1.5, 709.0], [1.6, 709.0], [1.7, 709.0], [1.8, 709.0], [1.9, 709.0], [2.0, 710.0], [2.1, 710.0], [2.2, 710.0], [2.3, 710.0], [2.4, 710.0], [2.5, 710.0], [2.6, 710.0], [2.7, 710.0], [2.8, 710.0], [2.9, 710.0], [3.0, 710.0], [3.1, 710.0], [3.2, 710.0], [3.3, 710.0], [3.4, 710.0], [3.5, 711.0], [3.6, 711.0], [3.7, 711.0], [3.8, 711.0], [3.9, 711.0], [4.0, 712.0], [4.1, 712.0], [4.2, 712.0], [4.3, 712.0], [4.4, 712.0], [4.5, 713.0], [4.6, 713.0], [4.7, 713.0], [4.8, 713.0], [4.9, 713.0], [5.0, 713.0], [5.1, 713.0], [5.2, 713.0], [5.3, 713.0], [5.4, 713.0], [5.5, 713.0], [5.6, 713.0], [5.7, 713.0], [5.8, 713.0], [5.9, 713.0], [6.0, 714.0], [6.1, 714.0], [6.2, 714.0], [6.3, 714.0], [6.4, 714.0], [6.5, 717.0], [6.6, 717.0], [6.7, 717.0], [6.8, 717.0], [6.9, 717.0], [7.0, 718.0], [7.1, 718.0], [7.2, 718.0], [7.3, 718.0], [7.4, 718.0], [7.5, 718.0], [7.6, 718.0], [7.7, 718.0], [7.8, 718.0], [7.9, 718.0], [8.0, 719.0], [8.1, 719.0], [8.2, 719.0], [8.3, 719.0], [8.4, 719.0], [8.5, 720.0], [8.6, 720.0], [8.7, 720.0], [8.8, 720.0], [8.9, 720.0], [9.0, 723.0], [9.1, 723.0], [9.2, 723.0], [9.3, 723.0], [9.4, 723.0], [9.5, 724.0], [9.6, 724.0], [9.7, 724.0], [9.8, 724.0], [9.9, 724.0], [10.0, 727.0], [10.1, 727.0], [10.2, 727.0], [10.3, 727.0], [10.4, 727.0], [10.5, 729.0], [10.6, 729.0], [10.7, 729.0], [10.8, 729.0], [10.9, 729.0], [11.0, 732.0], [11.1, 732.0], [11.2, 732.0], [11.3, 732.0], [11.4, 732.0], [11.5, 732.0], [11.6, 732.0], [11.7, 732.0], [11.8, 732.0], [11.9, 732.0], [12.0, 733.0], [12.1, 733.0], [12.2, 733.0], [12.3, 733.0], [12.4, 733.0], [12.5, 735.0], [12.6, 735.0], [12.7, 735.0], [12.8, 735.0], [12.9, 735.0], [13.0, 737.0], [13.1, 737.0], [13.2, 737.0], [13.3, 737.0], [13.4, 737.0], [13.5, 761.0], [13.6, 761.0], [13.7, 761.0], [13.8, 761.0], [13.9, 761.0], [14.0, 769.0], [14.1, 769.0], [14.2, 769.0], [14.3, 769.0], [14.4, 769.0], [14.5, 770.0], [14.6, 770.0], [14.7, 770.0], [14.8, 770.0], [14.9, 770.0], [15.0, 774.0], [15.1, 774.0], [15.2, 774.0], [15.3, 774.0], [15.4, 774.0], [15.5, 774.0], [15.6, 774.0], [15.7, 774.0], [15.8, 774.0], [15.9, 774.0], [16.0, 791.0], [16.1, 791.0], [16.2, 791.0], [16.3, 791.0], [16.4, 791.0], [16.5, 797.0], [16.6, 797.0], [16.7, 797.0], [16.8, 797.0], [16.9, 797.0], [17.0, 801.0], [17.1, 801.0], [17.2, 801.0], [17.3, 801.0], [17.4, 801.0], [17.5, 805.0], [17.6, 805.0], [17.7, 805.0], [17.8, 805.0], [17.9, 805.0], [18.0, 810.0], [18.1, 810.0], [18.2, 810.0], [18.3, 810.0], [18.4, 810.0], [18.5, 820.0], [18.6, 820.0], [18.7, 820.0], [18.8, 820.0], [18.9, 820.0], [19.0, 820.0], [19.1, 820.0], [19.2, 820.0], [19.3, 820.0], [19.4, 820.0], [19.5, 831.0], [19.6, 831.0], [19.7, 831.0], [19.8, 831.0], [19.9, 831.0], [20.0, 836.0], [20.1, 836.0], [20.2, 836.0], [20.3, 836.0], [20.4, 836.0], [20.5, 840.0], [20.6, 840.0], [20.7, 840.0], [20.8, 840.0], [20.9, 840.0], [21.0, 849.0], [21.1, 849.0], [21.2, 849.0], [21.3, 849.0], [21.4, 849.0], [21.5, 851.0], [21.6, 851.0], [21.7, 851.0], [21.8, 851.0], [21.9, 851.0], [22.0, 861.0], [22.1, 861.0], [22.2, 861.0], [22.3, 861.0], [22.4, 861.0], [22.5, 867.0], [22.6, 867.0], [22.7, 867.0], [22.8, 867.0], [22.9, 867.0], [23.0, 869.0], [23.1, 869.0], [23.2, 869.0], [23.3, 869.0], [23.4, 869.0], [23.5, 880.0], [23.6, 880.0], [23.7, 880.0], [23.8, 880.0], [23.9, 880.0], [24.0, 881.0], [24.1, 881.0], [24.2, 881.0], [24.3, 881.0], [24.4, 881.0], [24.5, 885.0], [24.6, 885.0], [24.7, 885.0], [24.8, 885.0], [24.9, 885.0], [25.0, 886.0], [25.1, 886.0], [25.2, 886.0], [25.3, 886.0], [25.4, 886.0], [25.5, 900.0], [25.6, 900.0], [25.7, 900.0], [25.8, 900.0], [25.9, 900.0], [26.0, 934.0], [26.1, 934.0], [26.2, 934.0], [26.3, 934.0], [26.4, 934.0], [26.5, 940.0], [26.6, 940.0], [26.7, 940.0], [26.8, 940.0], [26.9, 940.0], [27.0, 953.0], [27.1, 953.0], [27.2, 953.0], [27.3, 953.0], [27.4, 953.0], [27.5, 954.0], [27.6, 954.0], [27.7, 954.0], [27.8, 954.0], [27.9, 954.0], [28.0, 957.0], [28.1, 957.0], [28.2, 957.0], [28.3, 957.0], [28.4, 957.0], [28.5, 961.0], [28.6, 961.0], [28.7, 961.0], [28.8, 961.0], [28.9, 961.0], [29.0, 962.0], [29.1, 962.0], [29.2, 962.0], [29.3, 962.0], [29.4, 962.0], [29.5, 962.0], [29.6, 962.0], [29.7, 962.0], [29.8, 962.0], [29.9, 962.0], [30.0, 963.0], [30.1, 963.0], [30.2, 963.0], [30.3, 963.0], [30.4, 963.0], [30.5, 971.0], [30.6, 971.0], [30.7, 971.0], [30.8, 971.0], [30.9, 971.0], [31.0, 979.0], [31.1, 979.0], [31.2, 979.0], [31.3, 979.0], [31.4, 979.0], [31.5, 980.0], [31.6, 980.0], [31.7, 980.0], [31.8, 980.0], [31.9, 980.0], [32.0, 988.0], [32.1, 988.0], [32.2, 988.0], [32.3, 988.0], [32.4, 988.0], [32.5, 994.0], [32.6, 994.0], [32.7, 994.0], [32.8, 994.0], [32.9, 994.0], [33.0, 998.0], [33.1, 998.0], [33.2, 998.0], [33.3, 998.0], [33.4, 998.0], [33.5, 1005.0], [33.6, 1005.0], [33.7, 1005.0], [33.8, 1005.0], [33.9, 1005.0], [34.0, 1013.0], [34.1, 1013.0], [34.2, 1013.0], [34.3, 1013.0], [34.4, 1013.0], [34.5, 1032.0], [34.6, 1032.0], [34.7, 1032.0], [34.8, 1032.0], [34.9, 1032.0], [35.0, 1034.0], [35.1, 1034.0], [35.2, 1034.0], [35.3, 1034.0], [35.4, 1034.0], [35.5, 1034.0], [35.6, 1034.0], [35.7, 1034.0], [35.8, 1034.0], [35.9, 1034.0], [36.0, 1037.0], [36.1, 1037.0], [36.2, 1037.0], [36.3, 1037.0], [36.4, 1037.0], [36.5, 1037.0], [36.6, 1037.0], [36.7, 1037.0], [36.8, 1037.0], [36.9, 1037.0], [37.0, 1038.0], [37.1, 1038.0], [37.2, 1038.0], [37.3, 1038.0], [37.4, 1038.0], [37.5, 1044.0], [37.6, 1044.0], [37.7, 1044.0], [37.8, 1044.0], [37.9, 1044.0], [38.0, 1051.0], [38.1, 1051.0], [38.2, 1051.0], [38.3, 1051.0], [38.4, 1051.0], [38.5, 1057.0], [38.6, 1057.0], [38.7, 1057.0], [38.8, 1057.0], [38.9, 1057.0], [39.0, 1060.0], [39.1, 1060.0], [39.2, 1060.0], [39.3, 1060.0], [39.4, 1060.0], [39.5, 1063.0], [39.6, 1063.0], [39.7, 1063.0], [39.8, 1063.0], [39.9, 1063.0], [40.0, 1063.0], [40.1, 1063.0], [40.2, 1063.0], [40.3, 1063.0], [40.4, 1063.0], [40.5, 1071.0], [40.6, 1071.0], [40.7, 1071.0], [40.8, 1071.0], [40.9, 1071.0], [41.0, 1074.0], [41.1, 1074.0], [41.2, 1074.0], [41.3, 1074.0], [41.4, 1074.0], [41.5, 1086.0], [41.6, 1086.0], [41.7, 1086.0], [41.8, 1086.0], [41.9, 1086.0], [42.0, 1090.0], [42.1, 1090.0], [42.2, 1090.0], [42.3, 1090.0], [42.4, 1090.0], [42.5, 1101.0], [42.6, 1101.0], [42.7, 1101.0], [42.8, 1101.0], [42.9, 1101.0], [43.0, 1107.0], [43.1, 1107.0], [43.2, 1107.0], [43.3, 1107.0], [43.4, 1107.0], [43.5, 1108.0], [43.6, 1108.0], [43.7, 1108.0], [43.8, 1108.0], [43.9, 1108.0], [44.0, 1110.0], [44.1, 1110.0], [44.2, 1110.0], [44.3, 1110.0], [44.4, 1110.0], [44.5, 1114.0], [44.6, 1114.0], [44.7, 1114.0], [44.8, 1114.0], [44.9, 1114.0], [45.0, 1119.0], [45.1, 1119.0], [45.2, 1119.0], [45.3, 1119.0], [45.4, 1119.0], [45.5, 1122.0], [45.6, 1122.0], [45.7, 1122.0], [45.8, 1122.0], [45.9, 1122.0], [46.0, 1125.0], [46.1, 1125.0], [46.2, 1125.0], [46.3, 1125.0], [46.4, 1125.0], [46.5, 1143.0], [46.6, 1143.0], [46.7, 1143.0], [46.8, 1143.0], [46.9, 1143.0], [47.0, 1149.0], [47.1, 1149.0], [47.2, 1149.0], [47.3, 1149.0], [47.4, 1149.0], [47.5, 1161.0], [47.6, 1161.0], [47.7, 1161.0], [47.8, 1161.0], [47.9, 1161.0], [48.0, 1165.0], [48.1, 1165.0], [48.2, 1165.0], [48.3, 1165.0], [48.4, 1165.0], [48.5, 1165.0], [48.6, 1165.0], [48.7, 1165.0], [48.8, 1165.0], [48.9, 1165.0], [49.0, 1169.0], [49.1, 1169.0], [49.2, 1169.0], [49.3, 1169.0], [49.4, 1169.0], [49.5, 1173.0], [49.6, 1173.0], [49.7, 1173.0], [49.8, 1173.0], [49.9, 1173.0], [50.0, 1174.0], [50.1, 1174.0], [50.2, 1174.0], [50.3, 1174.0], [50.4, 1174.0], [50.5, 1182.0], [50.6, 1182.0], [50.7, 1182.0], [50.8, 1182.0], [50.9, 1182.0], [51.0, 1185.0], [51.1, 1185.0], [51.2, 1185.0], [51.3, 1185.0], [51.4, 1185.0], [51.5, 1194.0], [51.6, 1194.0], [51.7, 1194.0], [51.8, 1194.0], [51.9, 1194.0], [52.0, 1195.0], [52.1, 1195.0], [52.2, 1195.0], [52.3, 1195.0], [52.4, 1195.0], [52.5, 1201.0], [52.6, 1201.0], [52.7, 1201.0], [52.8, 1201.0], [52.9, 1201.0], [53.0, 1215.0], [53.1, 1215.0], [53.2, 1215.0], [53.3, 1215.0], [53.4, 1215.0], [53.5, 1219.0], [53.6, 1219.0], [53.7, 1219.0], [53.8, 1219.0], [53.9, 1219.0], [54.0, 1220.0], [54.1, 1220.0], [54.2, 1220.0], [54.3, 1220.0], [54.4, 1220.0], [54.5, 1225.0], [54.6, 1225.0], [54.7, 1225.0], [54.8, 1225.0], [54.9, 1225.0], [55.0, 1233.0], [55.1, 1233.0], [55.2, 1233.0], [55.3, 1233.0], [55.4, 1233.0], [55.5, 1234.0], [55.6, 1234.0], [55.7, 1234.0], [55.8, 1234.0], [55.9, 1234.0], [56.0, 1238.0], [56.1, 1238.0], [56.2, 1238.0], [56.3, 1238.0], [56.4, 1238.0], [56.5, 1245.0], [56.6, 1245.0], [56.7, 1245.0], [56.8, 1245.0], [56.9, 1245.0], [57.0, 1254.0], [57.1, 1254.0], [57.2, 1254.0], [57.3, 1254.0], [57.4, 1254.0], [57.5, 1255.0], [57.6, 1255.0], [57.7, 1255.0], [57.8, 1255.0], [57.9, 1255.0], [58.0, 1258.0], [58.1, 1258.0], [58.2, 1258.0], [58.3, 1258.0], [58.4, 1258.0], [58.5, 1260.0], [58.6, 1260.0], [58.7, 1260.0], [58.8, 1260.0], [58.9, 1260.0], [59.0, 1269.0], [59.1, 1269.0], [59.2, 1269.0], [59.3, 1269.0], [59.4, 1269.0], [59.5, 1270.0], [59.6, 1270.0], [59.7, 1270.0], [59.8, 1270.0], [59.9, 1270.0], [60.0, 1272.0], [60.1, 1272.0], [60.2, 1272.0], [60.3, 1272.0], [60.4, 1272.0], [60.5, 1273.0], [60.6, 1273.0], [60.7, 1273.0], [60.8, 1273.0], [60.9, 1273.0], [61.0, 1294.0], [61.1, 1294.0], [61.2, 1294.0], [61.3, 1294.0], [61.4, 1294.0], [61.5, 1302.0], [61.6, 1302.0], [61.7, 1302.0], [61.8, 1302.0], [61.9, 1302.0], [62.0, 1310.0], [62.1, 1310.0], [62.2, 1310.0], [62.3, 1310.0], [62.4, 1310.0], [62.5, 1312.0], [62.6, 1312.0], [62.7, 1312.0], [62.8, 1312.0], [62.9, 1312.0], [63.0, 1312.0], [63.1, 1312.0], [63.2, 1312.0], [63.3, 1312.0], [63.4, 1312.0], [63.5, 1313.0], [63.6, 1313.0], [63.7, 1313.0], [63.8, 1313.0], [63.9, 1313.0], [64.0, 1315.0], [64.1, 1315.0], [64.2, 1315.0], [64.3, 1315.0], [64.4, 1315.0], [64.5, 1316.0], [64.6, 1316.0], [64.7, 1316.0], [64.8, 1316.0], [64.9, 1316.0], [65.0, 1316.0], [65.1, 1316.0], [65.2, 1316.0], [65.3, 1316.0], [65.4, 1316.0], [65.5, 1324.0], [65.6, 1324.0], [65.7, 1324.0], [65.8, 1324.0], [65.9, 1324.0], [66.0, 1326.0], [66.1, 1326.0], [66.2, 1326.0], [66.3, 1326.0], [66.4, 1326.0], [66.5, 1329.0], [66.6, 1329.0], [66.7, 1329.0], [66.8, 1329.0], [66.9, 1329.0], [67.0, 1333.0], [67.1, 1333.0], [67.2, 1333.0], [67.3, 1333.0], [67.4, 1333.0], [67.5, 1369.0], [67.6, 1369.0], [67.7, 1369.0], [67.8, 1369.0], [67.9, 1369.0], [68.0, 1369.0], [68.1, 1369.0], [68.2, 1369.0], [68.3, 1369.0], [68.4, 1369.0], [68.5, 1370.0], [68.6, 1370.0], [68.7, 1370.0], [68.8, 1370.0], [68.9, 1370.0], [69.0, 1371.0], [69.1, 1371.0], [69.2, 1371.0], [69.3, 1371.0], [69.4, 1371.0], [69.5, 1372.0], [69.6, 1372.0], [69.7, 1372.0], [69.8, 1372.0], [69.9, 1372.0], [70.0, 1375.0], [70.1, 1375.0], [70.2, 1375.0], [70.3, 1375.0], [70.4, 1375.0], [70.5, 1378.0], [70.6, 1378.0], [70.7, 1378.0], [70.8, 1378.0], [70.9, 1378.0], [71.0, 1378.0], [71.1, 1378.0], [71.2, 1378.0], [71.3, 1378.0], [71.4, 1378.0], [71.5, 1379.0], [71.6, 1379.0], [71.7, 1379.0], [71.8, 1379.0], [71.9, 1379.0], [72.0, 1379.0], [72.1, 1379.0], [72.2, 1379.0], [72.3, 1379.0], [72.4, 1379.0], [72.5, 1383.0], [72.6, 1383.0], [72.7, 1383.0], [72.8, 1383.0], [72.9, 1383.0], [73.0, 1386.0], [73.1, 1386.0], [73.2, 1386.0], [73.3, 1386.0], [73.4, 1386.0], [73.5, 1397.0], [73.6, 1397.0], [73.7, 1397.0], [73.8, 1397.0], [73.9, 1397.0], [74.0, 1399.0], [74.1, 1399.0], [74.2, 1399.0], [74.3, 1399.0], [74.4, 1399.0], [74.5, 1402.0], [74.6, 1402.0], [74.7, 1402.0], [74.8, 1402.0], [74.9, 1402.0], [75.0, 1402.0], [75.1, 1402.0], [75.2, 1402.0], [75.3, 1402.0], [75.4, 1402.0], [75.5, 1403.0], [75.6, 1403.0], [75.7, 1403.0], [75.8, 1403.0], [75.9, 1403.0], [76.0, 1404.0], [76.1, 1404.0], [76.2, 1404.0], [76.3, 1404.0], [76.4, 1404.0], [76.5, 1405.0], [76.6, 1405.0], [76.7, 1405.0], [76.8, 1405.0], [76.9, 1405.0], [77.0, 1407.0], [77.1, 1407.0], [77.2, 1407.0], [77.3, 1407.0], [77.4, 1407.0], [77.5, 1408.0], [77.6, 1408.0], [77.7, 1408.0], [77.8, 1408.0], [77.9, 1408.0], [78.0, 1416.0], [78.1, 1416.0], [78.2, 1416.0], [78.3, 1416.0], [78.4, 1416.0], [78.5, 1420.0], [78.6, 1420.0], [78.7, 1420.0], [78.8, 1420.0], [78.9, 1420.0], [79.0, 1430.0], [79.1, 1430.0], [79.2, 1430.0], [79.3, 1430.0], [79.4, 1430.0], [79.5, 1439.0], [79.6, 1439.0], [79.7, 1439.0], [79.8, 1439.0], [79.9, 1439.0], [80.0, 1441.0], [80.1, 1441.0], [80.2, 1441.0], [80.3, 1441.0], [80.4, 1441.0], [80.5, 1442.0], [80.6, 1442.0], [80.7, 1442.0], [80.8, 1442.0], [80.9, 1442.0], [81.0, 1443.0], [81.1, 1443.0], [81.2, 1443.0], [81.3, 1443.0], [81.4, 1443.0], [81.5, 1445.0], [81.6, 1445.0], [81.7, 1445.0], [81.8, 1445.0], [81.9, 1445.0], [82.0, 1446.0], [82.1, 1446.0], [82.2, 1446.0], [82.3, 1446.0], [82.4, 1446.0], [82.5, 1456.0], [82.6, 1456.0], [82.7, 1456.0], [82.8, 1456.0], [82.9, 1456.0], [83.0, 1464.0], [83.1, 1464.0], [83.2, 1464.0], [83.3, 1464.0], [83.4, 1464.0], [83.5, 1475.0], [83.6, 1475.0], [83.7, 1475.0], [83.8, 1475.0], [83.9, 1475.0], [84.0, 1477.0], [84.1, 1477.0], [84.2, 1477.0], [84.3, 1477.0], [84.4, 1477.0], [84.5, 1481.0], [84.6, 1481.0], [84.7, 1481.0], [84.8, 1481.0], [84.9, 1481.0], [85.0, 1491.0], [85.1, 1491.0], [85.2, 1491.0], [85.3, 1491.0], [85.4, 1491.0], [85.5, 1495.0], [85.6, 1495.0], [85.7, 1495.0], [85.8, 1495.0], [85.9, 1495.0], [86.0, 1496.0], [86.1, 1496.0], [86.2, 1496.0], [86.3, 1496.0], [86.4, 1496.0], [86.5, 1497.0], [86.6, 1497.0], [86.7, 1497.0], [86.8, 1497.0], [86.9, 1497.0], [87.0, 1500.0], [87.1, 1500.0], [87.2, 1500.0], [87.3, 1500.0], [87.4, 1500.0], [87.5, 1512.0], [87.6, 1512.0], [87.7, 1512.0], [87.8, 1512.0], [87.9, 1512.0], [88.0, 1513.0], [88.1, 1513.0], [88.2, 1513.0], [88.3, 1513.0], [88.4, 1513.0], [88.5, 1527.0], [88.6, 1527.0], [88.7, 1527.0], [88.8, 1527.0], [88.9, 1527.0], [89.0, 1529.0], [89.1, 1529.0], [89.2, 1529.0], [89.3, 1529.0], [89.4, 1529.0], [89.5, 1529.0], [89.6, 1529.0], [89.7, 1529.0], [89.8, 1529.0], [89.9, 1529.0], [90.0, 1543.0], [90.1, 1543.0], [90.2, 1543.0], [90.3, 1543.0], [90.4, 1543.0], [90.5, 1544.0], [90.6, 1544.0], [90.7, 1544.0], [90.8, 1544.0], [90.9, 1544.0], [91.0, 1545.0], [91.1, 1545.0], [91.2, 1545.0], [91.3, 1545.0], [91.4, 1545.0], [91.5, 1553.0], [91.6, 1553.0], [91.7, 1553.0], [91.8, 1553.0], [91.9, 1553.0], [92.0, 1609.0], [92.1, 1609.0], [92.2, 1609.0], [92.3, 1609.0], [92.4, 1609.0], [92.5, 1614.0], [92.6, 1614.0], [92.7, 1614.0], [92.8, 1614.0], [92.9, 1614.0], [93.0, 1616.0], [93.1, 1616.0], [93.2, 1616.0], [93.3, 1616.0], [93.4, 1616.0], [93.5, 1616.0], [93.6, 1616.0], [93.7, 1616.0], [93.8, 1616.0], [93.9, 1616.0], [94.0, 1616.0], [94.1, 1616.0], [94.2, 1616.0], [94.3, 1616.0], [94.4, 1616.0], [94.5, 1616.0], [94.6, 1616.0], [94.7, 1616.0], [94.8, 1616.0], [94.9, 1616.0], [95.0, 1618.0], [95.1, 1618.0], [95.2, 1618.0], [95.3, 1618.0], [95.4, 1618.0], [95.5, 1621.0], [95.6, 1621.0], [95.7, 1621.0], [95.8, 1621.0], [95.9, 1621.0], [96.0, 1622.0], [96.1, 1622.0], [96.2, 1622.0], [96.3, 1622.0], [96.4, 1622.0], [96.5, 1625.0], [96.6, 1625.0], [96.7, 1625.0], [96.8, 1625.0], [96.9, 1625.0], [97.0, 1627.0], [97.1, 1627.0], [97.2, 1627.0], [97.3, 1627.0], [97.4, 1627.0], [97.5, 1629.0], [97.6, 1629.0], [97.7, 1629.0], [97.8, 1629.0], [97.9, 1629.0], [98.0, 1631.0], [98.1, 1631.0], [98.2, 1631.0], [98.3, 1631.0], [98.4, 1631.0], [98.5, 1647.0], [98.6, 1647.0], [98.7, 1647.0], [98.8, 1647.0], [98.9, 1647.0], [99.0, 1650.0], [99.1, 1650.0], [99.2, 1650.0], [99.3, 1650.0], [99.4, 1650.0], [99.5, 1656.0], [99.6, 1656.0], [99.7, 1656.0], [99.8, 1656.0], [99.9, 1656.0]], "isOverall": false, "label": "POST bid", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 10.0, "minX": 700.0, "maxY": 34.0, "series": [{"data": [[1100.0, 20.0], [1200.0, 18.0], [1300.0, 26.0], [700.0, 34.0], [1400.0, 25.0], [1500.0, 10.0], [800.0, 17.0], [1600.0, 16.0], [900.0, 16.0], [1000.0, 18.0]], "isOverall": false, "label": "POST bid", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1600.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 25.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 175.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 175.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 25.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 102.8949999999999, "minX": 1.79110446E12, "maxY": 102.8949999999999, "series": [{"data": [[1.79110446E12, 102.8949999999999]], "isOverall": false, "label": "bidders", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110446E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 718.5185185185186, "minX": 1.0, "maxY": 1647.0, "series": [{"data": [[2.0, 1631.0], [5.0, 1645.0], [9.0, 1622.0], [12.0, 1619.6666666666667], [14.0, 1619.2], [16.0, 1611.5], [17.0, 1543.0], [19.0, 1544.0], [20.0, 1549.0], [22.0, 1528.0], [23.0, 1513.0], [25.0, 1520.5], [27.0, 1497.5], [29.0, 1493.5], [33.0, 1456.0], [32.0, 1483.0], [35.0, 1464.0], [34.0, 1481.0], [36.0, 1442.0], [39.0, 1441.6666666666667], [40.0, 1430.0], [42.0, 1416.0], [45.0, 1407.0], [44.0, 1436.3333333333333], [46.0, 1408.0], [48.0, 1403.0], [51.0, 1386.0], [50.0, 1402.5], [52.0, 1379.0], [55.0, 1397.0], [54.0, 1394.0], [56.0, 1371.0], [59.0, 1378.0], [61.0, 1372.0], [62.0, 1375.25], [67.0, 1324.0], [66.0, 1326.0], [65.0, 1379.3333333333333], [68.0, 1333.0], [75.0, 1302.0], [73.0, 1313.8], [79.0, 1272.5], [77.0, 1315.0], [76.0, 1319.5], [81.0, 1282.0], [87.0, 1255.0], [86.0, 1257.0], [84.0, 1257.3333333333333], [91.0, 1225.0], [90.0, 1233.5], [89.0, 1238.0], [95.0, 1195.0], [94.0, 1217.0], [92.0, 1220.0], [99.0, 1191.5], [97.0, 1185.0], [96.0, 1194.0], [103.0, 1165.0], [102.0, 1171.0], [101.0, 1174.0], [107.0, 1125.0], [106.0, 1154.0], [104.0, 1161.0], [110.0, 1108.0], [109.0, 1149.0], [108.0, 1122.0], [114.0, 1119.0], [113.0, 1107.3333333333333], [119.0, 1060.0], [118.0, 1074.0], [117.0, 1095.3333333333333], [122.0, 1060.0], [120.0, 1071.0], [127.0, 1038.3333333333333], [125.0, 1063.0], [124.0, 1037.0], [135.0, 994.0], [134.0, 998.0], [133.0, 1005.0], [132.0, 1036.0], [130.0, 1013.0], [129.0, 1051.0], [128.0, 1032.0], [142.0, 965.0], [138.0, 975.0], [136.0, 988.0], [149.0, 886.0], [148.0, 937.0], [146.0, 954.0], [145.0, 959.3333333333334], [158.0, 840.0], [157.0, 859.0], [155.0, 865.0], [153.0, 886.5], [167.0, 799.0], [165.0, 810.0], [164.0, 820.5], [162.0, 820.0], [161.0, 820.0], [160.0, 840.0], [172.0, 771.5], [170.0, 770.0], [169.0, 774.0], [168.0, 791.0], [178.0, 761.0], [200.0, 718.5185185185186], [1.0, 1647.0]], "isOverall": false, "label": "POST bid", "isController": false}, {"data": [[102.8949999999999, 1157.0750000000005]], "isOverall": false, "label": "POST bid-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 200.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 750.75, "minX": 1.79110446E12, "maxY": 1730.0, "series": [{"data": [[1.79110446E12, 750.75]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79110446E12, 1730.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110446E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1157.0750000000005, "minX": 1.79110446E12, "maxY": 1157.0750000000005, "series": [{"data": [[1.79110446E12, 1157.0750000000005]], "isOverall": false, "label": "POST bid", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110446E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1155.2949999999998, "minX": 1.79110446E12, "maxY": 1155.2949999999998, "series": [{"data": [[1.79110446E12, 1155.2949999999998]], "isOverall": false, "label": "POST bid", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110446E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 403.29999999999984, "minX": 1.79110446E12, "maxY": 403.29999999999984, "series": [{"data": [[1.79110446E12, 403.29999999999984]], "isOverall": false, "label": "POST bid", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110446E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 706.0, "minX": 1.79110446E12, "maxY": 1656.0, "series": [{"data": [[1.79110446E12, 1656.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79110446E12, 1541.6000000000001]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79110446E12, 1649.97]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79110446E12, 1617.9]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79110446E12, 706.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79110446E12, 1173.5]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110446E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1173.5, "minX": 200.0, "maxY": 1173.5, "series": [{"data": [[200.0, 1173.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 200.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 1173.5, "minX": 200.0, "maxY": 1173.5, "series": [{"data": [[200.0, 1173.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 200.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 3.3333333333333335, "minX": 1.79110446E12, "maxY": 3.3333333333333335, "series": [{"data": [[1.79110446E12, 3.3333333333333335]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110446E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.08333333333333333, "minX": 1.79110446E12, "maxY": 3.25, "series": [{"data": [[1.79110446E12, 0.08333333333333333]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.79110446E12, 3.25]], "isOverall": false, "label": "409", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79110446E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 3.3333333333333335, "minX": 1.79110446E12, "maxY": 3.3333333333333335, "series": [{"data": [[1.79110446E12, 3.3333333333333335]], "isOverall": false, "label": "POST bid-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110446E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 3.3333333333333335, "minX": 1.79110446E12, "maxY": 3.3333333333333335, "series": [{"data": [[1.79110446E12, 3.3333333333333335]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79110446E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

