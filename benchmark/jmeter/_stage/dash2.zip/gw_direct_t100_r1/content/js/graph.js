/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 4.0, "minX": 0.0, "maxY": 566.0, "series": [{"data": [[0.0, 4.0], [0.1, 10.0], [0.2, 12.0], [0.3, 13.0], [0.4, 15.0], [0.5, 16.0], [0.6, 17.0], [0.7, 18.0], [0.8, 19.0], [0.9, 19.0], [1.0, 20.0], [1.1, 20.0], [1.2, 21.0], [1.3, 21.0], [1.4, 22.0], [1.5, 23.0], [1.6, 23.0], [1.7, 24.0], [1.8, 24.0], [1.9, 24.0], [2.0, 25.0], [2.1, 25.0], [2.2, 26.0], [2.3, 26.0], [2.4, 26.0], [2.5, 27.0], [2.6, 27.0], [2.7, 27.0], [2.8, 28.0], [2.9, 28.0], [3.0, 28.0], [3.1, 29.0], [3.2, 29.0], [3.3, 29.0], [3.4, 30.0], [3.5, 30.0], [3.6, 30.0], [3.7, 30.0], [3.8, 31.0], [3.9, 31.0], [4.0, 31.0], [4.1, 31.0], [4.2, 32.0], [4.3, 32.0], [4.4, 32.0], [4.5, 32.0], [4.6, 33.0], [4.7, 33.0], [4.8, 33.0], [4.9, 33.0], [5.0, 34.0], [5.1, 34.0], [5.2, 34.0], [5.3, 34.0], [5.4, 34.0], [5.5, 35.0], [5.6, 35.0], [5.7, 35.0], [5.8, 35.0], [5.9, 36.0], [6.0, 36.0], [6.1, 36.0], [6.2, 36.0], [6.3, 36.0], [6.4, 36.0], [6.5, 37.0], [6.6, 37.0], [6.7, 37.0], [6.8, 37.0], [6.9, 37.0], [7.0, 38.0], [7.1, 38.0], [7.2, 38.0], [7.3, 38.0], [7.4, 38.0], [7.5, 39.0], [7.6, 39.0], [7.7, 39.0], [7.8, 39.0], [7.9, 39.0], [8.0, 40.0], [8.1, 40.0], [8.2, 40.0], [8.3, 40.0], [8.4, 40.0], [8.5, 41.0], [8.6, 41.0], [8.7, 41.0], [8.8, 41.0], [8.9, 41.0], [9.0, 41.0], [9.1, 42.0], [9.2, 42.0], [9.3, 42.0], [9.4, 42.0], [9.5, 42.0], [9.6, 42.0], [9.7, 43.0], [9.8, 43.0], [9.9, 43.0], [10.0, 43.0], [10.1, 43.0], [10.2, 43.0], [10.3, 44.0], [10.4, 44.0], [10.5, 44.0], [10.6, 44.0], [10.7, 44.0], [10.8, 44.0], [10.9, 44.0], [11.0, 45.0], [11.1, 45.0], [11.2, 45.0], [11.3, 45.0], [11.4, 45.0], [11.5, 45.0], [11.6, 46.0], [11.7, 46.0], [11.8, 46.0], [11.9, 46.0], [12.0, 46.0], [12.1, 46.0], [12.2, 46.0], [12.3, 47.0], [12.4, 47.0], [12.5, 47.0], [12.6, 47.0], [12.7, 47.0], [12.8, 47.0], [12.9, 47.0], [13.0, 48.0], [13.1, 48.0], [13.2, 48.0], [13.3, 48.0], [13.4, 48.0], [13.5, 48.0], [13.6, 48.0], [13.7, 48.0], [13.8, 49.0], [13.9, 49.0], [14.0, 49.0], [14.1, 49.0], [14.2, 49.0], [14.3, 49.0], [14.4, 49.0], [14.5, 50.0], [14.6, 50.0], [14.7, 50.0], [14.8, 50.0], [14.9, 50.0], [15.0, 50.0], [15.1, 50.0], [15.2, 50.0], [15.3, 51.0], [15.4, 51.0], [15.5, 51.0], [15.6, 51.0], [15.7, 51.0], [15.8, 51.0], [15.9, 51.0], [16.0, 51.0], [16.1, 52.0], [16.2, 52.0], [16.3, 52.0], [16.4, 52.0], [16.5, 52.0], [16.6, 52.0], [16.7, 52.0], [16.8, 53.0], [16.9, 53.0], [17.0, 53.0], [17.1, 53.0], [17.2, 53.0], [17.3, 53.0], [17.4, 53.0], [17.5, 53.0], [17.6, 53.0], [17.7, 54.0], [17.8, 54.0], [17.9, 54.0], [18.0, 54.0], [18.1, 54.0], [18.2, 54.0], [18.3, 54.0], [18.4, 54.0], [18.5, 55.0], [18.6, 55.0], [18.7, 55.0], [18.8, 55.0], [18.9, 55.0], [19.0, 55.0], [19.1, 55.0], [19.2, 55.0], [19.3, 56.0], [19.4, 56.0], [19.5, 56.0], [19.6, 56.0], [19.7, 56.0], [19.8, 56.0], [19.9, 56.0], [20.0, 56.0], [20.1, 56.0], [20.2, 57.0], [20.3, 57.0], [20.4, 57.0], [20.5, 57.0], [20.6, 57.0], [20.7, 57.0], [20.8, 57.0], [20.9, 57.0], [21.0, 57.0], [21.1, 57.0], [21.2, 58.0], [21.3, 58.0], [21.4, 58.0], [21.5, 58.0], [21.6, 58.0], [21.7, 58.0], [21.8, 58.0], [21.9, 58.0], [22.0, 58.0], [22.1, 59.0], [22.2, 59.0], [22.3, 59.0], [22.4, 59.0], [22.5, 59.0], [22.6, 59.0], [22.7, 59.0], [22.8, 59.0], [22.9, 59.0], [23.0, 60.0], [23.1, 60.0], [23.2, 60.0], [23.3, 60.0], [23.4, 60.0], [23.5, 60.0], [23.6, 60.0], [23.7, 60.0], [23.8, 60.0], [23.9, 61.0], [24.0, 61.0], [24.1, 61.0], [24.2, 61.0], [24.3, 61.0], [24.4, 61.0], [24.5, 61.0], [24.6, 61.0], [24.7, 61.0], [24.8, 62.0], [24.9, 62.0], [25.0, 62.0], [25.1, 62.0], [25.2, 62.0], [25.3, 62.0], [25.4, 62.0], [25.5, 62.0], [25.6, 62.0], [25.7, 63.0], [25.8, 63.0], [25.9, 63.0], [26.0, 63.0], [26.1, 63.0], [26.2, 63.0], [26.3, 63.0], [26.4, 63.0], [26.5, 63.0], [26.6, 63.0], [26.7, 64.0], [26.8, 64.0], [26.9, 64.0], [27.0, 64.0], [27.1, 64.0], [27.2, 64.0], [27.3, 64.0], [27.4, 64.0], [27.5, 64.0], [27.6, 64.0], [27.7, 65.0], [27.8, 65.0], [27.9, 65.0], [28.0, 65.0], [28.1, 65.0], [28.2, 65.0], [28.3, 65.0], [28.4, 65.0], [28.5, 65.0], [28.6, 66.0], [28.7, 66.0], [28.8, 66.0], [28.9, 66.0], [29.0, 66.0], [29.1, 66.0], [29.2, 66.0], [29.3, 66.0], [29.4, 66.0], [29.5, 66.0], [29.6, 67.0], [29.7, 67.0], [29.8, 67.0], [29.9, 67.0], [30.0, 67.0], [30.1, 67.0], [30.2, 67.0], [30.3, 67.0], [30.4, 67.0], [30.5, 67.0], [30.6, 68.0], [30.7, 68.0], [30.8, 68.0], [30.9, 68.0], [31.0, 68.0], [31.1, 68.0], [31.2, 68.0], [31.3, 68.0], [31.4, 68.0], [31.5, 68.0], [31.6, 69.0], [31.7, 69.0], [31.8, 69.0], [31.9, 69.0], [32.0, 69.0], [32.1, 69.0], [32.2, 69.0], [32.3, 69.0], [32.4, 69.0], [32.5, 70.0], [32.6, 70.0], [32.7, 70.0], [32.8, 70.0], [32.9, 70.0], [33.0, 70.0], [33.1, 70.0], [33.2, 70.0], [33.3, 70.0], [33.4, 70.0], [33.5, 71.0], [33.6, 71.0], [33.7, 71.0], [33.8, 71.0], [33.9, 71.0], [34.0, 71.0], [34.1, 71.0], [34.2, 71.0], [34.3, 71.0], [34.4, 72.0], [34.5, 72.0], [34.6, 72.0], [34.7, 72.0], [34.8, 72.0], [34.9, 72.0], [35.0, 72.0], [35.1, 72.0], [35.2, 72.0], [35.3, 73.0], [35.4, 73.0], [35.5, 73.0], [35.6, 73.0], [35.7, 73.0], [35.8, 73.0], [35.9, 73.0], [36.0, 73.0], [36.1, 73.0], [36.2, 73.0], [36.3, 74.0], [36.4, 74.0], [36.5, 74.0], [36.6, 74.0], [36.7, 74.0], [36.8, 74.0], [36.9, 74.0], [37.0, 74.0], [37.1, 74.0], [37.2, 75.0], [37.3, 75.0], [37.4, 75.0], [37.5, 75.0], [37.6, 75.0], [37.7, 75.0], [37.8, 75.0], [37.9, 75.0], [38.0, 75.0], [38.1, 75.0], [38.2, 76.0], [38.3, 76.0], [38.4, 76.0], [38.5, 76.0], [38.6, 76.0], [38.7, 76.0], [38.8, 76.0], [38.9, 76.0], [39.0, 76.0], [39.1, 76.0], [39.2, 76.0], [39.3, 77.0], [39.4, 77.0], [39.5, 77.0], [39.6, 77.0], [39.7, 77.0], [39.8, 77.0], [39.9, 77.0], [40.0, 77.0], [40.1, 77.0], [40.2, 77.0], [40.3, 78.0], [40.4, 78.0], [40.5, 78.0], [40.6, 78.0], [40.7, 78.0], [40.8, 78.0], [40.9, 78.0], [41.0, 78.0], [41.1, 78.0], [41.2, 79.0], [41.3, 79.0], [41.4, 79.0], [41.5, 79.0], [41.6, 79.0], [41.7, 79.0], [41.8, 79.0], [41.9, 79.0], [42.0, 79.0], [42.1, 80.0], [42.2, 80.0], [42.3, 80.0], [42.4, 80.0], [42.5, 80.0], [42.6, 80.0], [42.7, 80.0], [42.8, 80.0], [42.9, 80.0], [43.0, 81.0], [43.1, 81.0], [43.2, 81.0], [43.3, 81.0], [43.4, 81.0], [43.5, 81.0], [43.6, 81.0], [43.7, 81.0], [43.8, 81.0], [43.9, 82.0], [44.0, 82.0], [44.1, 82.0], [44.2, 82.0], [44.3, 82.0], [44.4, 82.0], [44.5, 82.0], [44.6, 82.0], [44.7, 82.0], [44.8, 82.0], [44.9, 83.0], [45.0, 83.0], [45.1, 83.0], [45.2, 83.0], [45.3, 83.0], [45.4, 83.0], [45.5, 83.0], [45.6, 83.0], [45.7, 83.0], [45.8, 84.0], [45.9, 84.0], [46.0, 84.0], [46.1, 84.0], [46.2, 84.0], [46.3, 84.0], [46.4, 84.0], [46.5, 84.0], [46.6, 84.0], [46.7, 85.0], [46.8, 85.0], [46.9, 85.0], [47.0, 85.0], [47.1, 85.0], [47.2, 85.0], [47.3, 85.0], [47.4, 85.0], [47.5, 85.0], [47.6, 86.0], [47.7, 86.0], [47.8, 86.0], [47.9, 86.0], [48.0, 86.0], [48.1, 86.0], [48.2, 86.0], [48.3, 86.0], [48.4, 87.0], [48.5, 87.0], [48.6, 87.0], [48.7, 87.0], [48.8, 87.0], [48.9, 87.0], [49.0, 87.0], [49.1, 87.0], [49.2, 87.0], [49.3, 87.0], [49.4, 88.0], [49.5, 88.0], [49.6, 88.0], [49.7, 88.0], [49.8, 88.0], [49.9, 88.0], [50.0, 88.0], [50.1, 88.0], [50.2, 89.0], [50.3, 89.0], [50.4, 89.0], [50.5, 89.0], [50.6, 89.0], [50.7, 89.0], [50.8, 89.0], [50.9, 89.0], [51.0, 89.0], [51.1, 90.0], [51.2, 90.0], [51.3, 90.0], [51.4, 90.0], [51.5, 90.0], [51.6, 90.0], [51.7, 90.0], [51.8, 90.0], [51.9, 90.0], [52.0, 91.0], [52.1, 91.0], [52.2, 91.0], [52.3, 91.0], [52.4, 91.0], [52.5, 91.0], [52.6, 91.0], [52.7, 91.0], [52.8, 92.0], [52.9, 92.0], [53.0, 92.0], [53.1, 92.0], [53.2, 92.0], [53.3, 92.0], [53.4, 92.0], [53.5, 92.0], [53.6, 92.0], [53.7, 93.0], [53.8, 93.0], [53.9, 93.0], [54.0, 93.0], [54.1, 93.0], [54.2, 93.0], [54.3, 93.0], [54.4, 93.0], [54.5, 94.0], [54.6, 94.0], [54.7, 94.0], [54.8, 94.0], [54.9, 94.0], [55.0, 94.0], [55.1, 94.0], [55.2, 95.0], [55.3, 95.0], [55.4, 95.0], [55.5, 95.0], [55.6, 95.0], [55.7, 95.0], [55.8, 95.0], [55.9, 95.0], [56.0, 95.0], [56.1, 96.0], [56.2, 96.0], [56.3, 96.0], [56.4, 96.0], [56.5, 96.0], [56.6, 96.0], [56.7, 96.0], [56.8, 96.0], [56.9, 97.0], [57.0, 97.0], [57.1, 97.0], [57.2, 97.0], [57.3, 97.0], [57.4, 97.0], [57.5, 97.0], [57.6, 98.0], [57.7, 98.0], [57.8, 98.0], [57.9, 98.0], [58.0, 98.0], [58.1, 98.0], [58.2, 98.0], [58.3, 98.0], [58.4, 99.0], [58.5, 99.0], [58.6, 99.0], [58.7, 99.0], [58.8, 99.0], [58.9, 99.0], [59.0, 99.0], [59.1, 99.0], [59.2, 100.0], [59.3, 100.0], [59.4, 100.0], [59.5, 100.0], [59.6, 100.0], [59.7, 100.0], [59.8, 100.0], [59.9, 101.0], [60.0, 101.0], [60.1, 101.0], [60.2, 101.0], [60.3, 101.0], [60.4, 101.0], [60.5, 101.0], [60.6, 102.0], [60.7, 102.0], [60.8, 102.0], [60.9, 102.0], [61.0, 102.0], [61.1, 102.0], [61.2, 102.0], [61.3, 103.0], [61.4, 103.0], [61.5, 103.0], [61.6, 103.0], [61.7, 103.0], [61.8, 103.0], [61.9, 103.0], [62.0, 104.0], [62.1, 104.0], [62.2, 104.0], [62.3, 104.0], [62.4, 104.0], [62.5, 104.0], [62.6, 104.0], [62.7, 105.0], [62.8, 105.0], [62.9, 105.0], [63.0, 105.0], [63.1, 105.0], [63.2, 105.0], [63.3, 105.0], [63.4, 106.0], [63.5, 106.0], [63.6, 106.0], [63.7, 106.0], [63.8, 106.0], [63.9, 106.0], [64.0, 107.0], [64.1, 107.0], [64.2, 107.0], [64.3, 107.0], [64.4, 107.0], [64.5, 107.0], [64.6, 107.0], [64.7, 108.0], [64.8, 108.0], [64.9, 108.0], [65.0, 108.0], [65.1, 108.0], [65.2, 108.0], [65.3, 108.0], [65.4, 109.0], [65.5, 109.0], [65.6, 109.0], [65.7, 109.0], [65.8, 109.0], [65.9, 109.0], [66.0, 110.0], [66.1, 110.0], [66.2, 110.0], [66.3, 110.0], [66.4, 110.0], [66.5, 110.0], [66.6, 110.0], [66.7, 111.0], [66.8, 111.0], [66.9, 111.0], [67.0, 111.0], [67.1, 111.0], [67.2, 111.0], [67.3, 112.0], [67.4, 112.0], [67.5, 112.0], [67.6, 112.0], [67.7, 112.0], [67.8, 112.0], [67.9, 113.0], [68.0, 113.0], [68.1, 113.0], [68.2, 113.0], [68.3, 113.0], [68.4, 113.0], [68.5, 113.0], [68.6, 114.0], [68.7, 114.0], [68.8, 114.0], [68.9, 114.0], [69.0, 114.0], [69.1, 114.0], [69.2, 115.0], [69.3, 115.0], [69.4, 115.0], [69.5, 115.0], [69.6, 115.0], [69.7, 116.0], [69.8, 116.0], [69.9, 116.0], [70.0, 116.0], [70.1, 116.0], [70.2, 116.0], [70.3, 117.0], [70.4, 117.0], [70.5, 117.0], [70.6, 117.0], [70.7, 117.0], [70.8, 118.0], [70.9, 118.0], [71.0, 118.0], [71.1, 118.0], [71.2, 118.0], [71.3, 119.0], [71.4, 119.0], [71.5, 119.0], [71.6, 119.0], [71.7, 119.0], [71.8, 119.0], [71.9, 120.0], [72.0, 120.0], [72.1, 120.0], [72.2, 120.0], [72.3, 120.0], [72.4, 121.0], [72.5, 121.0], [72.6, 121.0], [72.7, 121.0], [72.8, 121.0], [72.9, 122.0], [73.0, 122.0], [73.1, 122.0], [73.2, 122.0], [73.3, 122.0], [73.4, 123.0], [73.5, 123.0], [73.6, 123.0], [73.7, 123.0], [73.8, 123.0], [73.9, 123.0], [74.0, 124.0], [74.1, 124.0], [74.2, 124.0], [74.3, 124.0], [74.4, 125.0], [74.5, 125.0], [74.6, 125.0], [74.7, 125.0], [74.8, 125.0], [74.9, 126.0], [75.0, 126.0], [75.1, 126.0], [75.2, 126.0], [75.3, 126.0], [75.4, 127.0], [75.5, 127.0], [75.6, 127.0], [75.7, 127.0], [75.8, 127.0], [75.9, 128.0], [76.0, 128.0], [76.1, 128.0], [76.2, 128.0], [76.3, 129.0], [76.4, 129.0], [76.5, 129.0], [76.6, 129.0], [76.7, 129.0], [76.8, 130.0], [76.9, 130.0], [77.0, 130.0], [77.1, 130.0], [77.2, 130.0], [77.3, 131.0], [77.4, 131.0], [77.5, 131.0], [77.6, 131.0], [77.7, 131.0], [77.8, 132.0], [77.9, 132.0], [78.0, 132.0], [78.1, 132.0], [78.2, 133.0], [78.3, 133.0], [78.4, 133.0], [78.5, 133.0], [78.6, 134.0], [78.7, 134.0], [78.8, 134.0], [78.9, 134.0], [79.0, 134.0], [79.1, 135.0], [79.2, 135.0], [79.3, 135.0], [79.4, 135.0], [79.5, 136.0], [79.6, 136.0], [79.7, 136.0], [79.8, 136.0], [79.9, 137.0], [80.0, 137.0], [80.1, 137.0], [80.2, 137.0], [80.3, 138.0], [80.4, 138.0], [80.5, 138.0], [80.6, 138.0], [80.7, 139.0], [80.8, 139.0], [80.9, 139.0], [81.0, 140.0], [81.1, 140.0], [81.2, 140.0], [81.3, 140.0], [81.4, 141.0], [81.5, 141.0], [81.6, 141.0], [81.7, 142.0], [81.8, 142.0], [81.9, 142.0], [82.0, 142.0], [82.1, 143.0], [82.2, 143.0], [82.3, 143.0], [82.4, 144.0], [82.5, 144.0], [82.6, 144.0], [82.7, 145.0], [82.8, 145.0], [82.9, 145.0], [83.0, 146.0], [83.1, 146.0], [83.2, 146.0], [83.3, 147.0], [83.4, 147.0], [83.5, 147.0], [83.6, 148.0], [83.7, 148.0], [83.8, 148.0], [83.9, 149.0], [84.0, 149.0], [84.1, 149.0], [84.2, 149.0], [84.3, 150.0], [84.4, 150.0], [84.5, 150.0], [84.6, 151.0], [84.7, 151.0], [84.8, 151.0], [84.9, 152.0], [85.0, 152.0], [85.1, 152.0], [85.2, 153.0], [85.3, 153.0], [85.4, 153.0], [85.5, 154.0], [85.6, 154.0], [85.7, 155.0], [85.8, 155.0], [85.9, 155.0], [86.0, 156.0], [86.1, 156.0], [86.2, 157.0], [86.3, 157.0], [86.4, 158.0], [86.5, 158.0], [86.6, 158.0], [86.7, 159.0], [86.8, 159.0], [86.9, 159.0], [87.0, 160.0], [87.1, 160.0], [87.2, 161.0], [87.3, 161.0], [87.4, 161.0], [87.5, 162.0], [87.6, 162.0], [87.7, 163.0], [87.8, 163.0], [87.9, 163.0], [88.0, 164.0], [88.1, 164.0], [88.2, 165.0], [88.3, 165.0], [88.4, 166.0], [88.5, 166.0], [88.6, 167.0], [88.7, 167.0], [88.8, 167.0], [88.9, 168.0], [89.0, 168.0], [89.1, 169.0], [89.2, 169.0], [89.3, 170.0], [89.4, 170.0], [89.5, 171.0], [89.6, 171.0], [89.7, 171.0], [89.8, 172.0], [89.9, 172.0], [90.0, 173.0], [90.1, 173.0], [90.2, 174.0], [90.3, 175.0], [90.4, 175.0], [90.5, 176.0], [90.6, 176.0], [90.7, 177.0], [90.8, 177.0], [90.9, 178.0], [91.0, 179.0], [91.1, 179.0], [91.2, 180.0], [91.3, 180.0], [91.4, 181.0], [91.5, 182.0], [91.6, 182.0], [91.7, 183.0], [91.8, 183.0], [91.9, 184.0], [92.0, 185.0], [92.1, 185.0], [92.2, 186.0], [92.3, 187.0], [92.4, 188.0], [92.5, 188.0], [92.6, 189.0], [92.7, 190.0], [92.8, 190.0], [92.9, 191.0], [93.0, 192.0], [93.1, 193.0], [93.2, 194.0], [93.3, 194.0], [93.4, 195.0], [93.5, 196.0], [93.6, 197.0], [93.7, 197.0], [93.8, 198.0], [93.9, 199.0], [94.0, 200.0], [94.1, 201.0], [94.2, 202.0], [94.3, 203.0], [94.4, 204.0], [94.5, 205.0], [94.6, 205.0], [94.7, 206.0], [94.8, 208.0], [94.9, 209.0], [95.0, 209.0], [95.1, 210.0], [95.2, 211.0], [95.3, 212.0], [95.4, 213.0], [95.5, 215.0], [95.6, 216.0], [95.7, 217.0], [95.8, 218.0], [95.9, 220.0], [96.0, 221.0], [96.1, 222.0], [96.2, 223.0], [96.3, 224.0], [96.4, 226.0], [96.5, 227.0], [96.6, 229.0], [96.7, 230.0], [96.8, 232.0], [96.9, 233.0], [97.0, 234.0], [97.1, 236.0], [97.2, 238.0], [97.3, 240.0], [97.4, 241.0], [97.5, 243.0], [97.6, 244.0], [97.7, 247.0], [97.8, 249.0], [97.9, 252.0], [98.0, 254.0], [98.1, 257.0], [98.2, 259.0], [98.3, 263.0], [98.4, 266.0], [98.5, 269.0], [98.6, 273.0], [98.7, 277.0], [98.8, 282.0], [98.9, 286.0], [99.0, 289.0], [99.1, 295.0], [99.2, 300.0], [99.3, 308.0], [99.4, 315.0], [99.5, 324.0], [99.6, 332.0], [99.7, 346.0], [99.8, 365.0], [99.9, 393.0], [100.0, 566.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 7.0, "minX": 0.0, "maxY": 38155.0, "series": [{"data": [[0.0, 38155.0], [300.0, 462.0], [100.0, 22458.0], [200.0, 3395.0], [400.0, 54.0], [500.0, 7.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 7.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 64524.0, "series": [{"data": [[0.0, 64524.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 7.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 91.26319625195242, "minX": 1.79070366E12, "maxY": 99.8500671967745, "series": [{"data": [[1.79070366E12, 91.26319625195242], [1.79070372E12, 99.8500671967745]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070372E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 12.941176470588236, "minX": 3.0, "maxY": 216.50000000000003, "series": [{"data": [[3.0, 145.33333333333334], [4.0, 13.324324324324326], [5.0, 12.941176470588236], [6.0, 20.142857142857146], [7.0, 22.687500000000007], [8.0, 22.89285714285714], [9.0, 27.048780487804876], [10.0, 23.684210526315788], [11.0, 27.657894736842106], [12.0, 39.0], [13.0, 46.5], [14.0, 33.66071428571429], [15.0, 33.73529411764706], [16.0, 26.6], [17.0, 40.5531914893617], [18.0, 32.53703703703703], [19.0, 38.99999999999999], [20.0, 36.779411764705884], [21.0, 39.83720930232558], [22.0, 41.2280701754386], [23.0, 51.54054054054054], [24.0, 53.75510204081632], [25.0, 41.44117647058825], [26.0, 42.63793103448276], [27.0, 50.31034482758621], [28.0, 39.28378378378379], [29.0, 47.85937500000001], [30.0, 47.344827586206904], [31.0, 52.85483870967741], [32.0, 42.556962025316466], [33.0, 44.35000000000001], [34.0, 52.03797468354429], [35.0, 48.78787878787878], [36.0, 41.189873417721515], [37.0, 47.40909090909093], [38.0, 48.899999999999984], [39.0, 66.18367346938777], [40.0, 61.101265822784804], [41.0, 67.75925925925924], [42.0, 74.85454545454544], [43.0, 68.17391304347828], [44.0, 78.04918032786883], [45.0, 103.62962962962963], [46.0, 86.04347826086958], [47.0, 69.51851851851852], [48.0, 59.67241379310345], [49.0, 64.27000000000002], [50.0, 54.3939393939394], [51.0, 72.75294117647056], [52.0, 77.13636363636363], [53.0, 105.93220338983049], [54.0, 84.2727272727273], [55.0, 119.14814814814817], [56.0, 105.71764705882352], [57.0, 75.74468085106383], [58.0, 80.00000000000001], [59.0, 88.39560439560438], [60.0, 64.25000000000001], [61.0, 83.15909090909092], [62.0, 72.99999999999999], [63.0, 96.36486486486484], [64.0, 127.16129032258065], [65.0, 142.72222222222223], [66.0, 216.50000000000003], [67.0, 191.2173913043478], [68.0, 188.4838709677419], [69.0, 191.34090909090907], [70.0, 129.75925925925924], [71.0, 148.15384615384616], [72.0, 138.87804878048775], [73.0, 81.90697674418605], [74.0, 163.9795918367347], [75.0, 159.32258064516128], [76.0, 214.0], [77.0, 215.92222222222222], [78.0, 97.89130434782611], [79.0, 142.59090909090915], [80.0, 88.18367346938781], [81.0, 94.07865168539325], [82.0, 71.07017543859645], [83.0, 67.78070175438599], [84.0, 91.68421052631582], [85.0, 99.7717391304348], [86.0, 93.52702702702703], [87.0, 119.87500000000001], [88.0, 111.0909090909091], [89.0, 167.82352941176472], [90.0, 96.43396226415095], [91.0, 89.68867924528303], [92.0, 98.68181818181819], [93.0, 98.95588235294117], [94.0, 91.1333333333333], [95.0, 123.01250000000003], [96.0, 113.44871794871796], [97.0, 139.7291666666667], [98.0, 174.08064516129042], [99.0, 132.6632653061225], [100.0, 102.05116794543781]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[96.01577536377812, 100.39433760518179]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 222836.0, "minX": 1.79070366E12, "maxY": 354006.76666666666, "series": [{"data": [[1.79070366E12, 285635.1666666667], [1.79070372E12, 354006.76666666666]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79070366E12, 222836.0], [1.79070372E12, 276203.73333333334]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070372E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 94.06204502183901, "minX": 1.79070366E12, "maxY": 108.24317195904933, "series": [{"data": [[1.79070366E12, 108.24317195904933], [1.79070372E12, 94.06204502183901]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070372E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 92.95699406428517, "minX": 1.79070366E12, "maxY": 106.77917751171213, "series": [{"data": [[1.79070366E12, 106.77917751171213], [1.79070372E12, 92.95699406428517]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070372E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.017667151976705032, "minX": 1.79070366E12, "maxY": 0.032656602463994794, "series": [{"data": [[1.79070366E12, 0.032656602463994794], [1.79070372E12, 0.017667151976705032]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070372E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 4.0, "minX": 1.79070366E12, "maxY": 566.0, "series": [{"data": [[1.79070366E12, 566.0], [1.79070372E12, 464.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79070366E12, 185.0], [1.79070372E12, 150.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79070366E12, 296.0], [1.79070372E12, 244.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79070366E12, 220.0], [1.79070372E12, 182.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79070366E12, 6.0], [1.79070372E12, 4.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79070366E12, 98.0], [1.79070372E12, 80.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070372E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 21.0, "minX": 332.0, "maxY": 169.0, "series": [{"data": [[601.0, 153.0], [618.0, 42.0], [627.0, 69.0], [650.0, 82.0], [670.0, 139.5], [667.0, 133.0], [688.0, 87.0], [702.0, 127.0], [721.0, 90.0], [722.0, 123.0], [728.0, 126.0], [765.0, 77.0], [779.0, 116.0], [818.0, 112.0], [831.0, 112.0], [830.0, 113.5], [850.0, 91.0], [841.0, 111.0], [859.0, 107.0], [866.0, 105.0], [895.0, 101.0], [884.0, 101.5], [879.0, 96.0], [898.0, 85.0], [918.0, 97.0], [910.0, 100.5], [943.0, 95.0], [949.0, 100.0], [940.0, 98.0], [966.0, 92.0], [1003.0, 98.0], [995.0, 93.0], [1010.0, 83.0], [994.0, 90.0], [1022.0, 83.0], [1027.0, 93.0], [1025.0, 87.0], [1057.0, 84.0], [1066.0, 82.0], [1036.0, 85.0], [1035.0, 82.0], [1032.0, 90.0], [1040.0, 89.0], [1038.0, 90.0], [1042.0, 88.0], [1044.0, 82.0], [1084.0, 81.0], [1073.0, 82.0], [1077.0, 85.0], [1092.0, 79.0], [1126.0, 81.0], [1127.0, 77.0], [1155.0, 82.0], [1180.0, 73.0], [1198.0, 74.0], [1262.0, 72.0], [1223.0, 73.0], [1219.0, 76.0], [1241.0, 65.0], [1303.0, 65.0], [1309.0, 73.0], [332.0, 21.0], [395.0, 156.0], [485.0, 33.0], [507.0, 169.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1309.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 21.0, "minX": 332.0, "maxY": 167.0, "series": [{"data": [[601.0, 151.0], [618.0, 40.0], [627.0, 67.0], [650.0, 80.0], [670.0, 138.0], [667.0, 130.0], [688.0, 86.0], [702.0, 124.0], [721.0, 89.0], [722.0, 122.0], [728.0, 124.5], [765.0, 76.0], [779.0, 115.0], [818.0, 110.0], [831.0, 109.0], [830.0, 112.0], [850.0, 90.0], [841.0, 110.0], [859.0, 106.0], [866.0, 103.0], [895.0, 100.0], [884.0, 101.0], [879.0, 94.0], [898.0, 83.5], [918.0, 96.0], [910.0, 98.0], [943.0, 94.0], [949.0, 99.0], [940.0, 96.0], [966.0, 91.0], [1003.0, 97.0], [995.0, 92.0], [1010.0, 82.0], [994.0, 89.0], [1022.0, 82.0], [1027.0, 92.0], [1025.0, 86.0], [1057.0, 83.0], [1066.0, 81.0], [1036.0, 84.5], [1035.0, 81.0], [1032.0, 90.0], [1040.0, 88.0], [1038.0, 89.0], [1042.0, 87.0], [1044.0, 81.0], [1084.0, 79.0], [1073.0, 81.0], [1077.0, 84.0], [1092.0, 78.0], [1126.0, 80.0], [1127.0, 76.0], [1155.0, 80.0], [1180.0, 72.0], [1198.0, 74.0], [1262.0, 72.0], [1223.0, 72.0], [1219.0, 75.0], [1241.0, 64.0], [1303.0, 64.0], [1309.0, 71.0], [332.0, 21.0], [395.0, 155.0], [485.0, 33.0], [507.0, 167.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1309.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 481.9166666666667, "minX": 1.79070366E12, "maxY": 593.6, "series": [{"data": [[1.79070366E12, 481.9166666666667], [1.79070372E12, 593.6]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070372E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 480.25, "minX": 1.79070366E12, "maxY": 595.2666666666667, "series": [{"data": [[1.79070366E12, 480.25], [1.79070372E12, 595.2666666666667]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070372E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 480.25, "minX": 1.79070366E12, "maxY": 595.2666666666667, "series": [{"data": [[1.79070366E12, 480.25], [1.79070372E12, 595.2666666666667]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070372E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 480.25, "minX": 1.79070366E12, "maxY": 595.2666666666667, "series": [{"data": [[1.79070366E12, 480.25], [1.79070372E12, 595.2666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070372E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

