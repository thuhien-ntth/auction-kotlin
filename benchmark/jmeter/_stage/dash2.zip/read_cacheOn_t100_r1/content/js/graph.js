/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 9.0, "minX": 0.0, "maxY": 806.0, "series": [{"data": [[0.0, 9.0], [0.1, 14.0], [0.2, 17.0], [0.3, 20.0], [0.4, 23.0], [0.5, 27.0], [0.6, 29.0], [0.7, 31.0], [0.8, 33.0], [0.9, 34.0], [1.0, 35.0], [1.1, 36.0], [1.2, 37.0], [1.3, 38.0], [1.4, 39.0], [1.5, 40.0], [1.6, 40.0], [1.7, 41.0], [1.8, 42.0], [1.9, 43.0], [2.0, 43.0], [2.1, 44.0], [2.2, 45.0], [2.3, 45.0], [2.4, 46.0], [2.5, 46.0], [2.6, 47.0], [2.7, 47.0], [2.8, 48.0], [2.9, 48.0], [3.0, 49.0], [3.1, 49.0], [3.2, 49.0], [3.3, 50.0], [3.4, 50.0], [3.5, 51.0], [3.6, 51.0], [3.7, 51.0], [3.8, 51.0], [3.9, 52.0], [4.0, 52.0], [4.1, 52.0], [4.2, 53.0], [4.3, 53.0], [4.4, 53.0], [4.5, 53.0], [4.6, 54.0], [4.7, 54.0], [4.8, 54.0], [4.9, 55.0], [5.0, 55.0], [5.1, 55.0], [5.2, 56.0], [5.3, 56.0], [5.4, 56.0], [5.5, 57.0], [5.6, 57.0], [5.7, 57.0], [5.8, 57.0], [5.9, 58.0], [6.0, 58.0], [6.1, 58.0], [6.2, 58.0], [6.3, 59.0], [6.4, 59.0], [6.5, 59.0], [6.6, 59.0], [6.7, 60.0], [6.8, 60.0], [6.9, 60.0], [7.0, 60.0], [7.1, 61.0], [7.2, 61.0], [7.3, 61.0], [7.4, 61.0], [7.5, 62.0], [7.6, 62.0], [7.7, 62.0], [7.8, 62.0], [7.9, 63.0], [8.0, 63.0], [8.1, 63.0], [8.2, 63.0], [8.3, 64.0], [8.4, 64.0], [8.5, 64.0], [8.6, 64.0], [8.7, 64.0], [8.8, 65.0], [8.9, 65.0], [9.0, 65.0], [9.1, 65.0], [9.2, 65.0], [9.3, 66.0], [9.4, 66.0], [9.5, 66.0], [9.6, 66.0], [9.7, 66.0], [9.8, 66.0], [9.9, 67.0], [10.0, 67.0], [10.1, 67.0], [10.2, 67.0], [10.3, 67.0], [10.4, 67.0], [10.5, 67.0], [10.6, 68.0], [10.7, 68.0], [10.8, 68.0], [10.9, 68.0], [11.0, 68.0], [11.1, 68.0], [11.2, 69.0], [11.3, 69.0], [11.4, 69.0], [11.5, 69.0], [11.6, 69.0], [11.7, 69.0], [11.8, 69.0], [11.9, 70.0], [12.0, 70.0], [12.1, 70.0], [12.2, 70.0], [12.3, 70.0], [12.4, 70.0], [12.5, 71.0], [12.6, 71.0], [12.7, 71.0], [12.8, 71.0], [12.9, 71.0], [13.0, 71.0], [13.1, 71.0], [13.2, 72.0], [13.3, 72.0], [13.4, 72.0], [13.5, 72.0], [13.6, 72.0], [13.7, 72.0], [13.8, 73.0], [13.9, 73.0], [14.0, 73.0], [14.1, 73.0], [14.2, 73.0], [14.3, 73.0], [14.4, 74.0], [14.5, 74.0], [14.6, 74.0], [14.7, 74.0], [14.8, 74.0], [14.9, 74.0], [15.0, 74.0], [15.1, 75.0], [15.2, 75.0], [15.3, 75.0], [15.4, 75.0], [15.5, 75.0], [15.6, 75.0], [15.7, 76.0], [15.8, 76.0], [15.9, 76.0], [16.0, 76.0], [16.1, 76.0], [16.2, 76.0], [16.3, 76.0], [16.4, 77.0], [16.5, 77.0], [16.6, 77.0], [16.7, 77.0], [16.8, 77.0], [16.9, 77.0], [17.0, 77.0], [17.1, 78.0], [17.2, 78.0], [17.3, 78.0], [17.4, 78.0], [17.5, 78.0], [17.6, 78.0], [17.7, 78.0], [17.8, 79.0], [17.9, 79.0], [18.0, 79.0], [18.1, 79.0], [18.2, 79.0], [18.3, 79.0], [18.4, 79.0], [18.5, 80.0], [18.6, 80.0], [18.7, 80.0], [18.8, 80.0], [18.9, 80.0], [19.0, 80.0], [19.1, 80.0], [19.2, 81.0], [19.3, 81.0], [19.4, 81.0], [19.5, 81.0], [19.6, 81.0], [19.7, 81.0], [19.8, 81.0], [19.9, 82.0], [20.0, 82.0], [20.1, 82.0], [20.2, 82.0], [20.3, 82.0], [20.4, 82.0], [20.5, 82.0], [20.6, 82.0], [20.7, 83.0], [20.8, 83.0], [20.9, 83.0], [21.0, 83.0], [21.1, 83.0], [21.2, 83.0], [21.3, 83.0], [21.4, 83.0], [21.5, 83.0], [21.6, 83.0], [21.7, 84.0], [21.8, 84.0], [21.9, 84.0], [22.0, 84.0], [22.1, 84.0], [22.2, 84.0], [22.3, 84.0], [22.4, 84.0], [22.5, 85.0], [22.6, 85.0], [22.7, 85.0], [22.8, 85.0], [22.9, 85.0], [23.0, 85.0], [23.1, 85.0], [23.2, 85.0], [23.3, 85.0], [23.4, 86.0], [23.5, 86.0], [23.6, 86.0], [23.7, 86.0], [23.8, 86.0], [23.9, 86.0], [24.0, 86.0], [24.1, 86.0], [24.2, 87.0], [24.3, 87.0], [24.4, 87.0], [24.5, 87.0], [24.6, 87.0], [24.7, 87.0], [24.8, 87.0], [24.9, 87.0], [25.0, 88.0], [25.1, 88.0], [25.2, 88.0], [25.3, 88.0], [25.4, 88.0], [25.5, 88.0], [25.6, 88.0], [25.7, 88.0], [25.8, 89.0], [25.9, 89.0], [26.0, 89.0], [26.1, 89.0], [26.2, 89.0], [26.3, 89.0], [26.4, 89.0], [26.5, 89.0], [26.6, 90.0], [26.7, 90.0], [26.8, 90.0], [26.9, 90.0], [27.0, 90.0], [27.1, 90.0], [27.2, 90.0], [27.3, 90.0], [27.4, 91.0], [27.5, 91.0], [27.6, 91.0], [27.7, 91.0], [27.8, 91.0], [27.9, 91.0], [28.0, 91.0], [28.1, 92.0], [28.2, 92.0], [28.3, 92.0], [28.4, 92.0], [28.5, 92.0], [28.6, 92.0], [28.7, 92.0], [28.8, 92.0], [28.9, 93.0], [29.0, 93.0], [29.1, 93.0], [29.2, 93.0], [29.3, 93.0], [29.4, 93.0], [29.5, 93.0], [29.6, 94.0], [29.7, 94.0], [29.8, 94.0], [29.9, 94.0], [30.0, 94.0], [30.1, 94.0], [30.2, 94.0], [30.3, 94.0], [30.4, 94.0], [30.5, 95.0], [30.6, 95.0], [30.7, 95.0], [30.8, 95.0], [30.9, 95.0], [31.0, 95.0], [31.1, 95.0], [31.2, 95.0], [31.3, 96.0], [31.4, 96.0], [31.5, 96.0], [31.6, 96.0], [31.7, 96.0], [31.8, 96.0], [31.9, 96.0], [32.0, 96.0], [32.1, 97.0], [32.2, 97.0], [32.3, 97.0], [32.4, 97.0], [32.5, 97.0], [32.6, 97.0], [32.7, 97.0], [32.8, 97.0], [32.9, 97.0], [33.0, 98.0], [33.1, 98.0], [33.2, 98.0], [33.3, 98.0], [33.4, 98.0], [33.5, 98.0], [33.6, 98.0], [33.7, 98.0], [33.8, 98.0], [33.9, 99.0], [34.0, 99.0], [34.1, 99.0], [34.2, 99.0], [34.3, 99.0], [34.4, 99.0], [34.5, 99.0], [34.6, 99.0], [34.7, 99.0], [34.8, 100.0], [34.9, 100.0], [35.0, 100.0], [35.1, 100.0], [35.2, 100.0], [35.3, 100.0], [35.4, 100.0], [35.5, 100.0], [35.6, 100.0], [35.7, 101.0], [35.8, 101.0], [35.9, 101.0], [36.0, 101.0], [36.1, 101.0], [36.2, 101.0], [36.3, 101.0], [36.4, 101.0], [36.5, 101.0], [36.6, 102.0], [36.7, 102.0], [36.8, 102.0], [36.9, 102.0], [37.0, 102.0], [37.1, 102.0], [37.2, 102.0], [37.3, 102.0], [37.4, 102.0], [37.5, 103.0], [37.6, 103.0], [37.7, 103.0], [37.8, 103.0], [37.9, 103.0], [38.0, 103.0], [38.1, 103.0], [38.2, 103.0], [38.3, 103.0], [38.4, 104.0], [38.5, 104.0], [38.6, 104.0], [38.7, 104.0], [38.8, 104.0], [38.9, 104.0], [39.0, 104.0], [39.1, 105.0], [39.2, 105.0], [39.3, 105.0], [39.4, 105.0], [39.5, 105.0], [39.6, 105.0], [39.7, 105.0], [39.8, 105.0], [39.9, 106.0], [40.0, 106.0], [40.1, 106.0], [40.2, 106.0], [40.3, 106.0], [40.4, 106.0], [40.5, 106.0], [40.6, 107.0], [40.7, 107.0], [40.8, 107.0], [40.9, 107.0], [41.0, 107.0], [41.1, 107.0], [41.2, 107.0], [41.3, 107.0], [41.4, 108.0], [41.5, 108.0], [41.6, 108.0], [41.7, 108.0], [41.8, 108.0], [41.9, 108.0], [42.0, 108.0], [42.1, 108.0], [42.2, 109.0], [42.3, 109.0], [42.4, 109.0], [42.5, 109.0], [42.6, 109.0], [42.7, 109.0], [42.8, 109.0], [42.9, 109.0], [43.0, 110.0], [43.1, 110.0], [43.2, 110.0], [43.3, 110.0], [43.4, 110.0], [43.5, 110.0], [43.6, 110.0], [43.7, 111.0], [43.8, 111.0], [43.9, 111.0], [44.0, 111.0], [44.1, 111.0], [44.2, 111.0], [44.3, 111.0], [44.4, 111.0], [44.5, 112.0], [44.6, 112.0], [44.7, 112.0], [44.8, 112.0], [44.9, 112.0], [45.0, 112.0], [45.1, 112.0], [45.2, 112.0], [45.3, 113.0], [45.4, 113.0], [45.5, 113.0], [45.6, 113.0], [45.7, 113.0], [45.8, 113.0], [45.9, 113.0], [46.0, 113.0], [46.1, 114.0], [46.2, 114.0], [46.3, 114.0], [46.4, 114.0], [46.5, 114.0], [46.6, 114.0], [46.7, 114.0], [46.8, 115.0], [46.9, 115.0], [47.0, 115.0], [47.1, 115.0], [47.2, 115.0], [47.3, 115.0], [47.4, 115.0], [47.5, 115.0], [47.6, 115.0], [47.7, 116.0], [47.8, 116.0], [47.9, 116.0], [48.0, 116.0], [48.1, 116.0], [48.2, 116.0], [48.3, 116.0], [48.4, 116.0], [48.5, 117.0], [48.6, 117.0], [48.7, 117.0], [48.8, 117.0], [48.9, 117.0], [49.0, 117.0], [49.1, 117.0], [49.2, 117.0], [49.3, 118.0], [49.4, 118.0], [49.5, 118.0], [49.6, 118.0], [49.7, 118.0], [49.8, 118.0], [49.9, 118.0], [50.0, 118.0], [50.1, 119.0], [50.2, 119.0], [50.3, 119.0], [50.4, 119.0], [50.5, 119.0], [50.6, 119.0], [50.7, 119.0], [50.8, 119.0], [50.9, 120.0], [51.0, 120.0], [51.1, 120.0], [51.2, 120.0], [51.3, 120.0], [51.4, 120.0], [51.5, 121.0], [51.6, 121.0], [51.7, 121.0], [51.8, 121.0], [51.9, 121.0], [52.0, 121.0], [52.1, 121.0], [52.2, 122.0], [52.3, 122.0], [52.4, 122.0], [52.5, 122.0], [52.6, 122.0], [52.7, 122.0], [52.8, 122.0], [52.9, 123.0], [53.0, 123.0], [53.1, 123.0], [53.2, 123.0], [53.3, 123.0], [53.4, 123.0], [53.5, 123.0], [53.6, 124.0], [53.7, 124.0], [53.8, 124.0], [53.9, 124.0], [54.0, 124.0], [54.1, 124.0], [54.2, 125.0], [54.3, 125.0], [54.4, 125.0], [54.5, 125.0], [54.6, 125.0], [54.7, 125.0], [54.8, 126.0], [54.9, 126.0], [55.0, 126.0], [55.1, 126.0], [55.2, 126.0], [55.3, 126.0], [55.4, 126.0], [55.5, 127.0], [55.6, 127.0], [55.7, 127.0], [55.8, 127.0], [55.9, 127.0], [56.0, 127.0], [56.1, 128.0], [56.2, 128.0], [56.3, 128.0], [56.4, 128.0], [56.5, 128.0], [56.6, 128.0], [56.7, 129.0], [56.8, 129.0], [56.9, 129.0], [57.0, 129.0], [57.1, 129.0], [57.2, 129.0], [57.3, 130.0], [57.4, 130.0], [57.5, 130.0], [57.6, 130.0], [57.7, 130.0], [57.8, 130.0], [57.9, 130.0], [58.0, 131.0], [58.1, 131.0], [58.2, 131.0], [58.3, 131.0], [58.4, 131.0], [58.5, 131.0], [58.6, 131.0], [58.7, 132.0], [58.8, 132.0], [58.9, 132.0], [59.0, 132.0], [59.1, 132.0], [59.2, 132.0], [59.3, 132.0], [59.4, 132.0], [59.5, 133.0], [59.6, 133.0], [59.7, 133.0], [59.8, 133.0], [59.9, 133.0], [60.0, 133.0], [60.1, 133.0], [60.2, 134.0], [60.3, 134.0], [60.4, 134.0], [60.5, 134.0], [60.6, 134.0], [60.7, 134.0], [60.8, 134.0], [60.9, 135.0], [61.0, 135.0], [61.1, 135.0], [61.2, 135.0], [61.3, 135.0], [61.4, 135.0], [61.5, 135.0], [61.6, 136.0], [61.7, 136.0], [61.8, 136.0], [61.9, 136.0], [62.0, 136.0], [62.1, 136.0], [62.2, 137.0], [62.3, 137.0], [62.4, 137.0], [62.5, 137.0], [62.6, 137.0], [62.7, 138.0], [62.8, 138.0], [62.9, 138.0], [63.0, 138.0], [63.1, 138.0], [63.2, 139.0], [63.3, 139.0], [63.4, 139.0], [63.5, 139.0], [63.6, 139.0], [63.7, 140.0], [63.8, 140.0], [63.9, 140.0], [64.0, 140.0], [64.1, 140.0], [64.2, 140.0], [64.3, 141.0], [64.4, 141.0], [64.5, 141.0], [64.6, 141.0], [64.7, 142.0], [64.8, 142.0], [64.9, 142.0], [65.0, 142.0], [65.1, 142.0], [65.2, 143.0], [65.3, 143.0], [65.4, 143.0], [65.5, 143.0], [65.6, 143.0], [65.7, 143.0], [65.8, 144.0], [65.9, 144.0], [66.0, 144.0], [66.1, 144.0], [66.2, 144.0], [66.3, 145.0], [66.4, 145.0], [66.5, 145.0], [66.6, 145.0], [66.7, 145.0], [66.8, 146.0], [66.9, 146.0], [67.0, 146.0], [67.1, 146.0], [67.2, 146.0], [67.3, 146.0], [67.4, 147.0], [67.5, 147.0], [67.6, 147.0], [67.7, 147.0], [67.8, 147.0], [67.9, 148.0], [68.0, 148.0], [68.1, 148.0], [68.2, 148.0], [68.3, 148.0], [68.4, 149.0], [68.5, 149.0], [68.6, 149.0], [68.7, 149.0], [68.8, 149.0], [68.9, 149.0], [69.0, 150.0], [69.1, 150.0], [69.2, 150.0], [69.3, 150.0], [69.4, 150.0], [69.5, 150.0], [69.6, 151.0], [69.7, 151.0], [69.8, 151.0], [69.9, 151.0], [70.0, 152.0], [70.1, 152.0], [70.2, 152.0], [70.3, 152.0], [70.4, 152.0], [70.5, 153.0], [70.6, 153.0], [70.7, 153.0], [70.8, 153.0], [70.9, 153.0], [71.0, 154.0], [71.1, 154.0], [71.2, 154.0], [71.3, 154.0], [71.4, 155.0], [71.5, 155.0], [71.6, 155.0], [71.7, 155.0], [71.8, 155.0], [71.9, 156.0], [72.0, 156.0], [72.1, 156.0], [72.2, 156.0], [72.3, 157.0], [72.4, 157.0], [72.5, 157.0], [72.6, 157.0], [72.7, 158.0], [72.8, 158.0], [72.9, 158.0], [73.0, 158.0], [73.1, 158.0], [73.2, 159.0], [73.3, 159.0], [73.4, 159.0], [73.5, 159.0], [73.6, 160.0], [73.7, 160.0], [73.8, 160.0], [73.9, 160.0], [74.0, 161.0], [74.1, 161.0], [74.2, 161.0], [74.3, 161.0], [74.4, 162.0], [74.5, 162.0], [74.6, 162.0], [74.7, 162.0], [74.8, 162.0], [74.9, 163.0], [75.0, 163.0], [75.1, 163.0], [75.2, 163.0], [75.3, 164.0], [75.4, 164.0], [75.5, 164.0], [75.6, 164.0], [75.7, 165.0], [75.8, 165.0], [75.9, 165.0], [76.0, 165.0], [76.1, 166.0], [76.2, 166.0], [76.3, 166.0], [76.4, 166.0], [76.5, 166.0], [76.6, 167.0], [76.7, 167.0], [76.8, 167.0], [76.9, 167.0], [77.0, 168.0], [77.1, 168.0], [77.2, 168.0], [77.3, 168.0], [77.4, 169.0], [77.5, 169.0], [77.6, 169.0], [77.7, 169.0], [77.8, 170.0], [77.9, 170.0], [78.0, 170.0], [78.1, 171.0], [78.2, 171.0], [78.3, 171.0], [78.4, 171.0], [78.5, 172.0], [78.6, 172.0], [78.7, 172.0], [78.8, 173.0], [78.9, 173.0], [79.0, 173.0], [79.1, 174.0], [79.2, 174.0], [79.3, 174.0], [79.4, 175.0], [79.5, 175.0], [79.6, 175.0], [79.7, 176.0], [79.8, 176.0], [79.9, 176.0], [80.0, 176.0], [80.1, 177.0], [80.2, 177.0], [80.3, 177.0], [80.4, 178.0], [80.5, 178.0], [80.6, 178.0], [80.7, 179.0], [80.8, 179.0], [80.9, 179.0], [81.0, 180.0], [81.1, 180.0], [81.2, 180.0], [81.3, 181.0], [81.4, 181.0], [81.5, 181.0], [81.6, 182.0], [81.7, 182.0], [81.8, 182.0], [81.9, 183.0], [82.0, 183.0], [82.1, 183.0], [82.2, 183.0], [82.3, 184.0], [82.4, 184.0], [82.5, 184.0], [82.6, 185.0], [82.7, 185.0], [82.8, 185.0], [82.9, 185.0], [83.0, 186.0], [83.1, 186.0], [83.2, 187.0], [83.3, 187.0], [83.4, 187.0], [83.5, 188.0], [83.6, 188.0], [83.7, 188.0], [83.8, 189.0], [83.9, 189.0], [84.0, 190.0], [84.1, 190.0], [84.2, 191.0], [84.3, 191.0], [84.4, 192.0], [84.5, 192.0], [84.6, 192.0], [84.7, 193.0], [84.8, 193.0], [84.9, 194.0], [85.0, 194.0], [85.1, 195.0], [85.2, 195.0], [85.3, 196.0], [85.4, 196.0], [85.5, 196.0], [85.6, 197.0], [85.7, 197.0], [85.8, 198.0], [85.9, 198.0], [86.0, 198.0], [86.1, 199.0], [86.2, 199.0], [86.3, 200.0], [86.4, 200.0], [86.5, 200.0], [86.6, 201.0], [86.7, 201.0], [86.8, 202.0], [86.9, 202.0], [87.0, 202.0], [87.1, 203.0], [87.2, 203.0], [87.3, 204.0], [87.4, 204.0], [87.5, 205.0], [87.6, 205.0], [87.7, 206.0], [87.8, 206.0], [87.9, 207.0], [88.0, 207.0], [88.1, 208.0], [88.2, 208.0], [88.3, 209.0], [88.4, 209.0], [88.5, 210.0], [88.6, 211.0], [88.7, 211.0], [88.8, 212.0], [88.9, 212.0], [89.0, 213.0], [89.1, 214.0], [89.2, 214.0], [89.3, 215.0], [89.4, 215.0], [89.5, 216.0], [89.6, 216.0], [89.7, 217.0], [89.8, 217.0], [89.9, 218.0], [90.0, 218.0], [90.1, 219.0], [90.2, 220.0], [90.3, 220.0], [90.4, 221.0], [90.5, 222.0], [90.6, 222.0], [90.7, 223.0], [90.8, 223.0], [90.9, 224.0], [91.0, 225.0], [91.1, 226.0], [91.2, 226.0], [91.3, 227.0], [91.4, 228.0], [91.5, 229.0], [91.6, 230.0], [91.7, 230.0], [91.8, 231.0], [91.9, 231.0], [92.0, 232.0], [92.1, 233.0], [92.2, 234.0], [92.3, 235.0], [92.4, 235.0], [92.5, 236.0], [92.6, 237.0], [92.7, 238.0], [92.8, 239.0], [92.9, 239.0], [93.0, 240.0], [93.1, 241.0], [93.2, 242.0], [93.3, 243.0], [93.4, 244.0], [93.5, 245.0], [93.6, 246.0], [93.7, 247.0], [93.8, 248.0], [93.9, 248.0], [94.0, 249.0], [94.1, 250.0], [94.2, 251.0], [94.3, 252.0], [94.4, 253.0], [94.5, 253.0], [94.6, 254.0], [94.7, 256.0], [94.8, 257.0], [94.9, 258.0], [95.0, 259.0], [95.1, 260.0], [95.2, 262.0], [95.3, 263.0], [95.4, 264.0], [95.5, 265.0], [95.6, 267.0], [95.7, 268.0], [95.8, 269.0], [95.9, 271.0], [96.0, 272.0], [96.1, 274.0], [96.2, 276.0], [96.3, 277.0], [96.4, 279.0], [96.5, 281.0], [96.6, 282.0], [96.7, 284.0], [96.8, 286.0], [96.9, 289.0], [97.0, 291.0], [97.1, 293.0], [97.2, 295.0], [97.3, 297.0], [97.4, 299.0], [97.5, 302.0], [97.6, 306.0], [97.7, 309.0], [97.8, 312.0], [97.9, 315.0], [98.0, 318.0], [98.1, 322.0], [98.2, 325.0], [98.3, 329.0], [98.4, 333.0], [98.5, 337.0], [98.6, 343.0], [98.7, 349.0], [98.8, 354.0], [98.9, 362.0], [99.0, 370.0], [99.1, 378.0], [99.2, 388.0], [99.3, 399.0], [99.4, 412.0], [99.5, 432.0], [99.6, 456.0], [99.7, 482.0], [99.8, 524.0], [99.9, 585.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 26949.0, "series": [{"data": [[0.0, 18199.0], [300.0, 995.0], [600.0, 29.0], [700.0, 19.0], [100.0, 26949.0], [200.0, 5820.0], [400.0, 234.0], [800.0, 1.0], [500.0, 79.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 800.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 126.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 52199.0, "series": [{"data": [[0.0, 52199.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 126.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 79.71975199291425, "minX": 1.79070174E12, "maxY": 99.86148629556372, "series": [{"data": [[1.79070174E12, 79.71975199291425], [1.7907018E12, 99.86148629556372]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7907018E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 13.2, "minX": 1.0, "maxY": 233.48275862068968, "series": [{"data": [[2.0, 32.93333333333333], [3.0, 13.2], [4.0, 17.333333333333332], [5.0, 23.32], [6.0, 20.482142857142858], [7.0, 35.82857142857142], [8.0, 41.87878787878788], [9.0, 59.525000000000006], [10.0, 58.83783783783784], [11.0, 39.81132075471698], [12.0, 46.75471698113208], [13.0, 63.14634146341464], [14.0, 76.55555555555556], [15.0, 79.83720930232559], [16.0, 55.1639344262295], [17.0, 57.79999999999999], [18.0, 70.00000000000001], [19.0, 64.36666666666666], [20.0, 86.39024390243902], [21.0, 119.70000000000002], [22.0, 105.2954545454545], [23.0, 96.21428571428568], [24.0, 91.71666666666665], [25.0, 88.30666666666667], [26.0, 64.45054945054945], [27.0, 65.05063291139241], [28.0, 64.29411764705883], [29.0, 70.88461538461537], [30.0, 68.41379310344827], [31.0, 63.83695652173913], [32.0, 72.57471264367817], [33.0, 91.67500000000003], [34.0, 78.1341463414634], [35.0, 109.44615384615388], [36.0, 102.89610389610387], [37.0, 79.02564102564102], [38.0, 76.7543859649123], [39.0, 84.82795698924731], [40.0, 104.73239436619718], [41.0, 89.81052631578949], [42.0, 95.15116279069763], [43.0, 105.07792207792208], [44.0, 87.51401869158879], [45.0, 80.44144144144144], [46.0, 78.13709677419351], [47.0, 91.67021276595742], [48.0, 131.08928571428572], [49.0, 126.15151515151514], [50.0, 71.7536231884058], [51.0, 90.57894736842104], [52.0, 101.36046511627909], [53.0, 168.75925925925932], [54.0, 131.91666666666663], [55.0, 94.05000000000001], [56.0, 91.69747899159664], [57.0, 100.44915254237291], [58.0, 94.78358208955224], [59.0, 103.84615384615378], [60.0, 124.23595505617976], [61.0, 130.90816326530617], [62.0, 128.2755102040816], [63.0, 156.47435897435892], [64.0, 159.77272727272728], [65.0, 233.48275862068968], [66.0, 156.54782608695646], [67.0, 122.5858585858586], [68.0, 192.35135135135135], [69.0, 136.98076923076925], [70.0, 138.9807692307692], [71.0, 150.63855421686745], [72.0, 131.6952380952381], [73.0, 177.03571428571428], [74.0, 150.8559322033898], [75.0, 167.45762711864404], [76.0, 214.48333333333335], [77.0, 160.9916666666667], [78.0, 138.7368421052632], [79.0, 154.17460317460325], [80.0, 126.09374999999996], [81.0, 182.5576923076923], [82.0, 200.8695652173914], [83.0, 179.8484848484849], [84.0, 166.3411764705882], [85.0, 166.06451612903228], [86.0, 155.5757575757576], [87.0, 208.92105263157893], [88.0, 199.9347826086957], [89.0, 204.21428571428567], [90.0, 141.69767441860466], [91.0, 183.82075471698113], [92.0, 184.30107526881733], [93.0, 179.87155963302763], [94.0, 164.06603773584902], [95.0, 143.12328767123282], [96.0, 148.0075187969925], [97.0, 150.36567164179104], [98.0, 143.04424778761063], [99.0, 172.02500000000006], [100.0, 136.06510753053868], [1.0, 118.0]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[93.34258958432879, 133.59564261825034]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 132093.0, "minX": 1.79070174E12, "maxY": 327599.9, "series": [{"data": [[1.79070174E12, 156788.35], [1.7907018E12, 327599.9]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79070174E12, 132093.0], [1.7907018E12, 276042.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7907018E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 128.44933597061342, "minX": 1.79070174E12, "maxY": 144.3501623855919, "series": [{"data": [[1.79070174E12, 144.3501623855919], [1.7907018E12, 128.44933597061342]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7907018E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 127.32545916925724, "minX": 1.79070174E12, "maxY": 142.94467080011836, "series": [{"data": [[1.79070174E12, 142.94467080011836], [1.7907018E12, 127.32545916925724]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7907018E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.007290194970330597, "minX": 1.79070174E12, "maxY": 0.023088278712724904, "series": [{"data": [[1.79070174E12, 0.023088278712724904], [1.7907018E12, 0.007290194970330597]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7907018E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 9.0, "minX": 1.79070174E12, "maxY": 806.0, "series": [{"data": [[1.79070174E12, 806.0], [1.7907018E12, 706.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79070174E12, 247.0], [1.7907018E12, 194.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79070174E12, 427.0], [1.7907018E12, 302.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79070174E12, 294.0], [1.7907018E12, 228.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79070174E12, 9.0], [1.7907018E12, 16.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79070174E12, 127.0], [1.7907018E12, 111.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7907018E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 13.0, "minX": 27.0, "maxY": 276.0, "series": [{"data": [[514.0, 177.0], [517.0, 177.0], [544.0, 92.5], [573.0, 160.0], [547.0, 147.0], [566.0, 168.0], [606.0, 136.0], [578.0, 164.0], [593.0, 141.0], [602.0, 148.5], [621.0, 135.0], [618.0, 139.5], [615.0, 154.0], [628.0, 147.0], [642.0, 139.0], [643.0, 136.0], [656.0, 160.0], [663.0, 138.0], [671.0, 146.0], [689.0, 137.0], [688.0, 140.0], [691.0, 145.0], [709.0, 128.0], [712.0, 123.0], [763.0, 123.0], [760.0, 119.0], [739.0, 121.0], [759.0, 122.0], [794.0, 122.5], [799.0, 111.0], [778.0, 116.0], [792.0, 117.0], [795.0, 114.0], [814.0, 118.0], [810.0, 116.0], [830.0, 112.0], [812.0, 106.0], [828.0, 116.0], [854.0, 113.0], [856.0, 113.0], [861.0, 107.0], [851.0, 110.0], [859.0, 106.0], [875.0, 102.0], [868.0, 106.0], [883.0, 103.0], [904.0, 106.5], [896.0, 101.0], [920.0, 99.0], [936.0, 101.0], [946.0, 97.0], [976.0, 97.0], [1047.0, 94.0], [1031.0, 93.0], [27.0, 13.0], [212.0, 45.0], [221.0, 19.0], [229.0, 63.0], [226.0, 78.5], [326.0, 276.0], [351.0, 68.0], [373.0, 138.0], [393.0, 248.0], [411.0, 86.0], [426.0, 65.0], [422.0, 85.5], [434.0, 99.0], [459.0, 155.0], [456.0, 152.0], [477.0, 92.0], [468.0, 178.5], [479.0, 201.0], [492.0, 136.0], [484.0, 162.0], [494.0, 206.5], [503.0, 83.0], [500.0, 118.0], [501.0, 178.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1047.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 13.0, "minX": 27.0, "maxY": 276.0, "series": [{"data": [[514.0, 175.5], [517.0, 176.0], [544.0, 91.0], [573.0, 158.0], [547.0, 145.0], [566.0, 167.0], [606.0, 135.0], [578.0, 163.0], [593.0, 140.0], [602.0, 146.0], [621.0, 133.0], [618.0, 139.0], [615.0, 153.0], [628.0, 146.0], [642.0, 137.0], [643.0, 134.0], [656.0, 159.0], [663.0, 137.0], [671.0, 146.0], [689.0, 135.0], [688.0, 138.0], [691.0, 144.0], [709.0, 127.0], [712.0, 122.0], [763.0, 122.0], [760.0, 117.0], [739.0, 119.0], [759.0, 121.0], [794.0, 121.0], [799.0, 110.0], [778.0, 115.0], [792.0, 116.0], [795.0, 112.0], [814.0, 117.0], [810.0, 115.0], [830.0, 111.0], [812.0, 105.0], [828.0, 115.0], [854.0, 112.0], [856.0, 112.0], [861.0, 106.0], [851.0, 110.0], [859.0, 105.0], [875.0, 100.0], [868.0, 105.0], [883.0, 102.0], [904.0, 105.0], [896.0, 100.0], [920.0, 98.0], [936.0, 101.0], [946.0, 96.0], [976.0, 95.0], [1047.0, 92.0], [1031.0, 92.0], [27.0, 13.0], [212.0, 44.0], [221.0, 19.0], [229.0, 60.0], [226.0, 76.0], [326.0, 276.0], [351.0, 67.0], [373.0, 133.0], [393.0, 246.0], [411.0, 86.0], [426.0, 64.0], [422.0, 85.0], [434.0, 98.0], [459.0, 155.0], [456.0, 151.0], [477.0, 92.0], [468.0, 177.5], [479.0, 199.0], [492.0, 133.0], [484.0, 160.5], [494.0, 206.0], [503.0, 82.0], [500.0, 117.0], [501.0, 176.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1047.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 283.9166666666667, "minX": 1.79070174E12, "maxY": 588.1666666666666, "series": [{"data": [[1.79070174E12, 283.9166666666667], [1.7907018E12, 588.1666666666666]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7907018E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 282.25, "minX": 1.79070174E12, "maxY": 589.8333333333334, "series": [{"data": [[1.79070174E12, 282.25], [1.7907018E12, 589.8333333333334]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7907018E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 282.25, "minX": 1.79070174E12, "maxY": 589.8333333333334, "series": [{"data": [[1.79070174E12, 282.25], [1.7907018E12, 589.8333333333334]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7907018E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 282.25, "minX": 1.79070174E12, "maxY": 589.8333333333334, "series": [{"data": [[1.79070174E12, 282.25], [1.7907018E12, 589.8333333333334]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7907018E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

