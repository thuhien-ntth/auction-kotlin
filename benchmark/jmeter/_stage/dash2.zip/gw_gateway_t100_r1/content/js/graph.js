/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 7.0, "minX": 0.0, "maxY": 747.0, "series": [{"data": [[0.0, 7.0], [0.1, 13.0], [0.2, 17.0], [0.3, 19.0], [0.4, 22.0], [0.5, 23.0], [0.6, 25.0], [0.7, 26.0], [0.8, 28.0], [0.9, 29.0], [1.0, 30.0], [1.1, 31.0], [1.2, 32.0], [1.3, 32.0], [1.4, 33.0], [1.5, 34.0], [1.6, 35.0], [1.7, 35.0], [1.8, 36.0], [1.9, 36.0], [2.0, 37.0], [2.1, 37.0], [2.2, 38.0], [2.3, 38.0], [2.4, 39.0], [2.5, 39.0], [2.6, 39.0], [2.7, 40.0], [2.8, 40.0], [2.9, 41.0], [3.0, 41.0], [3.1, 41.0], [3.2, 42.0], [3.3, 42.0], [3.4, 42.0], [3.5, 43.0], [3.6, 43.0], [3.7, 43.0], [3.8, 44.0], [3.9, 44.0], [4.0, 44.0], [4.1, 45.0], [4.2, 45.0], [4.3, 45.0], [4.4, 46.0], [4.5, 46.0], [4.6, 46.0], [4.7, 46.0], [4.8, 47.0], [4.9, 47.0], [5.0, 47.0], [5.1, 47.0], [5.2, 48.0], [5.3, 48.0], [5.4, 48.0], [5.5, 48.0], [5.6, 49.0], [5.7, 49.0], [5.8, 49.0], [5.9, 49.0], [6.0, 49.0], [6.1, 50.0], [6.2, 50.0], [6.3, 50.0], [6.4, 50.0], [6.5, 50.0], [6.6, 51.0], [6.7, 51.0], [6.8, 51.0], [6.9, 51.0], [7.0, 51.0], [7.1, 52.0], [7.2, 52.0], [7.3, 52.0], [7.4, 52.0], [7.5, 52.0], [7.6, 52.0], [7.7, 53.0], [7.8, 53.0], [7.9, 53.0], [8.0, 53.0], [8.1, 53.0], [8.2, 54.0], [8.3, 54.0], [8.4, 54.0], [8.5, 54.0], [8.6, 54.0], [8.7, 54.0], [8.8, 55.0], [8.9, 55.0], [9.0, 55.0], [9.1, 55.0], [9.2, 55.0], [9.3, 55.0], [9.4, 55.0], [9.5, 56.0], [9.6, 56.0], [9.7, 56.0], [9.8, 56.0], [9.9, 56.0], [10.0, 56.0], [10.1, 57.0], [10.2, 57.0], [10.3, 57.0], [10.4, 57.0], [10.5, 57.0], [10.6, 57.0], [10.7, 57.0], [10.8, 58.0], [10.9, 58.0], [11.0, 58.0], [11.1, 58.0], [11.2, 58.0], [11.3, 58.0], [11.4, 58.0], [11.5, 59.0], [11.6, 59.0], [11.7, 59.0], [11.8, 59.0], [11.9, 59.0], [12.0, 59.0], [12.1, 59.0], [12.2, 59.0], [12.3, 60.0], [12.4, 60.0], [12.5, 60.0], [12.6, 60.0], [12.7, 60.0], [12.8, 60.0], [12.9, 60.0], [13.0, 61.0], [13.1, 61.0], [13.2, 61.0], [13.3, 61.0], [13.4, 61.0], [13.5, 61.0], [13.6, 61.0], [13.7, 61.0], [13.8, 62.0], [13.9, 62.0], [14.0, 62.0], [14.1, 62.0], [14.2, 62.0], [14.3, 62.0], [14.4, 62.0], [14.5, 62.0], [14.6, 63.0], [14.7, 63.0], [14.8, 63.0], [14.9, 63.0], [15.0, 63.0], [15.1, 63.0], [15.2, 63.0], [15.3, 63.0], [15.4, 64.0], [15.5, 64.0], [15.6, 64.0], [15.7, 64.0], [15.8, 64.0], [15.9, 64.0], [16.0, 64.0], [16.1, 64.0], [16.2, 64.0], [16.3, 65.0], [16.4, 65.0], [16.5, 65.0], [16.6, 65.0], [16.7, 65.0], [16.8, 65.0], [16.9, 65.0], [17.0, 65.0], [17.1, 65.0], [17.2, 66.0], [17.3, 66.0], [17.4, 66.0], [17.5, 66.0], [17.6, 66.0], [17.7, 66.0], [17.8, 66.0], [17.9, 66.0], [18.0, 66.0], [18.1, 66.0], [18.2, 67.0], [18.3, 67.0], [18.4, 67.0], [18.5, 67.0], [18.6, 67.0], [18.7, 67.0], [18.8, 67.0], [18.9, 67.0], [19.0, 67.0], [19.1, 67.0], [19.2, 68.0], [19.3, 68.0], [19.4, 68.0], [19.5, 68.0], [19.6, 68.0], [19.7, 68.0], [19.8, 68.0], [19.9, 68.0], [20.0, 68.0], [20.1, 68.0], [20.2, 69.0], [20.3, 69.0], [20.4, 69.0], [20.5, 69.0], [20.6, 69.0], [20.7, 69.0], [20.8, 69.0], [20.9, 69.0], [21.0, 69.0], [21.1, 70.0], [21.2, 70.0], [21.3, 70.0], [21.4, 70.0], [21.5, 70.0], [21.6, 70.0], [21.7, 70.0], [21.8, 70.0], [21.9, 70.0], [22.0, 70.0], [22.1, 71.0], [22.2, 71.0], [22.3, 71.0], [22.4, 71.0], [22.5, 71.0], [22.6, 71.0], [22.7, 71.0], [22.8, 71.0], [22.9, 71.0], [23.0, 71.0], [23.1, 71.0], [23.2, 72.0], [23.3, 72.0], [23.4, 72.0], [23.5, 72.0], [23.6, 72.0], [23.7, 72.0], [23.8, 72.0], [23.9, 72.0], [24.0, 72.0], [24.1, 72.0], [24.2, 73.0], [24.3, 73.0], [24.4, 73.0], [24.5, 73.0], [24.6, 73.0], [24.7, 73.0], [24.8, 73.0], [24.9, 73.0], [25.0, 73.0], [25.1, 73.0], [25.2, 74.0], [25.3, 74.0], [25.4, 74.0], [25.5, 74.0], [25.6, 74.0], [25.7, 74.0], [25.8, 74.0], [25.9, 74.0], [26.0, 74.0], [26.1, 74.0], [26.2, 74.0], [26.3, 75.0], [26.4, 75.0], [26.5, 75.0], [26.6, 75.0], [26.7, 75.0], [26.8, 75.0], [26.9, 75.0], [27.0, 75.0], [27.1, 75.0], [27.2, 75.0], [27.3, 75.0], [27.4, 76.0], [27.5, 76.0], [27.6, 76.0], [27.7, 76.0], [27.8, 76.0], [27.9, 76.0], [28.0, 76.0], [28.1, 76.0], [28.2, 76.0], [28.3, 76.0], [28.4, 76.0], [28.5, 77.0], [28.6, 77.0], [28.7, 77.0], [28.8, 77.0], [28.9, 77.0], [29.0, 77.0], [29.1, 77.0], [29.2, 77.0], [29.3, 77.0], [29.4, 77.0], [29.5, 77.0], [29.6, 78.0], [29.7, 78.0], [29.8, 78.0], [29.9, 78.0], [30.0, 78.0], [30.1, 78.0], [30.2, 78.0], [30.3, 78.0], [30.4, 78.0], [30.5, 78.0], [30.6, 78.0], [30.7, 79.0], [30.8, 79.0], [30.9, 79.0], [31.0, 79.0], [31.1, 79.0], [31.2, 79.0], [31.3, 79.0], [31.4, 79.0], [31.5, 79.0], [31.6, 79.0], [31.7, 80.0], [31.8, 80.0], [31.9, 80.0], [32.0, 80.0], [32.1, 80.0], [32.2, 80.0], [32.3, 80.0], [32.4, 80.0], [32.5, 80.0], [32.6, 80.0], [32.7, 81.0], [32.8, 81.0], [32.9, 81.0], [33.0, 81.0], [33.1, 81.0], [33.2, 81.0], [33.3, 81.0], [33.4, 81.0], [33.5, 81.0], [33.6, 81.0], [33.7, 81.0], [33.8, 82.0], [33.9, 82.0], [34.0, 82.0], [34.1, 82.0], [34.2, 82.0], [34.3, 82.0], [34.4, 82.0], [34.5, 82.0], [34.6, 82.0], [34.7, 83.0], [34.8, 83.0], [34.9, 83.0], [35.0, 83.0], [35.1, 83.0], [35.2, 83.0], [35.3, 83.0], [35.4, 83.0], [35.5, 83.0], [35.6, 83.0], [35.7, 83.0], [35.8, 84.0], [35.9, 84.0], [36.0, 84.0], [36.1, 84.0], [36.2, 84.0], [36.3, 84.0], [36.4, 84.0], [36.5, 84.0], [36.6, 84.0], [36.7, 84.0], [36.8, 85.0], [36.9, 85.0], [37.0, 85.0], [37.1, 85.0], [37.2, 85.0], [37.3, 85.0], [37.4, 85.0], [37.5, 85.0], [37.6, 85.0], [37.7, 85.0], [37.8, 85.0], [37.9, 86.0], [38.0, 86.0], [38.1, 86.0], [38.2, 86.0], [38.3, 86.0], [38.4, 86.0], [38.5, 86.0], [38.6, 86.0], [38.7, 86.0], [38.8, 86.0], [38.9, 86.0], [39.0, 87.0], [39.1, 87.0], [39.2, 87.0], [39.3, 87.0], [39.4, 87.0], [39.5, 87.0], [39.6, 87.0], [39.7, 87.0], [39.8, 87.0], [39.9, 87.0], [40.0, 87.0], [40.1, 88.0], [40.2, 88.0], [40.3, 88.0], [40.4, 88.0], [40.5, 88.0], [40.6, 88.0], [40.7, 88.0], [40.8, 88.0], [40.9, 88.0], [41.0, 88.0], [41.1, 89.0], [41.2, 89.0], [41.3, 89.0], [41.4, 89.0], [41.5, 89.0], [41.6, 89.0], [41.7, 89.0], [41.8, 89.0], [41.9, 89.0], [42.0, 89.0], [42.1, 89.0], [42.2, 90.0], [42.3, 90.0], [42.4, 90.0], [42.5, 90.0], [42.6, 90.0], [42.7, 90.0], [42.8, 90.0], [42.9, 90.0], [43.0, 90.0], [43.1, 90.0], [43.2, 91.0], [43.3, 91.0], [43.4, 91.0], [43.5, 91.0], [43.6, 91.0], [43.7, 91.0], [43.8, 91.0], [43.9, 91.0], [44.0, 91.0], [44.1, 91.0], [44.2, 91.0], [44.3, 92.0], [44.4, 92.0], [44.5, 92.0], [44.6, 92.0], [44.7, 92.0], [44.8, 92.0], [44.9, 92.0], [45.0, 92.0], [45.1, 92.0], [45.2, 92.0], [45.3, 93.0], [45.4, 93.0], [45.5, 93.0], [45.6, 93.0], [45.7, 93.0], [45.8, 93.0], [45.9, 93.0], [46.0, 93.0], [46.1, 93.0], [46.2, 93.0], [46.3, 94.0], [46.4, 94.0], [46.5, 94.0], [46.6, 94.0], [46.7, 94.0], [46.8, 94.0], [46.9, 94.0], [47.0, 94.0], [47.1, 94.0], [47.2, 94.0], [47.3, 95.0], [47.4, 95.0], [47.5, 95.0], [47.6, 95.0], [47.7, 95.0], [47.8, 95.0], [47.9, 95.0], [48.0, 95.0], [48.1, 95.0], [48.2, 95.0], [48.3, 96.0], [48.4, 96.0], [48.5, 96.0], [48.6, 96.0], [48.7, 96.0], [48.8, 96.0], [48.9, 96.0], [49.0, 96.0], [49.1, 96.0], [49.2, 96.0], [49.3, 96.0], [49.4, 97.0], [49.5, 97.0], [49.6, 97.0], [49.7, 97.0], [49.8, 97.0], [49.9, 97.0], [50.0, 97.0], [50.1, 97.0], [50.2, 97.0], [50.3, 97.0], [50.4, 98.0], [50.5, 98.0], [50.6, 98.0], [50.7, 98.0], [50.8, 98.0], [50.9, 98.0], [51.0, 98.0], [51.1, 98.0], [51.2, 98.0], [51.3, 99.0], [51.4, 99.0], [51.5, 99.0], [51.6, 99.0], [51.7, 99.0], [51.8, 99.0], [51.9, 99.0], [52.0, 99.0], [52.1, 99.0], [52.2, 100.0], [52.3, 100.0], [52.4, 100.0], [52.5, 100.0], [52.6, 100.0], [52.7, 100.0], [52.8, 100.0], [52.9, 100.0], [53.0, 100.0], [53.1, 101.0], [53.2, 101.0], [53.3, 101.0], [53.4, 101.0], [53.5, 101.0], [53.6, 101.0], [53.7, 101.0], [53.8, 101.0], [53.9, 101.0], [54.0, 102.0], [54.1, 102.0], [54.2, 102.0], [54.3, 102.0], [54.4, 102.0], [54.5, 102.0], [54.6, 102.0], [54.7, 102.0], [54.8, 102.0], [54.9, 103.0], [55.0, 103.0], [55.1, 103.0], [55.2, 103.0], [55.3, 103.0], [55.4, 103.0], [55.5, 103.0], [55.6, 103.0], [55.7, 103.0], [55.8, 104.0], [55.9, 104.0], [56.0, 104.0], [56.1, 104.0], [56.2, 104.0], [56.3, 104.0], [56.4, 104.0], [56.5, 104.0], [56.6, 104.0], [56.7, 105.0], [56.8, 105.0], [56.9, 105.0], [57.0, 105.0], [57.1, 105.0], [57.2, 105.0], [57.3, 105.0], [57.4, 105.0], [57.5, 105.0], [57.6, 106.0], [57.7, 106.0], [57.8, 106.0], [57.9, 106.0], [58.0, 106.0], [58.1, 106.0], [58.2, 106.0], [58.3, 106.0], [58.4, 107.0], [58.5, 107.0], [58.6, 107.0], [58.7, 107.0], [58.8, 107.0], [58.9, 107.0], [59.0, 107.0], [59.1, 107.0], [59.2, 107.0], [59.3, 107.0], [59.4, 108.0], [59.5, 108.0], [59.6, 108.0], [59.7, 108.0], [59.8, 108.0], [59.9, 108.0], [60.0, 108.0], [60.1, 108.0], [60.2, 109.0], [60.3, 109.0], [60.4, 109.0], [60.5, 109.0], [60.6, 109.0], [60.7, 109.0], [60.8, 109.0], [60.9, 109.0], [61.0, 109.0], [61.1, 110.0], [61.2, 110.0], [61.3, 110.0], [61.4, 110.0], [61.5, 110.0], [61.6, 110.0], [61.7, 110.0], [61.8, 111.0], [61.9, 111.0], [62.0, 111.0], [62.1, 111.0], [62.2, 111.0], [62.3, 111.0], [62.4, 111.0], [62.5, 111.0], [62.6, 112.0], [62.7, 112.0], [62.8, 112.0], [62.9, 112.0], [63.0, 112.0], [63.1, 112.0], [63.2, 112.0], [63.3, 113.0], [63.4, 113.0], [63.5, 113.0], [63.6, 113.0], [63.7, 113.0], [63.8, 113.0], [63.9, 113.0], [64.0, 114.0], [64.1, 114.0], [64.2, 114.0], [64.3, 114.0], [64.4, 114.0], [64.5, 114.0], [64.6, 114.0], [64.7, 114.0], [64.8, 115.0], [64.9, 115.0], [65.0, 115.0], [65.1, 115.0], [65.2, 115.0], [65.3, 115.0], [65.4, 115.0], [65.5, 116.0], [65.6, 116.0], [65.7, 116.0], [65.8, 116.0], [65.9, 116.0], [66.0, 116.0], [66.1, 116.0], [66.2, 117.0], [66.3, 117.0], [66.4, 117.0], [66.5, 117.0], [66.6, 117.0], [66.7, 117.0], [66.8, 118.0], [66.9, 118.0], [67.0, 118.0], [67.1, 118.0], [67.2, 118.0], [67.3, 118.0], [67.4, 118.0], [67.5, 119.0], [67.6, 119.0], [67.7, 119.0], [67.8, 119.0], [67.9, 119.0], [68.0, 119.0], [68.1, 119.0], [68.2, 120.0], [68.3, 120.0], [68.4, 120.0], [68.5, 120.0], [68.6, 120.0], [68.7, 120.0], [68.8, 121.0], [68.9, 121.0], [69.0, 121.0], [69.1, 121.0], [69.2, 121.0], [69.3, 121.0], [69.4, 122.0], [69.5, 122.0], [69.6, 122.0], [69.7, 122.0], [69.8, 122.0], [69.9, 122.0], [70.0, 123.0], [70.1, 123.0], [70.2, 123.0], [70.3, 123.0], [70.4, 123.0], [70.5, 123.0], [70.6, 123.0], [70.7, 124.0], [70.8, 124.0], [70.9, 124.0], [71.0, 124.0], [71.1, 124.0], [71.2, 125.0], [71.3, 125.0], [71.4, 125.0], [71.5, 125.0], [71.6, 125.0], [71.7, 125.0], [71.8, 126.0], [71.9, 126.0], [72.0, 126.0], [72.1, 126.0], [72.2, 126.0], [72.3, 126.0], [72.4, 127.0], [72.5, 127.0], [72.6, 127.0], [72.7, 127.0], [72.8, 127.0], [72.9, 127.0], [73.0, 128.0], [73.1, 128.0], [73.2, 128.0], [73.3, 128.0], [73.4, 128.0], [73.5, 128.0], [73.6, 129.0], [73.7, 129.0], [73.8, 129.0], [73.9, 129.0], [74.0, 129.0], [74.1, 130.0], [74.2, 130.0], [74.3, 130.0], [74.4, 130.0], [74.5, 130.0], [74.6, 130.0], [74.7, 131.0], [74.8, 131.0], [74.9, 131.0], [75.0, 131.0], [75.1, 131.0], [75.2, 131.0], [75.3, 132.0], [75.4, 132.0], [75.5, 132.0], [75.6, 132.0], [75.7, 132.0], [75.8, 133.0], [75.9, 133.0], [76.0, 133.0], [76.1, 133.0], [76.2, 133.0], [76.3, 134.0], [76.4, 134.0], [76.5, 134.0], [76.6, 134.0], [76.7, 134.0], [76.8, 134.0], [76.9, 135.0], [77.0, 135.0], [77.1, 135.0], [77.2, 135.0], [77.3, 135.0], [77.4, 136.0], [77.5, 136.0], [77.6, 136.0], [77.7, 136.0], [77.8, 137.0], [77.9, 137.0], [78.0, 137.0], [78.1, 137.0], [78.2, 137.0], [78.3, 138.0], [78.4, 138.0], [78.5, 138.0], [78.6, 138.0], [78.7, 139.0], [78.8, 139.0], [78.9, 139.0], [79.0, 139.0], [79.1, 140.0], [79.2, 140.0], [79.3, 140.0], [79.4, 140.0], [79.5, 140.0], [79.6, 141.0], [79.7, 141.0], [79.8, 141.0], [79.9, 141.0], [80.0, 142.0], [80.1, 142.0], [80.2, 142.0], [80.3, 142.0], [80.4, 143.0], [80.5, 143.0], [80.6, 143.0], [80.7, 143.0], [80.8, 144.0], [80.9, 144.0], [81.0, 144.0], [81.1, 145.0], [81.2, 145.0], [81.3, 145.0], [81.4, 145.0], [81.5, 146.0], [81.6, 146.0], [81.7, 146.0], [81.8, 147.0], [81.9, 147.0], [82.0, 147.0], [82.1, 147.0], [82.2, 148.0], [82.3, 148.0], [82.4, 148.0], [82.5, 148.0], [82.6, 149.0], [82.7, 149.0], [82.8, 149.0], [82.9, 150.0], [83.0, 150.0], [83.1, 150.0], [83.2, 151.0], [83.3, 151.0], [83.4, 151.0], [83.5, 152.0], [83.6, 152.0], [83.7, 152.0], [83.8, 153.0], [83.9, 153.0], [84.0, 153.0], [84.1, 154.0], [84.2, 154.0], [84.3, 154.0], [84.4, 155.0], [84.5, 155.0], [84.6, 155.0], [84.7, 156.0], [84.8, 156.0], [84.9, 157.0], [85.0, 157.0], [85.1, 157.0], [85.2, 158.0], [85.3, 158.0], [85.4, 158.0], [85.5, 159.0], [85.6, 159.0], [85.7, 160.0], [85.8, 160.0], [85.9, 160.0], [86.0, 161.0], [86.1, 161.0], [86.2, 162.0], [86.3, 162.0], [86.4, 162.0], [86.5, 163.0], [86.6, 163.0], [86.7, 164.0], [86.8, 164.0], [86.9, 165.0], [87.0, 165.0], [87.1, 165.0], [87.2, 166.0], [87.3, 166.0], [87.4, 167.0], [87.5, 167.0], [87.6, 167.0], [87.7, 168.0], [87.8, 168.0], [87.9, 169.0], [88.0, 169.0], [88.1, 170.0], [88.2, 170.0], [88.3, 171.0], [88.4, 171.0], [88.5, 172.0], [88.6, 172.0], [88.7, 173.0], [88.8, 173.0], [88.9, 174.0], [89.0, 174.0], [89.1, 175.0], [89.2, 175.0], [89.3, 176.0], [89.4, 176.0], [89.5, 177.0], [89.6, 178.0], [89.7, 178.0], [89.8, 179.0], [89.9, 179.0], [90.0, 180.0], [90.1, 180.0], [90.2, 181.0], [90.3, 182.0], [90.4, 182.0], [90.5, 183.0], [90.6, 183.0], [90.7, 184.0], [90.8, 184.0], [90.9, 185.0], [91.0, 186.0], [91.1, 187.0], [91.2, 187.0], [91.3, 188.0], [91.4, 188.0], [91.5, 189.0], [91.6, 190.0], [91.7, 190.0], [91.8, 191.0], [91.9, 192.0], [92.0, 192.0], [92.1, 193.0], [92.2, 194.0], [92.3, 195.0], [92.4, 195.0], [92.5, 196.0], [92.6, 197.0], [92.7, 198.0], [92.8, 198.0], [92.9, 199.0], [93.0, 200.0], [93.1, 201.0], [93.2, 202.0], [93.3, 203.0], [93.4, 204.0], [93.5, 205.0], [93.6, 206.0], [93.7, 207.0], [93.8, 208.0], [93.9, 209.0], [94.0, 210.0], [94.1, 211.0], [94.2, 213.0], [94.3, 213.0], [94.4, 214.0], [94.5, 216.0], [94.6, 217.0], [94.7, 218.0], [94.8, 220.0], [94.9, 221.0], [95.0, 222.0], [95.1, 223.0], [95.2, 224.0], [95.3, 225.0], [95.4, 227.0], [95.5, 228.0], [95.6, 230.0], [95.7, 232.0], [95.8, 233.0], [95.9, 235.0], [96.0, 237.0], [96.1, 238.0], [96.2, 240.0], [96.3, 241.0], [96.4, 243.0], [96.5, 245.0], [96.6, 247.0], [96.7, 250.0], [96.8, 252.0], [96.9, 255.0], [97.0, 257.0], [97.1, 259.0], [97.2, 262.0], [97.3, 265.0], [97.4, 268.0], [97.5, 271.0], [97.6, 273.0], [97.7, 277.0], [97.8, 280.0], [97.9, 283.0], [98.0, 287.0], [98.1, 291.0], [98.2, 295.0], [98.3, 299.0], [98.4, 306.0], [98.5, 312.0], [98.6, 318.0], [98.7, 324.0], [98.8, 333.0], [98.9, 340.0], [99.0, 350.0], [99.1, 361.0], [99.2, 373.0], [99.3, 382.0], [99.4, 396.0], [99.5, 413.0], [99.6, 437.0], [99.7, 464.0], [99.8, 482.0], [99.9, 540.0], [100.0, 747.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 17.0, "minX": 0.0, "maxY": 30454.0, "series": [{"data": [[0.0, 30454.0], [300.0, 659.0], [600.0, 23.0], [700.0, 17.0], [100.0, 23808.0], [200.0, 3125.0], [400.0, 239.0], [500.0, 54.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 700.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 94.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 58285.0, "series": [{"data": [[0.0, 58285.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 94.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 25.871104067617566, "minX": 1.79070372E12, "maxY": 99.15202815957089, "series": [{"data": [[1.79070378E12, 97.89798099762481], [1.79070372E12, 25.871104067617566], [1.79070384E12, 99.15202815957089]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070384E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 15.6, "minX": 3.0, "maxY": 182.05660377358495, "series": [{"data": [[3.0, 34.00000000000001], [4.0, 21.41463414634146], [5.0, 15.6], [6.0, 18.13793103448276], [7.0, 34.42424242424242], [8.0, 27.366666666666667], [9.0, 39.086956521739125], [10.0, 24.249999999999996], [11.0, 26.348837209302317], [12.0, 30.22222222222222], [13.0, 44.02777777777777], [14.0, 38.63636363636364], [15.0, 27.9375], [16.0, 49.44444444444445], [17.0, 37.18], [18.0, 32.777777777777786], [19.0, 48.37500000000001], [20.0, 41.34615384615385], [21.0, 45.23255813953489], [22.0, 58.86111111111111], [23.0, 47.6], [24.0, 60.541666666666664], [25.0, 68.35483870967742], [26.0, 64.19642857142858], [27.0, 57.650000000000006], [28.0, 55.60655737704919], [29.0, 46.52307692307693], [30.0, 51.56818181818181], [31.0, 60.63934426229508], [32.0, 74.93749999999999], [33.0, 66.96000000000001], [34.0, 74.38461538461539], [35.0, 66.99999999999996], [36.0, 69.40540540540542], [37.0, 66.35820895522386], [38.0, 62.33870967741936], [39.0, 75.40425531914896], [40.0, 61.09638554216867], [41.0, 42.69387755102039], [42.0, 62.8888888888889], [43.0, 74.11320754716981], [44.0, 90.07317073170732], [45.0, 83.81428571428567], [46.0, 72.09836065573766], [47.0, 77.09090909090911], [48.0, 109.60377358490567], [49.0, 85.3333333333333], [50.0, 76.37735849056605], [51.0, 74.16091954022987], [52.0, 69.50000000000003], [53.0, 87.14285714285715], [54.0, 94.02739726027399], [55.0, 78.57575757575758], [56.0, 69.4342105263158], [57.0, 70.08], [58.0, 99.65116279069768], [59.0, 96.93589743589742], [60.0, 93.28571428571426], [61.0, 99.1470588235294], [62.0, 94.48684210526318], [63.0, 67.38000000000002], [64.0, 70.62962962962963], [65.0, 81.0246913580247], [66.0, 73.3444444444445], [67.0, 79.06818181818181], [68.0, 82.67500000000003], [69.0, 95.37499999999999], [70.0, 115.06756756756758], [71.0, 89.25806451612904], [72.0, 76.6767676767677], [73.0, 79.79000000000005], [74.0, 100.74418604651163], [75.0, 147.6530612244898], [76.0, 152.8923076923077], [77.0, 102.04109589041093], [78.0, 107.06060606060609], [79.0, 68.87387387387386], [80.0, 87.58064516129032], [81.0, 96.89772727272725], [82.0, 101.80769230769232], [83.0, 113.28169014084506], [84.0, 136.1774193548387], [85.0, 137.1090909090909], [86.0, 155.0735294117647], [87.0, 108.48484848484847], [88.0, 111.5], [89.0, 136.80303030303037], [90.0, 129.41558441558436], [91.0, 124.2337662337662], [92.0, 170.5428571428571], [93.0, 148.6666666666667], [94.0, 124.36486486486486], [95.0, 127.69090909090912], [96.0, 182.05660377358495], [97.0, 122.71559633027525], [98.0, 111.00000000000001], [99.0, 164.99999999999994], [100.0, 114.08677458010789]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[95.69059079463457, 111.13835454530032]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 14765.4, "minX": 1.79070372E12, "maxY": 462542.3, "series": [{"data": [[1.79070378E12, 462542.3], [1.79070372E12, 17339.45], [1.79070384E12, 54619.2]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79070378E12, 394056.0], [1.79070372E12, 14765.4], [1.79070384E12, 46534.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070384E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 48.7448494453249, "minX": 1.79070372E12, "maxY": 115.40352335708644, "series": [{"data": [[1.79070378E12, 115.40352335708644], [1.79070372E12, 48.7448494453249], [1.79070384E12, 94.81830372108628]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070384E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 48.103011093502325, "minX": 1.79070372E12, "maxY": 114.49075613618334, "series": [{"data": [[1.79070378E12, 114.49075613618334], [1.79070372E12, 48.103011093502325], [1.79070384E12, 94.0596714716729]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070384E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.004552652414885158, "minX": 1.79070372E12, "maxY": 0.14474379292128947, "series": [{"data": [[1.79070378E12, 0.004552652414885158], [1.79070372E12, 0.14474379292128947], [1.79070384E12, 0.0179349648005364]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070384E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 7.0, "minX": 1.79070372E12, "maxY": 747.0, "series": [{"data": [[1.79070378E12, 747.0], [1.79070372E12, 138.0], [1.79070384E12, 314.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79070378E12, 158.0], [1.79070372E12, 80.0], [1.79070384E12, 147.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79070378E12, 289.0], [1.79070372E12, 115.05999999999995], [1.79070384E12, 232.32999999999993]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79070378E12, 189.0], [1.79070372E12, 91.0], [1.79070384E12, 172.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79070378E12, 17.0], [1.79070372E12, 7.0], [1.79070384E12, 16.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79070378E12, 94.0], [1.79070372E12, 46.0], [1.79070384E12, 87.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070384E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 9.0, "minX": 19.0, "maxY": 417.0, "series": [{"data": [[514.0, 182.0], [561.0, 202.0], [606.0, 61.0], [587.0, 77.0], [625.0, 96.0], [661.0, 124.0], [701.0, 76.0], [675.0, 142.0], [696.0, 133.0], [690.0, 134.0], [677.0, 138.0], [681.0, 136.0], [724.0, 101.0], [708.0, 124.0], [759.0, 97.0], [794.0, 109.0], [806.0, 80.5], [800.0, 111.0], [827.0, 117.0], [810.0, 117.0], [854.0, 111.0], [848.0, 110.0], [841.0, 113.0], [861.0, 105.0], [869.0, 107.0], [892.0, 110.0], [917.0, 99.0], [900.0, 103.0], [906.0, 104.0], [907.0, 105.0], [905.0, 107.0], [935.0, 98.0], [986.0, 99.0], [968.0, 96.0], [984.0, 96.0], [960.0, 98.0], [1011.0, 90.0], [1016.0, 87.5], [1010.0, 94.5], [998.0, 93.0], [993.0, 96.0], [1077.0, 89.0], [1043.0, 95.0], [1035.0, 91.0], [1048.0, 88.5], [1045.0, 91.0], [1060.0, 86.0], [1059.0, 85.0], [1058.0, 87.0], [1079.0, 88.0], [1104.0, 89.0], [1113.0, 86.0], [1121.0, 82.0], [1136.0, 83.0], [1188.0, 83.0], [1169.0, 83.0], [1193.0, 73.0], [1224.0, 77.0], [1225.0, 81.0], [19.0, 9.0], [217.0, 417.0], [335.0, 23.0], [348.0, 267.5], [371.0, 238.0], [459.0, 37.0], [458.0, 219.0], [448.0, 203.5], [474.0, 57.0], [470.0, 217.5], [486.0, 193.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1225.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 9.0, "minX": 19.0, "maxY": 414.0, "series": [{"data": [[514.0, 180.5], [561.0, 200.0], [606.0, 61.0], [587.0, 76.0], [625.0, 95.0], [661.0, 123.0], [701.0, 76.0], [675.0, 142.0], [696.0, 132.0], [690.0, 133.0], [677.0, 138.0], [681.0, 135.0], [724.0, 100.0], [708.0, 123.0], [759.0, 96.0], [794.0, 108.0], [806.0, 79.0], [800.0, 110.5], [827.0, 116.0], [810.0, 117.0], [854.0, 111.0], [848.0, 109.0], [841.0, 112.0], [861.0, 104.0], [869.0, 106.0], [892.0, 110.0], [917.0, 98.0], [900.0, 101.5], [906.0, 102.0], [907.0, 104.0], [905.0, 106.0], [935.0, 97.0], [986.0, 98.0], [968.0, 95.0], [984.0, 95.5], [960.0, 97.0], [1011.0, 89.0], [1016.0, 87.0], [1010.0, 94.0], [998.0, 92.0], [993.0, 95.0], [1077.0, 88.0], [1043.0, 94.0], [1035.0, 90.0], [1048.0, 88.0], [1045.0, 90.0], [1060.0, 86.0], [1059.0, 85.0], [1058.0, 87.0], [1079.0, 88.0], [1104.0, 88.0], [1113.0, 85.0], [1121.0, 81.0], [1136.0, 82.0], [1188.0, 82.0], [1169.0, 82.0], [1193.0, 73.0], [1224.0, 77.0], [1225.0, 80.0], [19.0, 9.0], [217.0, 414.0], [335.0, 22.0], [348.0, 263.0], [371.0, 237.0], [459.0, 36.0], [458.0, 218.5], [448.0, 201.5], [474.0, 56.0], [470.0, 217.0], [486.0, 193.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1225.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 32.28333333333333, "minX": 1.79070372E12, "maxY": 842.9333333333333, "series": [{"data": [[1.79070378E12, 842.9333333333333], [1.79070372E12, 32.28333333333333], [1.79070384E12, 97.76666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070384E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 31.55, "minX": 1.79070372E12, "maxY": 842.0, "series": [{"data": [[1.79070378E12, 842.0], [1.79070372E12, 31.55], [1.79070384E12, 99.43333333333334]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79070384E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 31.55, "minX": 1.79070372E12, "maxY": 842.0, "series": [{"data": [[1.79070378E12, 842.0], [1.79070372E12, 31.55], [1.79070384E12, 99.43333333333334]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070384E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 31.55, "minX": 1.79070372E12, "maxY": 842.0, "series": [{"data": [[1.79070378E12, 842.0], [1.79070372E12, 31.55], [1.79070384E12, 99.43333333333334]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79070384E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

