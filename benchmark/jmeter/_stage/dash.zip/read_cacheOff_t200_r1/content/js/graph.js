/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 22.0, "minX": 0.0, "maxY": 2699.0, "series": [{"data": [[0.0, 22.0], [0.1, 29.0], [0.2, 35.0], [0.3, 39.0], [0.4, 41.0], [0.5, 44.0], [0.6, 45.0], [0.7, 47.0], [0.8, 48.0], [0.9, 49.0], [1.0, 51.0], [1.1, 53.0], [1.2, 54.0], [1.3, 55.0], [1.4, 56.0], [1.5, 58.0], [1.6, 59.0], [1.7, 60.0], [1.8, 61.0], [1.9, 63.0], [2.0, 64.0], [2.1, 65.0], [2.2, 66.0], [2.3, 68.0], [2.4, 69.0], [2.5, 69.0], [2.6, 71.0], [2.7, 72.0], [2.8, 73.0], [2.9, 74.0], [3.0, 75.0], [3.1, 76.0], [3.2, 78.0], [3.3, 79.0], [3.4, 80.0], [3.5, 81.0], [3.6, 83.0], [3.7, 85.0], [3.8, 86.0], [3.9, 87.0], [4.0, 89.0], [4.1, 90.0], [4.2, 91.0], [4.3, 92.0], [4.4, 93.0], [4.5, 94.0], [4.6, 96.0], [4.7, 98.0], [4.8, 99.0], [4.9, 100.0], [5.0, 101.0], [5.1, 102.0], [5.2, 104.0], [5.3, 105.0], [5.4, 106.0], [5.5, 107.0], [5.6, 108.0], [5.7, 109.0], [5.8, 110.0], [5.9, 111.0], [6.0, 113.0], [6.1, 114.0], [6.2, 115.0], [6.3, 116.0], [6.4, 118.0], [6.5, 120.0], [6.6, 121.0], [6.7, 122.0], [6.8, 123.0], [6.9, 124.0], [7.0, 125.0], [7.1, 126.0], [7.2, 128.0], [7.3, 129.0], [7.4, 131.0], [7.5, 131.0], [7.6, 133.0], [7.7, 134.0], [7.8, 135.0], [7.9, 136.0], [8.0, 137.0], [8.1, 138.0], [8.2, 140.0], [8.3, 141.0], [8.4, 142.0], [8.5, 143.0], [8.6, 144.0], [8.7, 145.0], [8.8, 146.0], [8.9, 147.0], [9.0, 148.0], [9.1, 149.0], [9.2, 150.0], [9.3, 151.0], [9.4, 152.0], [9.5, 154.0], [9.6, 155.0], [9.7, 156.0], [9.8, 157.0], [9.9, 158.0], [10.0, 159.0], [10.1, 160.0], [10.2, 161.0], [10.3, 162.0], [10.4, 163.0], [10.5, 163.0], [10.6, 165.0], [10.7, 166.0], [10.8, 167.0], [10.9, 168.0], [11.0, 169.0], [11.1, 170.0], [11.2, 171.0], [11.3, 172.0], [11.4, 173.0], [11.5, 174.0], [11.6, 175.0], [11.7, 176.0], [11.8, 177.0], [11.9, 178.0], [12.0, 179.0], [12.1, 179.0], [12.2, 180.0], [12.3, 181.0], [12.4, 182.0], [12.5, 183.0], [12.6, 184.0], [12.7, 184.0], [12.8, 185.0], [12.9, 186.0], [13.0, 187.0], [13.1, 188.0], [13.2, 189.0], [13.3, 190.0], [13.4, 191.0], [13.5, 191.0], [13.6, 192.0], [13.7, 194.0], [13.8, 195.0], [13.9, 196.0], [14.0, 196.0], [14.1, 197.0], [14.2, 198.0], [14.3, 199.0], [14.4, 200.0], [14.5, 200.0], [14.6, 201.0], [14.7, 202.0], [14.8, 203.0], [14.9, 204.0], [15.0, 205.0], [15.1, 206.0], [15.2, 207.0], [15.3, 208.0], [15.4, 209.0], [15.5, 209.0], [15.6, 210.0], [15.7, 211.0], [15.8, 212.0], [15.9, 213.0], [16.0, 213.0], [16.1, 214.0], [16.2, 215.0], [16.3, 216.0], [16.4, 217.0], [16.5, 217.0], [16.6, 218.0], [16.7, 219.0], [16.8, 219.0], [16.9, 220.0], [17.0, 221.0], [17.1, 221.0], [17.2, 222.0], [17.3, 223.0], [17.4, 224.0], [17.5, 225.0], [17.6, 225.0], [17.7, 226.0], [17.8, 227.0], [17.9, 228.0], [18.0, 229.0], [18.1, 230.0], [18.2, 230.0], [18.3, 231.0], [18.4, 232.0], [18.5, 232.0], [18.6, 233.0], [18.7, 234.0], [18.8, 234.0], [18.9, 235.0], [19.0, 236.0], [19.1, 236.0], [19.2, 237.0], [19.3, 238.0], [19.4, 239.0], [19.5, 240.0], [19.6, 240.0], [19.7, 241.0], [19.8, 242.0], [19.9, 243.0], [20.0, 244.0], [20.1, 245.0], [20.2, 246.0], [20.3, 247.0], [20.4, 248.0], [20.5, 249.0], [20.6, 249.0], [20.7, 250.0], [20.8, 251.0], [20.9, 251.0], [21.0, 252.0], [21.1, 253.0], [21.2, 254.0], [21.3, 255.0], [21.4, 256.0], [21.5, 257.0], [21.6, 258.0], [21.7, 259.0], [21.8, 260.0], [21.9, 260.0], [22.0, 261.0], [22.1, 262.0], [22.2, 263.0], [22.3, 264.0], [22.4, 265.0], [22.5, 265.0], [22.6, 266.0], [22.7, 267.0], [22.8, 268.0], [22.9, 269.0], [23.0, 270.0], [23.1, 271.0], [23.2, 272.0], [23.3, 272.0], [23.4, 273.0], [23.5, 274.0], [23.6, 275.0], [23.7, 276.0], [23.8, 276.0], [23.9, 277.0], [24.0, 278.0], [24.1, 279.0], [24.2, 279.0], [24.3, 281.0], [24.4, 281.0], [24.5, 282.0], [24.6, 283.0], [24.7, 283.0], [24.8, 284.0], [24.9, 285.0], [25.0, 286.0], [25.1, 287.0], [25.2, 288.0], [25.3, 289.0], [25.4, 290.0], [25.5, 290.0], [25.6, 291.0], [25.7, 292.0], [25.8, 293.0], [25.9, 293.0], [26.0, 294.0], [26.1, 295.0], [26.2, 296.0], [26.3, 297.0], [26.4, 297.0], [26.5, 298.0], [26.6, 298.0], [26.7, 299.0], [26.8, 299.0], [26.9, 300.0], [27.0, 301.0], [27.1, 301.0], [27.2, 302.0], [27.3, 303.0], [27.4, 303.0], [27.5, 304.0], [27.6, 305.0], [27.7, 305.0], [27.8, 306.0], [27.9, 306.0], [28.0, 308.0], [28.1, 308.0], [28.2, 310.0], [28.3, 310.0], [28.4, 311.0], [28.5, 312.0], [28.6, 312.0], [28.7, 313.0], [28.8, 314.0], [28.9, 314.0], [29.0, 315.0], [29.1, 316.0], [29.2, 316.0], [29.3, 317.0], [29.4, 317.0], [29.5, 318.0], [29.6, 319.0], [29.7, 321.0], [29.8, 322.0], [29.9, 323.0], [30.0, 323.0], [30.1, 324.0], [30.2, 324.0], [30.3, 325.0], [30.4, 326.0], [30.5, 326.0], [30.6, 327.0], [30.7, 328.0], [30.8, 329.0], [30.9, 329.0], [31.0, 330.0], [31.1, 331.0], [31.2, 332.0], [31.3, 333.0], [31.4, 333.0], [31.5, 334.0], [31.6, 335.0], [31.7, 335.0], [31.8, 336.0], [31.9, 337.0], [32.0, 338.0], [32.1, 339.0], [32.2, 340.0], [32.3, 340.0], [32.4, 341.0], [32.5, 342.0], [32.6, 342.0], [32.7, 343.0], [32.8, 344.0], [32.9, 345.0], [33.0, 346.0], [33.1, 347.0], [33.2, 347.0], [33.3, 348.0], [33.4, 349.0], [33.5, 349.0], [33.6, 350.0], [33.7, 351.0], [33.8, 352.0], [33.9, 352.0], [34.0, 353.0], [34.1, 354.0], [34.2, 355.0], [34.3, 356.0], [34.4, 357.0], [34.5, 358.0], [34.6, 358.0], [34.7, 359.0], [34.8, 359.0], [34.9, 360.0], [35.0, 361.0], [35.1, 361.0], [35.2, 362.0], [35.3, 363.0], [35.4, 364.0], [35.5, 365.0], [35.6, 365.0], [35.7, 366.0], [35.8, 367.0], [35.9, 368.0], [36.0, 369.0], [36.1, 370.0], [36.2, 370.0], [36.3, 371.0], [36.4, 372.0], [36.5, 373.0], [36.6, 373.0], [36.7, 374.0], [36.8, 375.0], [36.9, 375.0], [37.0, 376.0], [37.1, 377.0], [37.2, 377.0], [37.3, 379.0], [37.4, 380.0], [37.5, 380.0], [37.6, 381.0], [37.7, 382.0], [37.8, 382.0], [37.9, 383.0], [38.0, 384.0], [38.1, 385.0], [38.2, 386.0], [38.3, 388.0], [38.4, 388.0], [38.5, 389.0], [38.6, 390.0], [38.7, 390.0], [38.8, 391.0], [38.9, 392.0], [39.0, 393.0], [39.1, 393.0], [39.2, 394.0], [39.3, 395.0], [39.4, 396.0], [39.5, 396.0], [39.6, 397.0], [39.7, 398.0], [39.8, 399.0], [39.9, 400.0], [40.0, 401.0], [40.1, 401.0], [40.2, 402.0], [40.3, 403.0], [40.4, 403.0], [40.5, 404.0], [40.6, 405.0], [40.7, 406.0], [40.8, 407.0], [40.9, 408.0], [41.0, 409.0], [41.1, 410.0], [41.2, 410.0], [41.3, 411.0], [41.4, 412.0], [41.5, 413.0], [41.6, 414.0], [41.7, 415.0], [41.8, 415.0], [41.9, 416.0], [42.0, 417.0], [42.1, 417.0], [42.2, 418.0], [42.3, 418.0], [42.4, 419.0], [42.5, 420.0], [42.6, 421.0], [42.7, 422.0], [42.8, 423.0], [42.9, 424.0], [43.0, 425.0], [43.1, 426.0], [43.2, 427.0], [43.3, 428.0], [43.4, 429.0], [43.5, 430.0], [43.6, 431.0], [43.7, 431.0], [43.8, 432.0], [43.9, 433.0], [44.0, 434.0], [44.1, 434.0], [44.2, 435.0], [44.3, 436.0], [44.4, 437.0], [44.5, 438.0], [44.6, 439.0], [44.7, 439.0], [44.8, 440.0], [44.9, 441.0], [45.0, 442.0], [45.1, 443.0], [45.2, 444.0], [45.3, 444.0], [45.4, 445.0], [45.5, 446.0], [45.6, 447.0], [45.7, 448.0], [45.8, 448.0], [45.9, 449.0], [46.0, 450.0], [46.1, 451.0], [46.2, 452.0], [46.3, 453.0], [46.4, 454.0], [46.5, 455.0], [46.6, 456.0], [46.7, 457.0], [46.8, 457.0], [46.9, 458.0], [47.0, 459.0], [47.1, 460.0], [47.2, 460.0], [47.3, 461.0], [47.4, 462.0], [47.5, 463.0], [47.6, 464.0], [47.7, 465.0], [47.8, 465.0], [47.9, 466.0], [48.0, 467.0], [48.1, 468.0], [48.2, 469.0], [48.3, 470.0], [48.4, 471.0], [48.5, 471.0], [48.6, 472.0], [48.7, 473.0], [48.8, 473.0], [48.9, 474.0], [49.0, 475.0], [49.1, 476.0], [49.2, 477.0], [49.3, 477.0], [49.4, 478.0], [49.5, 478.0], [49.6, 479.0], [49.7, 480.0], [49.8, 481.0], [49.9, 482.0], [50.0, 483.0], [50.1, 483.0], [50.2, 484.0], [50.3, 485.0], [50.4, 486.0], [50.5, 487.0], [50.6, 487.0], [50.7, 488.0], [50.8, 489.0], [50.9, 490.0], [51.0, 491.0], [51.1, 492.0], [51.2, 493.0], [51.3, 494.0], [51.4, 495.0], [51.5, 495.0], [51.6, 496.0], [51.7, 497.0], [51.8, 498.0], [51.9, 498.0], [52.0, 499.0], [52.1, 500.0], [52.2, 500.0], [52.3, 501.0], [52.4, 502.0], [52.5, 503.0], [52.6, 503.0], [52.7, 504.0], [52.8, 505.0], [52.9, 505.0], [53.0, 506.0], [53.1, 506.0], [53.2, 507.0], [53.3, 508.0], [53.4, 509.0], [53.5, 510.0], [53.6, 511.0], [53.7, 511.0], [53.8, 512.0], [53.9, 513.0], [54.0, 514.0], [54.1, 514.0], [54.2, 515.0], [54.3, 516.0], [54.4, 517.0], [54.5, 518.0], [54.6, 518.0], [54.7, 519.0], [54.8, 519.0], [54.9, 520.0], [55.0, 521.0], [55.1, 522.0], [55.2, 523.0], [55.3, 523.0], [55.4, 524.0], [55.5, 525.0], [55.6, 526.0], [55.7, 527.0], [55.8, 527.0], [55.9, 528.0], [56.0, 529.0], [56.1, 530.0], [56.2, 530.0], [56.3, 531.0], [56.4, 532.0], [56.5, 533.0], [56.6, 533.0], [56.7, 534.0], [56.8, 535.0], [56.9, 536.0], [57.0, 537.0], [57.1, 537.0], [57.2, 538.0], [57.3, 539.0], [57.4, 539.0], [57.5, 540.0], [57.6, 541.0], [57.7, 542.0], [57.8, 543.0], [57.9, 544.0], [58.0, 545.0], [58.1, 546.0], [58.2, 547.0], [58.3, 548.0], [58.4, 548.0], [58.5, 550.0], [58.6, 550.0], [58.7, 551.0], [58.8, 552.0], [58.9, 552.0], [59.0, 553.0], [59.1, 554.0], [59.2, 555.0], [59.3, 555.0], [59.4, 556.0], [59.5, 557.0], [59.6, 558.0], [59.7, 559.0], [59.8, 560.0], [59.9, 561.0], [60.0, 561.0], [60.1, 562.0], [60.2, 563.0], [60.3, 564.0], [60.4, 565.0], [60.5, 566.0], [60.6, 567.0], [60.7, 568.0], [60.8, 569.0], [60.9, 570.0], [61.0, 570.0], [61.1, 571.0], [61.2, 572.0], [61.3, 573.0], [61.4, 574.0], [61.5, 575.0], [61.6, 576.0], [61.7, 576.0], [61.8, 577.0], [61.9, 578.0], [62.0, 579.0], [62.1, 580.0], [62.2, 581.0], [62.3, 582.0], [62.4, 583.0], [62.5, 584.0], [62.6, 585.0], [62.7, 585.0], [62.8, 586.0], [62.9, 587.0], [63.0, 588.0], [63.1, 589.0], [63.2, 589.0], [63.3, 590.0], [63.4, 591.0], [63.5, 592.0], [63.6, 592.0], [63.7, 593.0], [63.8, 594.0], [63.9, 595.0], [64.0, 596.0], [64.1, 597.0], [64.2, 598.0], [64.3, 599.0], [64.4, 599.0], [64.5, 601.0], [64.6, 602.0], [64.7, 602.0], [64.8, 603.0], [64.9, 604.0], [65.0, 604.0], [65.1, 605.0], [65.2, 606.0], [65.3, 606.0], [65.4, 607.0], [65.5, 608.0], [65.6, 609.0], [65.7, 609.0], [65.8, 611.0], [65.9, 611.0], [66.0, 612.0], [66.1, 613.0], [66.2, 614.0], [66.3, 614.0], [66.4, 615.0], [66.5, 616.0], [66.6, 617.0], [66.7, 618.0], [66.8, 619.0], [66.9, 620.0], [67.0, 621.0], [67.1, 622.0], [67.2, 623.0], [67.3, 624.0], [67.4, 625.0], [67.5, 627.0], [67.6, 628.0], [67.7, 629.0], [67.8, 630.0], [67.9, 632.0], [68.0, 633.0], [68.1, 633.0], [68.2, 635.0], [68.3, 636.0], [68.4, 637.0], [68.5, 639.0], [68.6, 639.0], [68.7, 640.0], [68.8, 641.0], [68.9, 642.0], [69.0, 643.0], [69.1, 644.0], [69.2, 645.0], [69.3, 646.0], [69.4, 646.0], [69.5, 647.0], [69.6, 648.0], [69.7, 649.0], [69.8, 650.0], [69.9, 651.0], [70.0, 653.0], [70.1, 654.0], [70.2, 655.0], [70.3, 655.0], [70.4, 657.0], [70.5, 658.0], [70.6, 659.0], [70.7, 659.0], [70.8, 660.0], [70.9, 661.0], [71.0, 662.0], [71.1, 663.0], [71.2, 664.0], [71.3, 665.0], [71.4, 666.0], [71.5, 667.0], [71.6, 668.0], [71.7, 669.0], [71.8, 670.0], [71.9, 671.0], [72.0, 672.0], [72.1, 673.0], [72.2, 674.0], [72.3, 675.0], [72.4, 677.0], [72.5, 678.0], [72.6, 679.0], [72.7, 680.0], [72.8, 682.0], [72.9, 683.0], [73.0, 684.0], [73.1, 685.0], [73.2, 686.0], [73.3, 687.0], [73.4, 688.0], [73.5, 690.0], [73.6, 691.0], [73.7, 692.0], [73.8, 693.0], [73.9, 694.0], [74.0, 695.0], [74.1, 696.0], [74.2, 697.0], [74.3, 698.0], [74.4, 699.0], [74.5, 701.0], [74.6, 702.0], [74.7, 703.0], [74.8, 704.0], [74.9, 705.0], [75.0, 706.0], [75.1, 707.0], [75.2, 708.0], [75.3, 709.0], [75.4, 710.0], [75.5, 712.0], [75.6, 713.0], [75.7, 714.0], [75.8, 715.0], [75.9, 716.0], [76.0, 718.0], [76.1, 719.0], [76.2, 720.0], [76.3, 721.0], [76.4, 722.0], [76.5, 723.0], [76.6, 725.0], [76.7, 726.0], [76.8, 727.0], [76.9, 729.0], [77.0, 730.0], [77.1, 731.0], [77.2, 733.0], [77.3, 734.0], [77.4, 735.0], [77.5, 737.0], [77.6, 738.0], [77.7, 740.0], [77.8, 742.0], [77.9, 743.0], [78.0, 745.0], [78.1, 746.0], [78.2, 748.0], [78.3, 749.0], [78.4, 751.0], [78.5, 752.0], [78.6, 753.0], [78.7, 754.0], [78.8, 755.0], [78.9, 756.0], [79.0, 757.0], [79.1, 758.0], [79.2, 760.0], [79.3, 762.0], [79.4, 763.0], [79.5, 764.0], [79.6, 766.0], [79.7, 767.0], [79.8, 770.0], [79.9, 771.0], [80.0, 773.0], [80.1, 773.0], [80.2, 774.0], [80.3, 776.0], [80.4, 778.0], [80.5, 779.0], [80.6, 780.0], [80.7, 782.0], [80.8, 783.0], [80.9, 784.0], [81.0, 786.0], [81.1, 788.0], [81.2, 789.0], [81.3, 790.0], [81.4, 792.0], [81.5, 794.0], [81.6, 795.0], [81.7, 797.0], [81.8, 798.0], [81.9, 799.0], [82.0, 800.0], [82.1, 801.0], [82.2, 803.0], [82.3, 805.0], [82.4, 806.0], [82.5, 807.0], [82.6, 809.0], [82.7, 811.0], [82.8, 812.0], [82.9, 814.0], [83.0, 816.0], [83.1, 817.0], [83.2, 818.0], [83.3, 820.0], [83.4, 821.0], [83.5, 823.0], [83.6, 824.0], [83.7, 826.0], [83.8, 827.0], [83.9, 829.0], [84.0, 831.0], [84.1, 833.0], [84.2, 834.0], [84.3, 836.0], [84.4, 837.0], [84.5, 839.0], [84.6, 841.0], [84.7, 844.0], [84.8, 845.0], [84.9, 847.0], [85.0, 848.0], [85.1, 849.0], [85.2, 851.0], [85.3, 853.0], [85.4, 854.0], [85.5, 856.0], [85.6, 858.0], [85.7, 859.0], [85.8, 860.0], [85.9, 863.0], [86.0, 864.0], [86.1, 866.0], [86.2, 868.0], [86.3, 871.0], [86.4, 874.0], [86.5, 875.0], [86.6, 877.0], [86.7, 880.0], [86.8, 881.0], [86.9, 883.0], [87.0, 885.0], [87.1, 887.0], [87.2, 889.0], [87.3, 891.0], [87.4, 892.0], [87.5, 894.0], [87.6, 896.0], [87.7, 898.0], [87.8, 900.0], [87.9, 902.0], [88.0, 904.0], [88.1, 906.0], [88.2, 908.0], [88.3, 911.0], [88.4, 914.0], [88.5, 916.0], [88.6, 918.0], [88.7, 920.0], [88.8, 922.0], [88.9, 925.0], [89.0, 928.0], [89.1, 932.0], [89.2, 934.0], [89.3, 936.0], [89.4, 939.0], [89.5, 943.0], [89.6, 946.0], [89.7, 948.0], [89.8, 950.0], [89.9, 953.0], [90.0, 955.0], [90.1, 958.0], [90.2, 961.0], [90.3, 963.0], [90.4, 965.0], [90.5, 966.0], [90.6, 968.0], [90.7, 971.0], [90.8, 974.0], [90.9, 977.0], [91.0, 978.0], [91.1, 980.0], [91.2, 982.0], [91.3, 985.0], [91.4, 987.0], [91.5, 988.0], [91.6, 991.0], [91.7, 994.0], [91.8, 996.0], [91.9, 998.0], [92.0, 1000.0], [92.1, 1002.0], [92.2, 1004.0], [92.3, 1007.0], [92.4, 1008.0], [92.5, 1010.0], [92.6, 1013.0], [92.7, 1014.0], [92.8, 1018.0], [92.9, 1020.0], [93.0, 1023.0], [93.1, 1026.0], [93.2, 1029.0], [93.3, 1034.0], [93.4, 1038.0], [93.5, 1041.0], [93.6, 1042.0], [93.7, 1047.0], [93.8, 1050.0], [93.9, 1055.0], [94.0, 1059.0], [94.1, 1065.0], [94.2, 1071.0], [94.3, 1076.0], [94.4, 1078.0], [94.5, 1081.0], [94.6, 1086.0], [94.7, 1090.0], [94.8, 1094.0], [94.9, 1100.0], [95.0, 1104.0], [95.1, 1108.0], [95.2, 1111.0], [95.3, 1115.0], [95.4, 1119.0], [95.5, 1124.0], [95.6, 1128.0], [95.7, 1132.0], [95.8, 1139.0], [95.9, 1146.0], [96.0, 1153.0], [96.1, 1160.0], [96.2, 1166.0], [96.3, 1173.0], [96.4, 1180.0], [96.5, 1186.0], [96.6, 1193.0], [96.7, 1201.0], [96.8, 1208.0], [96.9, 1215.0], [97.0, 1219.0], [97.1, 1227.0], [97.2, 1234.0], [97.3, 1239.0], [97.4, 1247.0], [97.5, 1253.0], [97.6, 1262.0], [97.7, 1269.0], [97.8, 1278.0], [97.9, 1287.0], [98.0, 1297.0], [98.1, 1303.0], [98.2, 1312.0], [98.3, 1321.0], [98.4, 1332.0], [98.5, 1343.0], [98.6, 1353.0], [98.7, 1370.0], [98.8, 1392.0], [98.9, 1407.0], [99.0, 1426.0], [99.1, 1448.0], [99.2, 1486.0], [99.3, 1501.0], [99.4, 1540.0], [99.5, 1597.0], [99.6, 1658.0], [99.7, 1706.0], [99.8, 1837.0], [99.9, 1939.0], [100.0, 2699.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 2004.0, "series": [{"data": [[0.0, 742.0], [600.0, 1535.0], [700.0, 1149.0], [800.0, 899.0], [900.0, 641.0], [1000.0, 452.0], [1100.0, 272.0], [1200.0, 211.0], [1300.0, 122.0], [1400.0, 66.0], [1500.0, 36.0], [100.0, 1460.0], [1600.0, 28.0], [1700.0, 15.0], [1800.0, 12.0], [1900.0, 5.0], [2000.0, 3.0], [2100.0, 2.0], [2200.0, 4.0], [2300.0, 4.0], [2500.0, 1.0], [2600.0, 1.0], [200.0, 1910.0], [300.0, 2004.0], [400.0, 1864.0], [500.0, 1895.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 2600.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 109.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 8004.0, "series": [{"data": [[0.0, 8004.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 7220.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 109.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 157.12611115726548, "minX": 1.79069472E12, "maxY": 193.99666262135912, "series": [{"data": [[1.79069472E12, 157.12611115726548], [1.79069478E12, 193.99666262135912]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069478E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 49.111111111111114, "minX": 2.0, "maxY": 1000.0, "series": [{"data": [[2.0, 1000.0], [4.0, 196.45454545454544], [5.0, 49.111111111111114], [6.0, 129.53333333333333], [7.0, 122.44444444444443], [8.0, 134.9230769230769], [9.0, 52.12499999999999], [10.0, 166.1818181818182], [11.0, 70.13043478260869], [12.0, 58.94117647058823], [13.0, 142.9411764705882], [14.0, 107.32142857142857], [15.0, 118.63636363636363], [16.0, 80.0625], [17.0, 82.28571428571428], [18.0, 88.95833333333333], [19.0, 82.35000000000001], [20.0, 159.4642857142857], [21.0, 92.36842105263159], [22.0, 64.26470588235296], [23.0, 148.6], [24.0, 109.08695652173914], [25.0, 89.85185185185185], [26.0, 90.06060606060606], [27.0, 127.80555555555557], [28.0, 111.5], [29.0, 98.77142857142856], [30.0, 102.72727272727269], [31.0, 115.6470588235294], [32.0, 130.83333333333334], [33.0, 173.9047619047619], [34.0, 148.7857142857143], [35.0, 234.10344827586204], [36.0, 161.53333333333333], [37.0, 147.71794871794873], [38.0, 124.57692307692307], [39.0, 136.61764705882354], [40.0, 120.42857142857142], [41.0, 151.0], [42.0, 125.88888888888889], [43.0, 167.33333333333331], [44.0, 138.34090909090912], [45.0, 142.56666666666663], [46.0, 239.34782608695656], [47.0, 198.42857142857142], [48.0, 170.50000000000006], [49.0, 213.37931034482762], [50.0, 202.1071428571429], [51.0, 174.49999999999997], [52.0, 243.1621621621622], [53.0, 173.62500000000003], [54.0, 225.00000000000006], [55.0, 162.9722222222222], [56.0, 174.72727272727275], [57.0, 217.43999999999997], [58.0, 572.5], [59.0, 284.55555555555554], [60.0, 332.95833333333326], [61.0, 195.49999999999997], [62.0, 326.875], [63.0, 403.4864864864865], [64.0, 306.55555555555554], [65.0, 269.28], [66.0, 294.7727272727273], [67.0, 333.6875], [68.0, 300.22727272727275], [69.0, 294.7857142857143], [70.0, 360.73333333333335], [71.0, 327.02941176470574], [72.0, 268.80645161290323], [73.0, 215.94285714285715], [74.0, 286.50000000000006], [75.0, 246.84], [76.0, 244.14705882352945], [77.0, 222.625], [78.0, 311.3636363636364], [79.0, 323.2142857142857], [80.0, 263.45000000000005], [81.0, 326.4473684210526], [82.0, 274.9024390243902], [83.0, 273.7083333333333], [84.0, 272.48], [85.0, 330.1052631578947], [86.0, 313.06060606060606], [87.0, 309.6], [88.0, 419.6428571428571], [89.0, 408.0357142857142], [90.0, 442.65000000000003], [91.0, 416.12], [92.0, 364.3809523809524], [93.0, 314.5555555555555], [94.0, 223.14285714285717], [95.0, 272.51724137931035], [96.0, 272.1842105263158], [97.0, 303.88235294117646], [98.0, 460.5], [99.0, 239.16666666666666], [100.0, 355.08695652173907], [101.0, 400.7037037037037], [102.0, 508.0540540540541], [103.0, 350.19999999999993], [104.0, 248.42105263157893], [105.0, 329.75], [106.0, 290.6111111111111], [107.0, 419.4285714285714], [108.0, 418.03703703703707], [109.0, 347.17142857142846], [110.0, 289.31578947368416], [111.0, 356.0487804878049], [112.0, 375.61111111111114], [113.0, 301.26530612244903], [114.0, 430.1666666666666], [115.0, 284.4117647058824], [116.0, 336.48780487804873], [117.0, 262.99999999999994], [118.0, 319.6153846153846], [119.0, 298.74285714285713], [120.0, 294.99999999999994], [121.0, 350.8000000000001], [122.0, 340.6428571428571], [123.0, 438.2307692307692], [124.0, 406.8148148148149], [125.0, 403.0], [126.0, 420.875], [127.0, 381.5405405405406], [128.0, 388.27586206896547], [129.0, 400.1621621621622], [130.0, 438.6052631578948], [131.0, 470.6153846153846], [132.0, 335.6363636363637], [133.0, 255.46428571428575], [134.0, 298.7586206896551], [135.0, 396.69444444444434], [136.0, 402.6129032258064], [137.0, 630.25], [138.0, 563.0526315789473], [139.0, 463.89473684210526], [140.0, 372.2549019607844], [141.0, 347.9736842105263], [142.0, 368.25641025641033], [143.0, 333.6808510638298], [144.0, 344.0882352941177], [145.0, 388.4130434782608], [146.0, 395.61290322580635], [147.0, 453.17647058823525], [148.0, 360.75], [149.0, 397.48275862068965], [150.0, 356.6666666666668], [151.0, 373.24528301886784], [152.0, 292.7894736842105], [153.0, 275.46428571428567], [154.0, 408.4146341463414], [155.0, 427.65], [156.0, 451.86842105263156], [157.0, 325.04], [158.0, 471.7272727272727], [159.0, 502.2758620689655], [160.0, 492.6428571428571], [161.0, 569.1142857142858], [162.0, 547.1818181818182], [163.0, 612.8888888888889], [164.0, 624.4666666666667], [165.0, 591.4999999999999], [166.0, 727.85], [167.0, 680.4444444444445], [168.0, 628.111111111111], [169.0, 826.9189189189191], [170.0, 765.6562500000001], [171.0, 852.8260869565217], [172.0, 583.4687499999999], [173.0, 503.7647058823529], [174.0, 579.6428571428571], [175.0, 436.66666666666674], [179.0, 773.7011494252879], [180.0, 212.91304347826085], [181.0, 232.6818181818182], [182.0, 337.4444444444444], [183.0, 389.3], [178.0, 397.0], [177.0, 509.0], [176.0, 326.0], [184.0, 506.6666666666667], [185.0, 554.909090909091], [186.0, 632.04], [187.0, 648.9999999999998], [188.0, 706.7499999999999], [189.0, 847.4615384615386], [190.0, 927.0526315789473], [191.0, 921.6052631578947], [192.0, 652.611111111111], [193.0, 612.1666666666665], [194.0, 739.4117647058824], [195.0, 607.5000000000001], [196.0, 715.56], [197.0, 913.3249999999999], [198.0, 941.6666666666667], [199.0, 491.4705882352942], [200.0, 622.3687913907295]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[165.05184895323882, 524.6596882540935]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 200.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 25708.8, "minX": 1.79069472E12, "maxY": 111661.66666666667, "series": [{"data": [[1.79069472E12, 111661.66666666667], [1.79069478E12, 30573.233333333334]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79069472E12, 93888.6], [1.79069478E12, 25708.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069478E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 503.57913101271123, "minX": 1.79069472E12, "maxY": 601.6459344660201, "series": [{"data": [[1.79069472E12, 503.57913101271123], [1.79069478E12, 601.6459344660201]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069478E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 497.8048517072366, "minX": 1.79069472E12, "maxY": 596.2642597087387, "series": [{"data": [[1.79069472E12, 497.8048517072366], [1.79069478E12, 596.2642597087387]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069478E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79069472E12, "maxY": 0.05333554872476564, "series": [{"data": [[1.79069472E12, 0.05333554872476564], [1.79069478E12, 0.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069478E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 22.0, "minX": 1.79069472E12, "maxY": 2699.0, "series": [{"data": [[1.79069472E12, 2699.0], [1.79069478E12, 2007.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79069472E12, 942.0], [1.79069478E12, 987.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79069472E12, 1445.7200000000048], [1.79069478E12, 1361.1799999999985]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79069472E12, 1103.0], [1.79069478E12, 1107.1499999999996]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79069472E12, 22.0], [1.79069478E12, 67.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79069472E12, 453.0], [1.79069478E12, 557.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069478E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 26.0, "minX": 7.0, "maxY": 783.0, "series": [{"data": [[7.0, 26.0], [159.0, 53.0], [172.0, 619.0], [206.0, 250.5], [201.0, 753.0], [204.0, 758.0], [216.0, 708.0], [218.0, 744.5], [232.0, 710.5], [244.0, 71.0], [246.0, 506.5], [250.0, 720.0], [258.0, 236.5], [268.0, 783.0], [262.0, 690.5], [271.0, 612.0], [277.0, 87.0], [279.0, 205.0], [281.0, 304.5], [298.0, 294.5], [296.0, 709.0], [295.0, 547.0], [315.0, 117.0], [307.0, 608.5], [305.0, 633.0], [304.0, 613.5], [321.0, 312.0], [330.0, 300.5], [323.0, 350.0], [329.0, 571.0], [320.0, 501.0], [334.0, 528.0], [331.0, 568.0], [333.0, 644.0], [347.0, 569.0], [359.0, 648.0], [352.0, 551.0], [367.0, 573.0], [378.0, 359.0], [376.0, 574.5], [375.0, 482.0], [397.0, 483.0], [392.0, 437.0], [404.0, 335.0], [415.0, 547.0], [445.0, 523.0], [489.0, 601.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 489.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 26.0, "minX": 7.0, "maxY": 781.0, "series": [{"data": [[7.0, 26.0], [159.0, 51.0], [172.0, 603.5], [206.0, 249.5], [201.0, 731.0], [204.0, 752.0], [216.0, 706.5], [218.0, 715.5], [232.0, 702.0], [244.0, 69.0], [246.0, 503.5], [250.0, 714.0], [258.0, 233.5], [268.0, 781.0], [262.0, 679.0], [271.0, 606.0], [277.0, 86.0], [279.0, 198.0], [281.0, 298.5], [298.0, 289.5], [296.0, 701.5], [295.0, 529.0], [315.0, 113.0], [307.0, 603.0], [305.0, 619.0], [304.0, 602.0], [321.0, 310.0], [330.0, 297.5], [323.0, 348.0], [329.0, 562.0], [320.0, 493.5], [334.0, 516.0], [331.0, 566.0], [333.0, 635.0], [347.0, 563.0], [359.0, 640.0], [352.0, 543.0], [367.0, 567.0], [378.0, 357.0], [376.0, 569.0], [375.0, 475.0], [397.0, 483.0], [392.0, 434.0], [404.0, 326.0], [415.0, 545.0], [445.0, 523.0], [489.0, 599.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 489.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 51.6, "minX": 1.79069472E12, "maxY": 203.95, "series": [{"data": [[1.79069472E12, 203.95], [1.79069478E12, 51.6]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069478E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 54.93333333333333, "minX": 1.79069472E12, "maxY": 200.61666666666667, "series": [{"data": [[1.79069472E12, 200.61666666666667], [1.79069478E12, 54.93333333333333]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069478E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 54.93333333333333, "minX": 1.79069472E12, "maxY": 200.61666666666667, "series": [{"data": [[1.79069472E12, 200.61666666666667], [1.79069478E12, 54.93333333333333]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069478E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 54.93333333333333, "minX": 1.79069472E12, "maxY": 200.61666666666667, "series": [{"data": [[1.79069472E12, 200.61666666666667], [1.79069478E12, 54.93333333333333]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069478E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

