/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 14.0, "minX": 0.0, "maxY": 1117.0, "series": [{"data": [[0.0, 14.0], [0.1, 15.0], [0.2, 17.0], [0.3, 19.0], [0.4, 20.0], [0.5, 22.0], [0.6, 23.0], [0.7, 24.0], [0.8, 25.0], [0.9, 26.0], [1.0, 27.0], [1.1, 27.0], [1.2, 28.0], [1.3, 29.0], [1.4, 29.0], [1.5, 30.0], [1.6, 31.0], [1.7, 32.0], [1.8, 33.0], [1.9, 33.0], [2.0, 34.0], [2.1, 34.0], [2.2, 35.0], [2.3, 36.0], [2.4, 36.0], [2.5, 37.0], [2.6, 37.0], [2.7, 38.0], [2.8, 38.0], [2.9, 39.0], [3.0, 39.0], [3.1, 40.0], [3.2, 40.0], [3.3, 41.0], [3.4, 41.0], [3.5, 41.0], [3.6, 42.0], [3.7, 42.0], [3.8, 43.0], [3.9, 43.0], [4.0, 44.0], [4.1, 44.0], [4.2, 45.0], [4.3, 45.0], [4.4, 46.0], [4.5, 46.0], [4.6, 46.0], [4.7, 47.0], [4.8, 47.0], [4.9, 47.0], [5.0, 47.0], [5.1, 48.0], [5.2, 48.0], [5.3, 49.0], [5.4, 49.0], [5.5, 50.0], [5.6, 50.0], [5.7, 50.0], [5.8, 51.0], [5.9, 51.0], [6.0, 51.0], [6.1, 52.0], [6.2, 52.0], [6.3, 52.0], [6.4, 52.0], [6.5, 53.0], [6.6, 53.0], [6.7, 53.0], [6.8, 53.0], [6.9, 54.0], [7.0, 54.0], [7.1, 55.0], [7.2, 55.0], [7.3, 55.0], [7.4, 55.0], [7.5, 56.0], [7.6, 56.0], [7.7, 56.0], [7.8, 57.0], [7.9, 57.0], [8.0, 57.0], [8.1, 58.0], [8.2, 58.0], [8.3, 58.0], [8.4, 59.0], [8.5, 59.0], [8.6, 59.0], [8.7, 59.0], [8.8, 59.0], [8.9, 60.0], [9.0, 60.0], [9.1, 60.0], [9.2, 60.0], [9.3, 61.0], [9.4, 61.0], [9.5, 61.0], [9.6, 61.0], [9.7, 62.0], [9.8, 62.0], [9.9, 62.0], [10.0, 62.0], [10.1, 63.0], [10.2, 63.0], [10.3, 63.0], [10.4, 63.0], [10.5, 64.0], [10.6, 64.0], [10.7, 64.0], [10.8, 64.0], [10.9, 64.0], [11.0, 65.0], [11.1, 65.0], [11.2, 65.0], [11.3, 65.0], [11.4, 66.0], [11.5, 66.0], [11.6, 66.0], [11.7, 66.0], [11.8, 66.0], [11.9, 67.0], [12.0, 67.0], [12.1, 67.0], [12.2, 67.0], [12.3, 67.0], [12.4, 68.0], [12.5, 68.0], [12.6, 68.0], [12.7, 68.0], [12.8, 69.0], [12.9, 69.0], [13.0, 69.0], [13.1, 69.0], [13.2, 70.0], [13.3, 70.0], [13.4, 70.0], [13.5, 70.0], [13.6, 71.0], [13.7, 71.0], [13.8, 71.0], [13.9, 71.0], [14.0, 72.0], [14.1, 72.0], [14.2, 72.0], [14.3, 72.0], [14.4, 72.0], [14.5, 72.0], [14.6, 73.0], [14.7, 73.0], [14.8, 73.0], [14.9, 73.0], [15.0, 73.0], [15.1, 74.0], [15.2, 74.0], [15.3, 74.0], [15.4, 74.0], [15.5, 74.0], [15.6, 74.0], [15.7, 75.0], [15.8, 75.0], [15.9, 75.0], [16.0, 75.0], [16.1, 76.0], [16.2, 76.0], [16.3, 76.0], [16.4, 76.0], [16.5, 76.0], [16.6, 76.0], [16.7, 77.0], [16.8, 77.0], [16.9, 77.0], [17.0, 77.0], [17.1, 77.0], [17.2, 78.0], [17.3, 78.0], [17.4, 78.0], [17.5, 78.0], [17.6, 78.0], [17.7, 79.0], [17.8, 79.0], [17.9, 79.0], [18.0, 79.0], [18.1, 79.0], [18.2, 80.0], [18.3, 80.0], [18.4, 80.0], [18.5, 80.0], [18.6, 80.0], [18.7, 81.0], [18.8, 81.0], [18.9, 81.0], [19.0, 81.0], [19.1, 81.0], [19.2, 82.0], [19.3, 82.0], [19.4, 82.0], [19.5, 82.0], [19.6, 82.0], [19.7, 82.0], [19.8, 83.0], [19.9, 83.0], [20.0, 83.0], [20.1, 83.0], [20.2, 84.0], [20.3, 84.0], [20.4, 84.0], [20.5, 84.0], [20.6, 84.0], [20.7, 85.0], [20.8, 85.0], [20.9, 85.0], [21.0, 85.0], [21.1, 85.0], [21.2, 85.0], [21.3, 85.0], [21.4, 85.0], [21.5, 86.0], [21.6, 86.0], [21.7, 86.0], [21.8, 86.0], [21.9, 87.0], [22.0, 87.0], [22.1, 87.0], [22.2, 87.0], [22.3, 87.0], [22.4, 88.0], [22.5, 88.0], [22.6, 88.0], [22.7, 88.0], [22.8, 88.0], [22.9, 89.0], [23.0, 89.0], [23.1, 89.0], [23.2, 89.0], [23.3, 89.0], [23.4, 89.0], [23.5, 90.0], [23.6, 90.0], [23.7, 90.0], [23.8, 90.0], [23.9, 90.0], [24.0, 90.0], [24.1, 91.0], [24.2, 91.0], [24.3, 91.0], [24.4, 91.0], [24.5, 91.0], [24.6, 92.0], [24.7, 92.0], [24.8, 92.0], [24.9, 92.0], [25.0, 92.0], [25.1, 92.0], [25.2, 93.0], [25.3, 93.0], [25.4, 93.0], [25.5, 93.0], [25.6, 93.0], [25.7, 93.0], [25.8, 94.0], [25.9, 94.0], [26.0, 94.0], [26.1, 94.0], [26.2, 94.0], [26.3, 94.0], [26.4, 95.0], [26.5, 95.0], [26.6, 95.0], [26.7, 95.0], [26.8, 95.0], [26.9, 95.0], [27.0, 95.0], [27.1, 96.0], [27.2, 96.0], [27.3, 96.0], [27.4, 96.0], [27.5, 96.0], [27.6, 96.0], [27.7, 96.0], [27.8, 97.0], [27.9, 97.0], [28.0, 97.0], [28.1, 97.0], [28.2, 98.0], [28.3, 98.0], [28.4, 98.0], [28.5, 98.0], [28.6, 98.0], [28.7, 98.0], [28.8, 98.0], [28.9, 99.0], [29.0, 99.0], [29.1, 99.0], [29.2, 99.0], [29.3, 100.0], [29.4, 100.0], [29.5, 100.0], [29.6, 100.0], [29.7, 100.0], [29.8, 100.0], [29.9, 101.0], [30.0, 101.0], [30.1, 101.0], [30.2, 101.0], [30.3, 101.0], [30.4, 102.0], [30.5, 102.0], [30.6, 102.0], [30.7, 102.0], [30.8, 102.0], [30.9, 102.0], [31.0, 103.0], [31.1, 103.0], [31.2, 103.0], [31.3, 103.0], [31.4, 103.0], [31.5, 104.0], [31.6, 104.0], [31.7, 104.0], [31.8, 104.0], [31.9, 104.0], [32.0, 104.0], [32.1, 105.0], [32.2, 105.0], [32.3, 105.0], [32.4, 105.0], [32.5, 105.0], [32.6, 106.0], [32.7, 106.0], [32.8, 106.0], [32.9, 106.0], [33.0, 106.0], [33.1, 107.0], [33.2, 107.0], [33.3, 107.0], [33.4, 107.0], [33.5, 107.0], [33.6, 107.0], [33.7, 107.0], [33.8, 108.0], [33.9, 108.0], [34.0, 108.0], [34.1, 108.0], [34.2, 108.0], [34.3, 108.0], [34.4, 109.0], [34.5, 109.0], [34.6, 109.0], [34.7, 109.0], [34.8, 109.0], [34.9, 109.0], [35.0, 110.0], [35.1, 110.0], [35.2, 110.0], [35.3, 110.0], [35.4, 110.0], [35.5, 111.0], [35.6, 111.0], [35.7, 111.0], [35.8, 111.0], [35.9, 111.0], [36.0, 111.0], [36.1, 112.0], [36.2, 112.0], [36.3, 112.0], [36.4, 112.0], [36.5, 112.0], [36.6, 112.0], [36.7, 113.0], [36.8, 113.0], [36.9, 113.0], [37.0, 113.0], [37.1, 113.0], [37.2, 113.0], [37.3, 114.0], [37.4, 114.0], [37.5, 114.0], [37.6, 114.0], [37.7, 114.0], [37.8, 114.0], [37.9, 114.0], [38.0, 115.0], [38.1, 115.0], [38.2, 115.0], [38.3, 115.0], [38.4, 115.0], [38.5, 116.0], [38.6, 116.0], [38.7, 116.0], [38.8, 116.0], [38.9, 116.0], [39.0, 116.0], [39.1, 117.0], [39.2, 117.0], [39.3, 117.0], [39.4, 117.0], [39.5, 117.0], [39.6, 118.0], [39.7, 118.0], [39.8, 118.0], [39.9, 118.0], [40.0, 118.0], [40.1, 118.0], [40.2, 119.0], [40.3, 119.0], [40.4, 119.0], [40.5, 119.0], [40.6, 119.0], [40.7, 120.0], [40.8, 120.0], [40.9, 120.0], [41.0, 120.0], [41.1, 120.0], [41.2, 121.0], [41.3, 121.0], [41.4, 121.0], [41.5, 121.0], [41.6, 121.0], [41.7, 121.0], [41.8, 122.0], [41.9, 122.0], [42.0, 122.0], [42.1, 122.0], [42.2, 123.0], [42.3, 123.0], [42.4, 123.0], [42.5, 123.0], [42.6, 123.0], [42.7, 123.0], [42.8, 123.0], [42.9, 124.0], [43.0, 124.0], [43.1, 124.0], [43.2, 124.0], [43.3, 124.0], [43.4, 124.0], [43.5, 125.0], [43.6, 125.0], [43.7, 125.0], [43.8, 125.0], [43.9, 125.0], [44.0, 126.0], [44.1, 126.0], [44.2, 126.0], [44.3, 126.0], [44.4, 126.0], [44.5, 126.0], [44.6, 127.0], [44.7, 127.0], [44.8, 127.0], [44.9, 127.0], [45.0, 127.0], [45.1, 128.0], [45.2, 128.0], [45.3, 128.0], [45.4, 128.0], [45.5, 128.0], [45.6, 129.0], [45.7, 129.0], [45.8, 129.0], [45.9, 129.0], [46.0, 129.0], [46.1, 129.0], [46.2, 130.0], [46.3, 130.0], [46.4, 130.0], [46.5, 130.0], [46.6, 130.0], [46.7, 131.0], [46.8, 131.0], [46.9, 131.0], [47.0, 131.0], [47.1, 131.0], [47.2, 132.0], [47.3, 132.0], [47.4, 132.0], [47.5, 132.0], [47.6, 132.0], [47.7, 133.0], [47.8, 133.0], [47.9, 133.0], [48.0, 133.0], [48.1, 133.0], [48.2, 134.0], [48.3, 134.0], [48.4, 134.0], [48.5, 134.0], [48.6, 134.0], [48.7, 135.0], [48.8, 135.0], [48.9, 135.0], [49.0, 135.0], [49.1, 135.0], [49.2, 135.0], [49.3, 136.0], [49.4, 136.0], [49.5, 136.0], [49.6, 136.0], [49.7, 136.0], [49.8, 136.0], [49.9, 137.0], [50.0, 137.0], [50.1, 137.0], [50.2, 137.0], [50.3, 137.0], [50.4, 138.0], [50.5, 138.0], [50.6, 138.0], [50.7, 138.0], [50.8, 138.0], [50.9, 139.0], [51.0, 139.0], [51.1, 139.0], [51.2, 139.0], [51.3, 139.0], [51.4, 139.0], [51.5, 140.0], [51.6, 140.0], [51.7, 140.0], [51.8, 140.0], [51.9, 140.0], [52.0, 141.0], [52.1, 141.0], [52.2, 141.0], [52.3, 141.0], [52.4, 141.0], [52.5, 141.0], [52.6, 142.0], [52.7, 142.0], [52.8, 142.0], [52.9, 143.0], [53.0, 143.0], [53.1, 143.0], [53.2, 143.0], [53.3, 144.0], [53.4, 144.0], [53.5, 144.0], [53.6, 144.0], [53.7, 145.0], [53.8, 145.0], [53.9, 145.0], [54.0, 145.0], [54.1, 146.0], [54.2, 146.0], [54.3, 146.0], [54.4, 146.0], [54.5, 147.0], [54.6, 147.0], [54.7, 147.0], [54.8, 147.0], [54.9, 148.0], [55.0, 148.0], [55.1, 148.0], [55.2, 148.0], [55.3, 148.0], [55.4, 149.0], [55.5, 149.0], [55.6, 149.0], [55.7, 149.0], [55.8, 149.0], [55.9, 150.0], [56.0, 150.0], [56.1, 150.0], [56.2, 150.0], [56.3, 150.0], [56.4, 151.0], [56.5, 151.0], [56.6, 151.0], [56.7, 151.0], [56.8, 152.0], [56.9, 152.0], [57.0, 152.0], [57.1, 152.0], [57.2, 152.0], [57.3, 153.0], [57.4, 153.0], [57.5, 153.0], [57.6, 153.0], [57.7, 154.0], [57.8, 154.0], [57.9, 154.0], [58.0, 154.0], [58.1, 154.0], [58.2, 155.0], [58.3, 155.0], [58.4, 155.0], [58.5, 156.0], [58.6, 156.0], [58.7, 156.0], [58.8, 156.0], [58.9, 156.0], [59.0, 157.0], [59.1, 157.0], [59.2, 157.0], [59.3, 157.0], [59.4, 157.0], [59.5, 158.0], [59.6, 158.0], [59.7, 158.0], [59.8, 159.0], [59.9, 159.0], [60.0, 159.0], [60.1, 159.0], [60.2, 160.0], [60.3, 160.0], [60.4, 160.0], [60.5, 160.0], [60.6, 161.0], [60.7, 161.0], [60.8, 161.0], [60.9, 162.0], [61.0, 162.0], [61.1, 162.0], [61.2, 162.0], [61.3, 162.0], [61.4, 163.0], [61.5, 163.0], [61.6, 163.0], [61.7, 163.0], [61.8, 164.0], [61.9, 164.0], [62.0, 164.0], [62.1, 164.0], [62.2, 165.0], [62.3, 165.0], [62.4, 165.0], [62.5, 165.0], [62.6, 165.0], [62.7, 166.0], [62.8, 166.0], [62.9, 166.0], [63.0, 166.0], [63.1, 167.0], [63.2, 167.0], [63.3, 167.0], [63.4, 167.0], [63.5, 168.0], [63.6, 168.0], [63.7, 168.0], [63.8, 169.0], [63.9, 169.0], [64.0, 169.0], [64.1, 169.0], [64.2, 169.0], [64.3, 170.0], [64.4, 170.0], [64.5, 170.0], [64.6, 170.0], [64.7, 171.0], [64.8, 171.0], [64.9, 171.0], [65.0, 171.0], [65.1, 172.0], [65.2, 172.0], [65.3, 172.0], [65.4, 172.0], [65.5, 172.0], [65.6, 173.0], [65.7, 173.0], [65.8, 173.0], [65.9, 173.0], [66.0, 174.0], [66.1, 174.0], [66.2, 174.0], [66.3, 174.0], [66.4, 174.0], [66.5, 175.0], [66.6, 175.0], [66.7, 175.0], [66.8, 176.0], [66.9, 176.0], [67.0, 176.0], [67.1, 176.0], [67.2, 177.0], [67.3, 177.0], [67.4, 177.0], [67.5, 177.0], [67.6, 178.0], [67.7, 178.0], [67.8, 178.0], [67.9, 179.0], [68.0, 179.0], [68.1, 179.0], [68.2, 180.0], [68.3, 180.0], [68.4, 180.0], [68.5, 180.0], [68.6, 181.0], [68.7, 181.0], [68.8, 181.0], [68.9, 182.0], [69.0, 182.0], [69.1, 182.0], [69.2, 183.0], [69.3, 183.0], [69.4, 183.0], [69.5, 183.0], [69.6, 184.0], [69.7, 184.0], [69.8, 184.0], [69.9, 185.0], [70.0, 185.0], [70.1, 185.0], [70.2, 186.0], [70.3, 186.0], [70.4, 186.0], [70.5, 186.0], [70.6, 187.0], [70.7, 187.0], [70.8, 187.0], [70.9, 187.0], [71.0, 188.0], [71.1, 188.0], [71.2, 188.0], [71.3, 189.0], [71.4, 189.0], [71.5, 189.0], [71.6, 189.0], [71.7, 190.0], [71.8, 190.0], [71.9, 191.0], [72.0, 191.0], [72.1, 192.0], [72.2, 192.0], [72.3, 192.0], [72.4, 192.0], [72.5, 193.0], [72.6, 193.0], [72.7, 193.0], [72.8, 194.0], [72.9, 194.0], [73.0, 194.0], [73.1, 195.0], [73.2, 195.0], [73.3, 196.0], [73.4, 196.0], [73.5, 196.0], [73.6, 197.0], [73.7, 197.0], [73.8, 197.0], [73.9, 198.0], [74.0, 198.0], [74.1, 199.0], [74.2, 199.0], [74.3, 200.0], [74.4, 200.0], [74.5, 201.0], [74.6, 201.0], [74.7, 201.0], [74.8, 202.0], [74.9, 202.0], [75.0, 202.0], [75.1, 203.0], [75.2, 203.0], [75.3, 203.0], [75.4, 204.0], [75.5, 204.0], [75.6, 204.0], [75.7, 204.0], [75.8, 205.0], [75.9, 205.0], [76.0, 205.0], [76.1, 206.0], [76.2, 206.0], [76.3, 206.0], [76.4, 207.0], [76.5, 207.0], [76.6, 207.0], [76.7, 208.0], [76.8, 208.0], [76.9, 209.0], [77.0, 209.0], [77.1, 209.0], [77.2, 210.0], [77.3, 210.0], [77.4, 211.0], [77.5, 211.0], [77.6, 211.0], [77.7, 211.0], [77.8, 212.0], [77.9, 212.0], [78.0, 213.0], [78.1, 213.0], [78.2, 213.0], [78.3, 214.0], [78.4, 214.0], [78.5, 215.0], [78.6, 215.0], [78.7, 215.0], [78.8, 216.0], [78.9, 216.0], [79.0, 216.0], [79.1, 217.0], [79.2, 217.0], [79.3, 218.0], [79.4, 218.0], [79.5, 218.0], [79.6, 219.0], [79.7, 219.0], [79.8, 220.0], [79.9, 220.0], [80.0, 220.0], [80.1, 221.0], [80.2, 222.0], [80.3, 222.0], [80.4, 222.0], [80.5, 223.0], [80.6, 223.0], [80.7, 224.0], [80.8, 224.0], [80.9, 225.0], [81.0, 226.0], [81.1, 226.0], [81.2, 226.0], [81.3, 226.0], [81.4, 227.0], [81.5, 228.0], [81.6, 228.0], [81.7, 229.0], [81.8, 229.0], [81.9, 230.0], [82.0, 230.0], [82.1, 231.0], [82.2, 231.0], [82.3, 231.0], [82.4, 231.0], [82.5, 232.0], [82.6, 232.0], [82.7, 233.0], [82.8, 233.0], [82.9, 234.0], [83.0, 235.0], [83.1, 235.0], [83.2, 236.0], [83.3, 236.0], [83.4, 236.0], [83.5, 237.0], [83.6, 238.0], [83.7, 239.0], [83.8, 239.0], [83.9, 240.0], [84.0, 240.0], [84.1, 241.0], [84.2, 241.0], [84.3, 242.0], [84.4, 243.0], [84.5, 243.0], [84.6, 244.0], [84.7, 245.0], [84.8, 245.0], [84.9, 246.0], [85.0, 246.0], [85.1, 247.0], [85.2, 247.0], [85.3, 248.0], [85.4, 248.0], [85.5, 249.0], [85.6, 249.0], [85.7, 250.0], [85.8, 251.0], [85.9, 252.0], [86.0, 252.0], [86.1, 253.0], [86.2, 254.0], [86.3, 254.0], [86.4, 255.0], [86.5, 256.0], [86.6, 256.0], [86.7, 257.0], [86.8, 257.0], [86.9, 258.0], [87.0, 258.0], [87.1, 259.0], [87.2, 260.0], [87.3, 261.0], [87.4, 261.0], [87.5, 262.0], [87.6, 263.0], [87.7, 263.0], [87.8, 264.0], [87.9, 264.0], [88.0, 265.0], [88.1, 265.0], [88.2, 266.0], [88.3, 267.0], [88.4, 268.0], [88.5, 268.0], [88.6, 269.0], [88.7, 270.0], [88.8, 271.0], [88.9, 272.0], [89.0, 273.0], [89.1, 273.0], [89.2, 275.0], [89.3, 275.0], [89.4, 276.0], [89.5, 277.0], [89.6, 278.0], [89.7, 278.0], [89.8, 279.0], [89.9, 280.0], [90.0, 280.0], [90.1, 281.0], [90.2, 282.0], [90.3, 283.0], [90.4, 284.0], [90.5, 286.0], [90.6, 286.0], [90.7, 287.0], [90.8, 289.0], [90.9, 290.0], [91.0, 291.0], [91.1, 292.0], [91.2, 293.0], [91.3, 294.0], [91.4, 295.0], [91.5, 296.0], [91.6, 297.0], [91.7, 298.0], [91.8, 299.0], [91.9, 300.0], [92.0, 301.0], [92.1, 302.0], [92.2, 303.0], [92.3, 304.0], [92.4, 305.0], [92.5, 306.0], [92.6, 307.0], [92.7, 308.0], [92.8, 309.0], [92.9, 310.0], [93.0, 311.0], [93.1, 313.0], [93.2, 314.0], [93.3, 315.0], [93.4, 316.0], [93.5, 317.0], [93.6, 319.0], [93.7, 321.0], [93.8, 323.0], [93.9, 324.0], [94.0, 325.0], [94.1, 327.0], [94.2, 328.0], [94.3, 330.0], [94.4, 331.0], [94.5, 334.0], [94.6, 335.0], [94.7, 336.0], [94.8, 338.0], [94.9, 339.0], [95.0, 340.0], [95.1, 343.0], [95.2, 346.0], [95.3, 347.0], [95.4, 350.0], [95.5, 351.0], [95.6, 354.0], [95.7, 355.0], [95.8, 357.0], [95.9, 359.0], [96.0, 362.0], [96.1, 363.0], [96.2, 364.0], [96.3, 366.0], [96.4, 368.0], [96.5, 370.0], [96.6, 373.0], [96.7, 375.0], [96.8, 377.0], [96.9, 379.0], [97.0, 381.0], [97.1, 383.0], [97.2, 387.0], [97.3, 388.0], [97.4, 394.0], [97.5, 398.0], [97.6, 401.0], [97.7, 405.0], [97.8, 409.0], [97.9, 414.0], [98.0, 417.0], [98.1, 423.0], [98.2, 426.0], [98.3, 432.0], [98.4, 438.0], [98.5, 444.0], [98.6, 448.0], [98.7, 456.0], [98.8, 463.0], [98.9, 471.0], [99.0, 481.0], [99.1, 488.0], [99.2, 499.0], [99.3, 515.0], [99.4, 531.0], [99.5, 543.0], [99.6, 558.0], [99.7, 583.0], [99.8, 611.0], [99.9, 656.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 5685.0, "series": [{"data": [[0.0, 3703.0], [1100.0, 1.0], [300.0, 716.0], [600.0, 24.0], [700.0, 4.0], [100.0, 5685.0], [200.0, 2239.0], [400.0, 208.0], [800.0, 2.0], [500.0, 70.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 101.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 12551.0, "series": [{"data": [[0.0, 12551.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 101.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 39.816409245262506, "minX": 1.79069466E12, "maxY": 49.66278739710473, "series": [{"data": [[1.79069472E12, 49.66278739710473], [1.79069466E12, 39.816409245262506]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069472E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 18.54999999999999, "minX": 1.0, "maxY": 212.09589041095902, "series": [{"data": [[2.0, 18.54999999999999], [3.0, 32.352941176470594], [4.0, 32.0], [5.0, 34.33928571428572], [6.0, 41.3606557377049], [7.0, 50.52727272727274], [8.0, 42.77464788732394], [9.0, 46.19999999999999], [10.0, 49.97368421052631], [11.0, 75.10169491525423], [12.0, 102.32608695652173], [13.0, 78.67647058823532], [14.0, 75.36842105263158], [15.0, 72.3048780487805], [16.0, 73.38202247191015], [17.0, 83.68749999999999], [18.0, 86.78947368421052], [19.0, 99.37037037037038], [20.0, 80.62037037037041], [21.0, 83.33673469387755], [22.0, 86.62105263157895], [23.0, 74.98412698412699], [24.0, 84.78378378378379], [25.0, 91.73873873873877], [26.0, 101.40625], [27.0, 102.11818181818184], [28.0, 100.99099099099101], [29.0, 142.29729729729732], [30.0, 130.2872340425532], [31.0, 120.47663551401874], [32.0, 126.28124999999996], [33.0, 135.21782178217828], [34.0, 112.48305084745759], [35.0, 142.1089108910891], [36.0, 160.92771084337346], [37.0, 177.33333333333331], [38.0, 208.61445783132527], [39.0, 141.22549019607837], [40.0, 160.6888888888888], [41.0, 190.17999999999998], [42.0, 169.40425531914894], [43.0, 212.09589041095902], [44.0, 202.85416666666669], [45.0, 153.75675675675677], [46.0, 168.03539823008848], [47.0, 148.33333333333334], [48.0, 157.14529914529916], [49.0, 132.04635761589398], [50.0, 181.14087372830613], [1.0, 18.72727272727273]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[42.55817262092957, 158.28722731583983]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 27479.4, "minX": 1.79069466E12, "maxY": 84727.4, "series": [{"data": [[1.79069472E12, 32693.666666666668], [1.79069466E12, 84727.4]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79069472E12, 27479.4], [1.79069466E12, 71206.2]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069472E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 156.85978749041635, "minX": 1.79069466E12, "maxY": 161.9860913993755, "series": [{"data": [[1.79069472E12, 161.9860913993755], [1.79069466E12, 156.85978749041635]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069472E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 152.58483952240078, "minX": 1.79069466E12, "maxY": 157.46579619642327, "series": [{"data": [[1.79069472E12, 157.46579619642327], [1.79069466E12, 152.58483952240078]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069472E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79069466E12, "maxY": 0.016102530397633923, "series": [{"data": [[1.79069472E12, 0.0], [1.79069466E12, 0.016102530397633923]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069472E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 14.0, "minX": 1.79069466E12, "maxY": 1117.0, "series": [{"data": [[1.79069472E12, 838.0], [1.79069466E12, 1117.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79069472E12, 277.0], [1.79069466E12, 282.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79069472E12, 463.0], [1.79069466E12, 488.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79069472E12, 339.59999999999945], [1.79069466E12, 342.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79069472E12, 24.0], [1.79069466E12, 14.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79069472E12, 140.0], [1.79069466E12, 135.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069472E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 19.0, "minX": 29.0, "maxY": 230.0, "series": [{"data": [[120.0, 25.0], [141.0, 137.0], [144.0, 37.0], [151.0, 60.0], [168.0, 78.5], [181.0, 42.0], [198.0, 82.5], [194.0, 206.5], [205.0, 226.0], [201.0, 230.0], [208.0, 68.5], [213.0, 201.0], [219.0, 150.0], [224.0, 169.0], [231.0, 198.0], [226.0, 196.5], [235.0, 144.0], [232.0, 157.0], [255.0, 74.0], [252.0, 146.0], [251.0, 181.0], [259.0, 99.5], [262.0, 176.0], [261.0, 165.0], [257.0, 169.0], [282.0, 106.0], [274.0, 166.5], [284.0, 152.5], [273.0, 155.0], [292.0, 145.0], [290.0, 154.0], [289.0, 159.0], [301.0, 153.0], [316.0, 150.0], [312.0, 139.0], [304.0, 133.5], [324.0, 141.0], [337.0, 126.0], [339.0, 130.5], [348.0, 129.5], [336.0, 123.0], [356.0, 125.0], [29.0, 19.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 356.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 18.0, "minX": 29.0, "maxY": 224.0, "series": [{"data": [[120.0, 24.0], [141.0, 135.0], [144.0, 37.0], [151.0, 60.0], [168.0, 77.0], [181.0, 41.0], [198.0, 82.0], [194.0, 198.5], [205.0, 224.0], [201.0, 224.0], [208.0, 65.0], [213.0, 193.0], [219.0, 145.0], [224.0, 163.5], [231.0, 189.0], [226.0, 191.5], [235.0, 139.5], [232.0, 156.0], [255.0, 73.0], [252.0, 139.0], [251.0, 174.0], [259.0, 95.0], [262.0, 172.5], [261.0, 158.0], [257.0, 166.0], [282.0, 104.0], [274.0, 162.0], [284.0, 148.0], [273.0, 149.0], [292.0, 141.0], [290.0, 150.0], [289.0, 155.0], [301.0, 147.0], [316.0, 142.0], [312.0, 135.5], [304.0, 129.5], [324.0, 136.5], [337.0, 122.0], [339.0, 125.5], [348.0, 127.0], [336.0, 121.0], [356.0, 122.0], [29.0, 18.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 356.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 57.88333333333333, "minX": 1.79069466E12, "maxY": 152.98333333333332, "series": [{"data": [[1.79069472E12, 57.88333333333333], [1.79069466E12, 152.98333333333332]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069472E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 58.71666666666667, "minX": 1.79069466E12, "maxY": 152.15, "series": [{"data": [[1.79069472E12, 58.71666666666667], [1.79069466E12, 152.15]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069472E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 58.71666666666667, "minX": 1.79069466E12, "maxY": 152.15, "series": [{"data": [[1.79069472E12, 58.71666666666667], [1.79069466E12, 152.15]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069472E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 58.71666666666667, "minX": 1.79069466E12, "maxY": 152.15, "series": [{"data": [[1.79069472E12, 58.71666666666667], [1.79069466E12, 152.15]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069472E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

