/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 14.0, "minX": 0.0, "maxY": 3035.0, "series": [{"data": [[0.0, 14.0], [0.1, 17.0], [0.2, 19.0], [0.3, 22.0], [0.4, 25.0], [0.5, 27.0], [0.6, 28.0], [0.7, 31.0], [0.8, 32.0], [0.9, 34.0], [1.0, 35.0], [1.1, 36.0], [1.2, 37.0], [1.3, 38.0], [1.4, 39.0], [1.5, 40.0], [1.6, 41.0], [1.7, 42.0], [1.8, 43.0], [1.9, 44.0], [2.0, 44.0], [2.1, 45.0], [2.2, 46.0], [2.3, 47.0], [2.4, 48.0], [2.5, 49.0], [2.6, 50.0], [2.7, 51.0], [2.8, 51.0], [2.9, 52.0], [3.0, 53.0], [3.1, 54.0], [3.2, 55.0], [3.3, 56.0], [3.4, 57.0], [3.5, 57.0], [3.6, 58.0], [3.7, 58.0], [3.8, 59.0], [3.9, 60.0], [4.0, 61.0], [4.1, 62.0], [4.2, 62.0], [4.3, 63.0], [4.4, 64.0], [4.5, 65.0], [4.6, 65.0], [4.7, 66.0], [4.8, 67.0], [4.9, 68.0], [5.0, 68.0], [5.1, 69.0], [5.2, 70.0], [5.3, 70.0], [5.4, 71.0], [5.5, 72.0], [5.6, 72.0], [5.7, 73.0], [5.8, 74.0], [5.9, 75.0], [6.0, 75.0], [6.1, 76.0], [6.2, 77.0], [6.3, 78.0], [6.4, 78.0], [6.5, 79.0], [6.6, 79.0], [6.7, 80.0], [6.8, 81.0], [6.9, 81.0], [7.0, 82.0], [7.1, 83.0], [7.2, 84.0], [7.3, 84.0], [7.4, 85.0], [7.5, 85.0], [7.6, 86.0], [7.7, 86.0], [7.8, 87.0], [7.9, 88.0], [8.0, 88.0], [8.1, 89.0], [8.2, 90.0], [8.3, 90.0], [8.4, 91.0], [8.5, 92.0], [8.6, 92.0], [8.7, 93.0], [8.8, 93.0], [8.9, 94.0], [9.0, 95.0], [9.1, 95.0], [9.2, 96.0], [9.3, 96.0], [9.4, 97.0], [9.5, 97.0], [9.6, 98.0], [9.7, 98.0], [9.8, 99.0], [9.9, 99.0], [10.0, 100.0], [10.1, 100.0], [10.2, 101.0], [10.3, 101.0], [10.4, 102.0], [10.5, 102.0], [10.6, 103.0], [10.7, 103.0], [10.8, 103.0], [10.9, 104.0], [11.0, 104.0], [11.1, 105.0], [11.2, 105.0], [11.3, 106.0], [11.4, 106.0], [11.5, 107.0], [11.6, 107.0], [11.7, 108.0], [11.8, 108.0], [11.9, 109.0], [12.0, 109.0], [12.1, 110.0], [12.2, 110.0], [12.3, 110.0], [12.4, 111.0], [12.5, 111.0], [12.6, 111.0], [12.7, 112.0], [12.8, 112.0], [12.9, 113.0], [13.0, 113.0], [13.1, 113.0], [13.2, 114.0], [13.3, 114.0], [13.4, 115.0], [13.5, 115.0], [13.6, 116.0], [13.7, 116.0], [13.8, 116.0], [13.9, 117.0], [14.0, 117.0], [14.1, 118.0], [14.2, 118.0], [14.3, 118.0], [14.4, 119.0], [14.5, 119.0], [14.6, 119.0], [14.7, 120.0], [14.8, 120.0], [14.9, 121.0], [15.0, 121.0], [15.1, 121.0], [15.2, 122.0], [15.3, 122.0], [15.4, 122.0], [15.5, 123.0], [15.6, 123.0], [15.7, 123.0], [15.8, 124.0], [15.9, 124.0], [16.0, 124.0], [16.1, 125.0], [16.2, 125.0], [16.3, 125.0], [16.4, 126.0], [16.5, 126.0], [16.6, 126.0], [16.7, 126.0], [16.8, 127.0], [16.9, 127.0], [17.0, 127.0], [17.1, 128.0], [17.2, 128.0], [17.3, 128.0], [17.4, 128.0], [17.5, 129.0], [17.6, 129.0], [17.7, 129.0], [17.8, 130.0], [17.9, 130.0], [18.0, 130.0], [18.1, 130.0], [18.2, 131.0], [18.3, 131.0], [18.4, 131.0], [18.5, 131.0], [18.6, 132.0], [18.7, 132.0], [18.8, 132.0], [18.9, 132.0], [19.0, 133.0], [19.1, 133.0], [19.2, 133.0], [19.3, 133.0], [19.4, 134.0], [19.5, 134.0], [19.6, 134.0], [19.7, 134.0], [19.8, 135.0], [19.9, 135.0], [20.0, 135.0], [20.1, 135.0], [20.2, 136.0], [20.3, 136.0], [20.4, 136.0], [20.5, 137.0], [20.6, 137.0], [20.7, 137.0], [20.8, 137.0], [20.9, 137.0], [21.0, 138.0], [21.1, 138.0], [21.2, 138.0], [21.3, 138.0], [21.4, 139.0], [21.5, 139.0], [21.6, 139.0], [21.7, 140.0], [21.8, 140.0], [21.9, 140.0], [22.0, 141.0], [22.1, 141.0], [22.2, 141.0], [22.3, 141.0], [22.4, 141.0], [22.5, 142.0], [22.6, 142.0], [22.7, 142.0], [22.8, 142.0], [22.9, 143.0], [23.0, 143.0], [23.1, 143.0], [23.2, 143.0], [23.3, 144.0], [23.4, 144.0], [23.5, 144.0], [23.6, 144.0], [23.7, 145.0], [23.8, 145.0], [23.9, 145.0], [24.0, 145.0], [24.1, 146.0], [24.2, 146.0], [24.3, 146.0], [24.4, 146.0], [24.5, 147.0], [24.6, 147.0], [24.7, 147.0], [24.8, 147.0], [24.9, 148.0], [25.0, 148.0], [25.1, 148.0], [25.2, 148.0], [25.3, 148.0], [25.4, 149.0], [25.5, 149.0], [25.6, 149.0], [25.7, 149.0], [25.8, 150.0], [25.9, 150.0], [26.0, 150.0], [26.1, 150.0], [26.2, 151.0], [26.3, 151.0], [26.4, 151.0], [26.5, 151.0], [26.6, 152.0], [26.7, 152.0], [26.8, 152.0], [26.9, 152.0], [27.0, 152.0], [27.1, 153.0], [27.2, 153.0], [27.3, 153.0], [27.4, 154.0], [27.5, 154.0], [27.6, 154.0], [27.7, 154.0], [27.8, 155.0], [27.9, 155.0], [28.0, 155.0], [28.1, 155.0], [28.2, 156.0], [28.3, 156.0], [28.4, 156.0], [28.5, 156.0], [28.6, 157.0], [28.7, 157.0], [28.8, 157.0], [28.9, 157.0], [29.0, 157.0], [29.1, 158.0], [29.2, 158.0], [29.3, 158.0], [29.4, 158.0], [29.5, 158.0], [29.6, 159.0], [29.7, 159.0], [29.8, 159.0], [29.9, 159.0], [30.0, 159.0], [30.1, 160.0], [30.2, 160.0], [30.3, 160.0], [30.4, 160.0], [30.5, 160.0], [30.6, 161.0], [30.7, 161.0], [30.8, 161.0], [30.9, 161.0], [31.0, 161.0], [31.1, 162.0], [31.2, 162.0], [31.3, 162.0], [31.4, 162.0], [31.5, 163.0], [31.6, 163.0], [31.7, 163.0], [31.8, 163.0], [31.9, 164.0], [32.0, 164.0], [32.1, 164.0], [32.2, 164.0], [32.3, 164.0], [32.4, 165.0], [32.5, 165.0], [32.6, 165.0], [32.7, 165.0], [32.8, 165.0], [32.9, 166.0], [33.0, 166.0], [33.1, 166.0], [33.2, 166.0], [33.3, 167.0], [33.4, 167.0], [33.5, 167.0], [33.6, 167.0], [33.7, 167.0], [33.8, 168.0], [33.9, 168.0], [34.0, 168.0], [34.1, 168.0], [34.2, 168.0], [34.3, 169.0], [34.4, 169.0], [34.5, 169.0], [34.6, 169.0], [34.7, 169.0], [34.8, 170.0], [34.9, 170.0], [35.0, 170.0], [35.1, 170.0], [35.2, 170.0], [35.3, 171.0], [35.4, 171.0], [35.5, 171.0], [35.6, 171.0], [35.7, 171.0], [35.8, 172.0], [35.9, 172.0], [36.0, 172.0], [36.1, 172.0], [36.2, 173.0], [36.3, 173.0], [36.4, 173.0], [36.5, 173.0], [36.6, 173.0], [36.7, 174.0], [36.8, 174.0], [36.9, 174.0], [37.0, 174.0], [37.1, 174.0], [37.2, 175.0], [37.3, 175.0], [37.4, 175.0], [37.5, 175.0], [37.6, 175.0], [37.7, 176.0], [37.8, 176.0], [37.9, 176.0], [38.0, 176.0], [38.1, 176.0], [38.2, 177.0], [38.3, 177.0], [38.4, 177.0], [38.5, 177.0], [38.6, 178.0], [38.7, 178.0], [38.8, 178.0], [38.9, 178.0], [39.0, 179.0], [39.1, 179.0], [39.2, 179.0], [39.3, 179.0], [39.4, 180.0], [39.5, 180.0], [39.6, 180.0], [39.7, 180.0], [39.8, 181.0], [39.9, 181.0], [40.0, 181.0], [40.1, 181.0], [40.2, 181.0], [40.3, 182.0], [40.4, 182.0], [40.5, 182.0], [40.6, 182.0], [40.7, 183.0], [40.8, 183.0], [40.9, 183.0], [41.0, 183.0], [41.1, 184.0], [41.2, 184.0], [41.3, 184.0], [41.4, 184.0], [41.5, 185.0], [41.6, 185.0], [41.7, 185.0], [41.8, 185.0], [41.9, 186.0], [42.0, 186.0], [42.1, 186.0], [42.2, 186.0], [42.3, 187.0], [42.4, 187.0], [42.5, 187.0], [42.6, 188.0], [42.7, 188.0], [42.8, 188.0], [42.9, 188.0], [43.0, 188.0], [43.1, 189.0], [43.2, 189.0], [43.3, 189.0], [43.4, 189.0], [43.5, 190.0], [43.6, 190.0], [43.7, 190.0], [43.8, 190.0], [43.9, 191.0], [44.0, 191.0], [44.1, 191.0], [44.2, 191.0], [44.3, 192.0], [44.4, 192.0], [44.5, 192.0], [44.6, 192.0], [44.7, 193.0], [44.8, 193.0], [44.9, 193.0], [45.0, 193.0], [45.1, 194.0], [45.2, 194.0], [45.3, 194.0], [45.4, 194.0], [45.5, 195.0], [45.6, 195.0], [45.7, 195.0], [45.8, 196.0], [45.9, 196.0], [46.0, 196.0], [46.1, 196.0], [46.2, 197.0], [46.3, 197.0], [46.4, 197.0], [46.5, 197.0], [46.6, 198.0], [46.7, 198.0], [46.8, 198.0], [46.9, 198.0], [47.0, 199.0], [47.1, 199.0], [47.2, 199.0], [47.3, 199.0], [47.4, 200.0], [47.5, 200.0], [47.6, 200.0], [47.7, 201.0], [47.8, 201.0], [47.9, 201.0], [48.0, 201.0], [48.1, 202.0], [48.2, 202.0], [48.3, 202.0], [48.4, 202.0], [48.5, 203.0], [48.6, 203.0], [48.7, 203.0], [48.8, 203.0], [48.9, 204.0], [49.0, 204.0], [49.1, 204.0], [49.2, 204.0], [49.3, 205.0], [49.4, 205.0], [49.5, 205.0], [49.6, 205.0], [49.7, 206.0], [49.8, 206.0], [49.9, 206.0], [50.0, 206.0], [50.1, 207.0], [50.2, 207.0], [50.3, 207.0], [50.4, 207.0], [50.5, 208.0], [50.6, 208.0], [50.7, 208.0], [50.8, 208.0], [50.9, 208.0], [51.0, 209.0], [51.1, 209.0], [51.2, 209.0], [51.3, 209.0], [51.4, 210.0], [51.5, 210.0], [51.6, 210.0], [51.7, 210.0], [51.8, 211.0], [51.9, 211.0], [52.0, 211.0], [52.1, 211.0], [52.2, 212.0], [52.3, 212.0], [52.4, 212.0], [52.5, 213.0], [52.6, 213.0], [52.7, 213.0], [52.8, 213.0], [52.9, 214.0], [53.0, 214.0], [53.1, 214.0], [53.2, 214.0], [53.3, 215.0], [53.4, 215.0], [53.5, 215.0], [53.6, 216.0], [53.7, 216.0], [53.8, 216.0], [53.9, 217.0], [54.0, 217.0], [54.1, 217.0], [54.2, 217.0], [54.3, 218.0], [54.4, 218.0], [54.5, 218.0], [54.6, 219.0], [54.7, 219.0], [54.8, 219.0], [54.9, 219.0], [55.0, 220.0], [55.1, 220.0], [55.2, 220.0], [55.3, 220.0], [55.4, 221.0], [55.5, 221.0], [55.6, 221.0], [55.7, 222.0], [55.8, 222.0], [55.9, 222.0], [56.0, 222.0], [56.1, 223.0], [56.2, 223.0], [56.3, 223.0], [56.4, 224.0], [56.5, 224.0], [56.6, 224.0], [56.7, 224.0], [56.8, 225.0], [56.9, 225.0], [57.0, 225.0], [57.1, 226.0], [57.2, 226.0], [57.3, 226.0], [57.4, 227.0], [57.5, 227.0], [57.6, 227.0], [57.7, 227.0], [57.8, 228.0], [57.9, 228.0], [58.0, 228.0], [58.1, 229.0], [58.2, 229.0], [58.3, 229.0], [58.4, 230.0], [58.5, 230.0], [58.6, 230.0], [58.7, 230.0], [58.8, 231.0], [58.9, 231.0], [59.0, 231.0], [59.1, 232.0], [59.2, 232.0], [59.3, 232.0], [59.4, 232.0], [59.5, 233.0], [59.6, 233.0], [59.7, 233.0], [59.8, 234.0], [59.9, 234.0], [60.0, 234.0], [60.1, 235.0], [60.2, 235.0], [60.3, 235.0], [60.4, 235.0], [60.5, 236.0], [60.6, 236.0], [60.7, 236.0], [60.8, 237.0], [60.9, 237.0], [61.0, 237.0], [61.1, 238.0], [61.2, 238.0], [61.3, 238.0], [61.4, 239.0], [61.5, 239.0], [61.6, 239.0], [61.7, 240.0], [61.8, 240.0], [61.9, 240.0], [62.0, 241.0], [62.1, 241.0], [62.2, 241.0], [62.3, 241.0], [62.4, 242.0], [62.5, 242.0], [62.6, 243.0], [62.7, 243.0], [62.8, 243.0], [62.9, 244.0], [63.0, 244.0], [63.1, 244.0], [63.2, 245.0], [63.3, 245.0], [63.4, 245.0], [63.5, 246.0], [63.6, 246.0], [63.7, 246.0], [63.8, 247.0], [63.9, 247.0], [64.0, 247.0], [64.1, 248.0], [64.2, 248.0], [64.3, 248.0], [64.4, 249.0], [64.5, 249.0], [64.6, 249.0], [64.7, 250.0], [64.8, 250.0], [64.9, 250.0], [65.0, 251.0], [65.1, 251.0], [65.2, 251.0], [65.3, 252.0], [65.4, 252.0], [65.5, 252.0], [65.6, 253.0], [65.7, 253.0], [65.8, 253.0], [65.9, 254.0], [66.0, 254.0], [66.1, 254.0], [66.2, 255.0], [66.3, 255.0], [66.4, 255.0], [66.5, 256.0], [66.6, 256.0], [66.7, 256.0], [66.8, 257.0], [66.9, 257.0], [67.0, 258.0], [67.1, 258.0], [67.2, 258.0], [67.3, 259.0], [67.4, 259.0], [67.5, 259.0], [67.6, 260.0], [67.7, 260.0], [67.8, 260.0], [67.9, 260.0], [68.0, 261.0], [68.1, 261.0], [68.2, 261.0], [68.3, 262.0], [68.4, 262.0], [68.5, 263.0], [68.6, 263.0], [68.7, 263.0], [68.8, 264.0], [68.9, 264.0], [69.0, 265.0], [69.1, 265.0], [69.2, 265.0], [69.3, 266.0], [69.4, 266.0], [69.5, 267.0], [69.6, 267.0], [69.7, 267.0], [69.8, 268.0], [69.9, 268.0], [70.0, 268.0], [70.1, 269.0], [70.2, 269.0], [70.3, 270.0], [70.4, 270.0], [70.5, 271.0], [70.6, 271.0], [70.7, 272.0], [70.8, 272.0], [70.9, 272.0], [71.0, 273.0], [71.1, 273.0], [71.2, 273.0], [71.3, 274.0], [71.4, 274.0], [71.5, 275.0], [71.6, 275.0], [71.7, 275.0], [71.8, 276.0], [71.9, 276.0], [72.0, 276.0], [72.1, 277.0], [72.2, 277.0], [72.3, 278.0], [72.4, 278.0], [72.5, 278.0], [72.6, 279.0], [72.7, 279.0], [72.8, 279.0], [72.9, 280.0], [73.0, 280.0], [73.1, 281.0], [73.2, 281.0], [73.3, 282.0], [73.4, 282.0], [73.5, 282.0], [73.6, 283.0], [73.7, 283.0], [73.8, 284.0], [73.9, 284.0], [74.0, 284.0], [74.1, 285.0], [74.2, 285.0], [74.3, 285.0], [74.4, 286.0], [74.5, 286.0], [74.6, 287.0], [74.7, 287.0], [74.8, 288.0], [74.9, 288.0], [75.0, 289.0], [75.1, 289.0], [75.2, 289.0], [75.3, 290.0], [75.4, 290.0], [75.5, 291.0], [75.6, 291.0], [75.7, 292.0], [75.8, 292.0], [75.9, 293.0], [76.0, 293.0], [76.1, 294.0], [76.2, 294.0], [76.3, 294.0], [76.4, 295.0], [76.5, 295.0], [76.6, 296.0], [76.7, 296.0], [76.8, 297.0], [76.9, 298.0], [77.0, 298.0], [77.1, 299.0], [77.2, 299.0], [77.3, 300.0], [77.4, 300.0], [77.5, 301.0], [77.6, 301.0], [77.7, 302.0], [77.8, 302.0], [77.9, 302.0], [78.0, 303.0], [78.1, 304.0], [78.2, 304.0], [78.3, 305.0], [78.4, 305.0], [78.5, 306.0], [78.6, 306.0], [78.7, 307.0], [78.8, 308.0], [78.9, 308.0], [79.0, 309.0], [79.1, 309.0], [79.2, 310.0], [79.3, 310.0], [79.4, 311.0], [79.5, 312.0], [79.6, 312.0], [79.7, 313.0], [79.8, 313.0], [79.9, 314.0], [80.0, 314.0], [80.1, 315.0], [80.2, 315.0], [80.3, 316.0], [80.4, 317.0], [80.5, 317.0], [80.6, 318.0], [80.7, 318.0], [80.8, 319.0], [80.9, 319.0], [81.0, 320.0], [81.1, 321.0], [81.2, 321.0], [81.3, 322.0], [81.4, 323.0], [81.5, 323.0], [81.6, 324.0], [81.7, 324.0], [81.8, 325.0], [81.9, 325.0], [82.0, 326.0], [82.1, 327.0], [82.2, 327.0], [82.3, 328.0], [82.4, 328.0], [82.5, 329.0], [82.6, 330.0], [82.7, 330.0], [82.8, 331.0], [82.9, 332.0], [83.0, 332.0], [83.1, 333.0], [83.2, 333.0], [83.3, 334.0], [83.4, 335.0], [83.5, 336.0], [83.6, 337.0], [83.7, 337.0], [83.8, 338.0], [83.9, 339.0], [84.0, 340.0], [84.1, 340.0], [84.2, 341.0], [84.3, 342.0], [84.4, 342.0], [84.5, 344.0], [84.6, 345.0], [84.7, 345.0], [84.8, 346.0], [84.9, 347.0], [85.0, 348.0], [85.1, 349.0], [85.2, 350.0], [85.3, 351.0], [85.4, 351.0], [85.5, 352.0], [85.6, 353.0], [85.7, 354.0], [85.8, 355.0], [85.9, 356.0], [86.0, 357.0], [86.1, 358.0], [86.2, 359.0], [86.3, 360.0], [86.4, 361.0], [86.5, 362.0], [86.6, 363.0], [86.7, 364.0], [86.8, 365.0], [86.9, 366.0], [87.0, 367.0], [87.1, 368.0], [87.2, 369.0], [87.3, 370.0], [87.4, 371.0], [87.5, 372.0], [87.6, 373.0], [87.7, 374.0], [87.8, 375.0], [87.9, 376.0], [88.0, 377.0], [88.1, 378.0], [88.2, 379.0], [88.3, 380.0], [88.4, 381.0], [88.5, 381.0], [88.6, 382.0], [88.7, 383.0], [88.8, 384.0], [88.9, 385.0], [89.0, 386.0], [89.1, 387.0], [89.2, 388.0], [89.3, 389.0], [89.4, 390.0], [89.5, 391.0], [89.6, 392.0], [89.7, 394.0], [89.8, 395.0], [89.9, 397.0], [90.0, 398.0], [90.1, 399.0], [90.2, 400.0], [90.3, 402.0], [90.4, 403.0], [90.5, 404.0], [90.6, 406.0], [90.7, 407.0], [90.8, 408.0], [90.9, 410.0], [91.0, 411.0], [91.1, 413.0], [91.2, 414.0], [91.3, 415.0], [91.4, 417.0], [91.5, 418.0], [91.6, 419.0], [91.7, 420.0], [91.8, 421.0], [91.9, 422.0], [92.0, 423.0], [92.1, 424.0], [92.2, 426.0], [92.3, 427.0], [92.4, 427.0], [92.5, 429.0], [92.6, 430.0], [92.7, 431.0], [92.8, 433.0], [92.9, 434.0], [93.0, 436.0], [93.1, 437.0], [93.2, 439.0], [93.3, 441.0], [93.4, 442.0], [93.5, 445.0], [93.6, 447.0], [93.7, 448.0], [93.8, 450.0], [93.9, 452.0], [94.0, 453.0], [94.1, 454.0], [94.2, 456.0], [94.3, 458.0], [94.4, 460.0], [94.5, 462.0], [94.6, 464.0], [94.7, 466.0], [94.8, 468.0], [94.9, 470.0], [95.0, 472.0], [95.1, 475.0], [95.2, 477.0], [95.3, 479.0], [95.4, 482.0], [95.5, 485.0], [95.6, 487.0], [95.7, 489.0], [95.8, 492.0], [95.9, 495.0], [96.0, 499.0], [96.1, 502.0], [96.2, 506.0], [96.3, 509.0], [96.4, 512.0], [96.5, 517.0], [96.6, 520.0], [96.7, 525.0], [96.8, 532.0], [96.9, 536.0], [97.0, 542.0], [97.1, 549.0], [97.2, 556.0], [97.3, 564.0], [97.4, 569.0], [97.5, 576.0], [97.6, 581.0], [97.7, 587.0], [97.8, 594.0], [97.9, 600.0], [98.0, 614.0], [98.1, 627.0], [98.2, 641.0], [98.3, 658.0], [98.4, 683.0], [98.5, 707.0], [98.6, 728.0], [98.7, 781.0], [98.8, 831.0], [98.9, 896.0], [99.0, 1133.0], [99.1, 1174.0], [99.2, 1220.0], [99.3, 1259.0], [99.4, 1306.0], [99.5, 1444.0], [99.6, 2752.0], [99.7, 2867.0], [99.8, 2896.0], [99.9, 2932.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 12178.0, "series": [{"data": [[0.0, 3241.0], [600.0, 196.0], [700.0, 89.0], [800.0, 51.0], [900.0, 18.0], [1000.0, 12.0], [1100.0, 57.0], [1200.0, 68.0], [1300.0, 32.0], [1400.0, 20.0], [1500.0, 4.0], [100.0, 12178.0], [1600.0, 3.0], [1800.0, 1.0], [1900.0, 1.0], [2000.0, 1.0], [2300.0, 1.0], [2200.0, 1.0], [2400.0, 3.0], [2600.0, 1.0], [2700.0, 11.0], [2800.0, 60.0], [2900.0, 59.0], [3000.0, 3.0], [200.0, 9752.0], [300.0, 4200.0], [400.0, 1924.0], [500.0, 602.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 3000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 149.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 31306.0, "series": [{"data": [[0.0, 31306.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 1134.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 149.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 148.21529504121457, "minX": 1.79069454E12, "maxY": 198.7533953649654, "series": [{"data": [[1.7906946E12, 198.7533953649654], [1.79069454E12, 148.21529504121457]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906946E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 19.612903225806452, "minX": 1.0, "maxY": 2774.3658536585367, "series": [{"data": [[4.0, 75.92307692307693], [5.0, 25.647058823529413], [6.0, 19.612903225806452], [7.0, 39.696969696969695], [8.0, 20.9], [9.0, 49.407407407407405], [10.0, 37.0], [11.0, 43.70588235294117], [12.0, 40.20588235294118], [13.0, 43.166666666666664], [14.0, 53.86486486486488], [15.0, 41.525000000000006], [16.0, 38.45945945945945], [17.0, 43.735294117647065], [18.0, 58.743589743589745], [19.0, 58.37500000000001], [20.0, 52.49999999999999], [21.0, 47.789473684210535], [22.0, 54.11904761904762], [23.0, 51.02439024390243], [24.0, 63.7659574468085], [25.0, 50.23076923076923], [26.0, 60.92307692307692], [27.0, 63.46875], [28.0, 61.576923076923066], [29.0, 74.11428571428571], [30.0, 74.60869565217394], [31.0, 66.0909090909091], [32.0, 68.79032258064518], [33.0, 68.56666666666665], [34.0, 102.47826086956522], [35.0, 136.6521739130435], [36.0, 108.11363636363636], [37.0, 89.29032258064514], [38.0, 72.36363636363636], [39.0, 79.65306122448979], [40.0, 57.357142857142854], [41.0, 66.47058823529412], [42.0, 65.52702702702702], [43.0, 66.0], [44.0, 62.489795918367356], [45.0, 72.28070175438596], [46.0, 92.33846153846156], [47.0, 72.32142857142856], [48.0, 89.78846153846152], [49.0, 94.72972972972973], [50.0, 136.38636363636363], [51.0, 110.58139534883722], [52.0, 143.93939393939397], [53.0, 155.35999999999999], [54.0, 170.7906976744186], [55.0, 135.0322580645161], [56.0, 198.93749999999997], [57.0, 238.84374999999994], [58.0, 171.9111111111111], [59.0, 139.1212121212121], [60.0, 134.79661016949146], [61.0, 123.8], [62.0, 153.13333333333335], [63.0, 138.17857142857144], [64.0, 149.6949152542373], [65.0, 112.56250000000001], [66.0, 136.5614035087719], [67.0, 217.6], [68.0, 221.4], [69.0, 246.86206896551718], [70.0, 230.99999999999997], [71.0, 294.69565217391306], [72.0, 283.1379310344827], [73.0, 232.36538461538456], [74.0, 151.82978723404258], [75.0, 221.7], [76.0, 247.6296296296296], [77.0, 244.68421052631572], [78.0, 160.82222222222217], [79.0, 186.70588235294122], [80.0, 204.82926829268294], [81.0, 215.0], [82.0, 195.11538461538464], [83.0, 177.96000000000006], [84.0, 131.26190476190473], [85.0, 184.22500000000005], [86.0, 140.38297872340428], [87.0, 160.88235294117646], [88.0, 169.43137254901958], [89.0, 152.32467532467535], [90.0, 157.04081632653057], [91.0, 158.17999999999998], [92.0, 168.60714285714283], [93.0, 134.57500000000002], [94.0, 139.68888888888893], [95.0, 192.91525423728808], [96.0, 131.8656716417911], [97.0, 166.90476190476193], [98.0, 177.61290322580646], [99.0, 133.90624999999997], [100.0, 186.5166666666667], [101.0, 177.4426229508197], [102.0, 160.07272727272726], [103.0, 224.91666666666666], [104.0, 247.40540540540545], [105.0, 251.64179104477608], [106.0, 194.18], [107.0, 162.75294117647056], [108.0, 161.94736842105263], [109.0, 201.1666666666667], [110.0, 217.03703703703698], [111.0, 182.7321428571429], [112.0, 115.23255813953489], [113.0, 168.1020408163266], [114.0, 148.0208333333333], [115.0, 180.22916666666666], [116.0, 211.86956521739123], [117.0, 151.67543859649123], [118.0, 125.94936708860759], [119.0, 134.3461538461538], [120.0, 148.94308943089433], [121.0, 105.02564102564102], [122.0, 177.61904761904762], [123.0, 201.30827067669165], [124.0, 105.25581395348837], [125.0, 154.04477611940294], [126.0, 114.11428571428571], [127.0, 163.79710144927546], [128.0, 94.68], [130.0, 210.7133333333333], [131.0, 102.94999999999999], [133.0, 168.85714285714286], [129.0, 166.4], [140.0, 309.0], [139.0, 316.0], [138.0, 189.0], [151.0, 246.875], [147.0, 194.25], [144.0, 184.2], [157.0, 1108.0], [158.0, 2558.9166666666665], [159.0, 2774.3658536585367], [155.0, 221.0], [160.0, 2332.095238095238], [161.0, 784.8749999999998], [162.0, 303.74528301886795], [163.0, 276.3333333333333], [166.0, 458.27950310559004], [167.0, 191.0], [165.0, 167.1], [169.0, 384.0], [171.0, 446.3542857142859], [172.0, 106.24242424242424], [173.0, 204.0], [175.0, 193.5], [174.0, 175.66666666666666], [168.0, 122.8], [183.0, 1181.0322580645159], [184.0, 1225.0317460317463], [185.0, 504.5405405405406], [186.0, 695.0625], [187.0, 426.2238805970149], [188.0, 374.6153846153845], [189.0, 308.3939393939395], [190.0, 358.45205479452056], [191.0, 278.47826086956513], [192.0, 404.7368421052631], [193.0, 433.8586956521738], [194.0, 370.2079207920792], [195.0, 244.0], [196.0, 298.8474576271186], [197.0, 310.3], [198.0, 262.3888888888889], [199.0, 258.32835820895514], [200.0, 244.59460342082602], [1.0, 216.0]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[175.04829850563084, 245.1891435760543]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 200.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 119230.8, "minX": 1.79069454E12, "maxY": 160111.55, "series": [{"data": [[1.7906946E12, 160111.55], [1.79069454E12, 141466.6]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.7906946E12, 134963.4], [1.79069454E12, 119230.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906946E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 235.74778940068126, "minX": 1.79069454E12, "maxY": 255.87629203192571, "series": [{"data": [[1.7906946E12, 235.74778940068126], [1.79069454E12, 255.87629203192571]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906946E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 234.51921632086885, "minX": 1.79069454E12, "maxY": 254.6381002224248, "series": [{"data": [[1.7906946E12, 234.51921632086885], [1.79069454E12, 254.6381002224248]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906946E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79069454E12, "maxY": 0.047625278032186386, "series": [{"data": [[1.7906946E12, 0.0], [1.79069454E12, 0.047625278032186386]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906946E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 14.0, "minX": 1.79069454E12, "maxY": 3035.0, "series": [{"data": [[1.7906946E12, 1165.0], [1.79069454E12, 3035.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.7906946E12, 380.0], [1.79069454E12, 418.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.7906946E12, 660.9199999999983], [1.79069454E12, 1465.1299999999992]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.7906946E12, 454.0], [1.79069454E12, 489.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.7906946E12, 20.0], [1.79069454E12, 14.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.7906946E12, 210.0], [1.79069454E12, 201.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906946E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 24.5, "minX": 5.0, "maxY": 2752.0, "series": [{"data": [[528.0, 341.0], [516.0, 328.0], [558.0, 150.0], [557.0, 179.0], [571.0, 286.0], [563.0, 319.0], [584.0, 339.0], [617.0, 64.0], [661.0, 170.0], [649.0, 294.0], [663.0, 281.0], [718.0, 270.5], [46.0, 24.5], [767.0, 218.0], [751.0, 251.0], [748.0, 260.0], [776.0, 171.5], [815.0, 148.0], [826.0, 193.0], [814.0, 218.0], [822.0, 259.0], [880.0, 247.0], [905.0, 217.0], [930.0, 217.5], [961.0, 212.0], [992.0, 202.0], [1017.0, 173.0], [1037.0, 173.0], [1030.0, 188.0], [1106.0, 168.0], [1112.0, 194.5], [1148.0, 181.0], [1114.0, 175.0], [5.0, 2752.0], [212.0, 453.5], [221.0, 186.0], [278.0, 224.0], [301.0, 34.0], [315.0, 1169.0], [366.0, 118.0], [397.0, 67.0], [405.0, 47.0], [421.0, 409.0], [425.0, 198.0], [436.0, 138.0], [460.0, 458.0], [473.0, 169.0], [464.0, 312.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1148.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 23.0, "minX": 5.0, "maxY": 2752.0, "series": [{"data": [[528.0, 340.0], [516.0, 319.0], [558.0, 150.0], [557.0, 178.0], [571.0, 286.0], [563.0, 317.0], [584.0, 337.0], [617.0, 62.0], [661.0, 167.0], [649.0, 293.0], [663.0, 280.0], [718.0, 270.0], [46.0, 23.0], [767.0, 215.0], [751.0, 250.0], [748.0, 259.0], [776.0, 171.0], [815.0, 147.0], [826.0, 192.5], [814.0, 218.0], [822.0, 259.0], [880.0, 245.0], [905.0, 216.0], [930.0, 215.0], [961.0, 211.0], [992.0, 201.5], [1017.0, 172.0], [1037.0, 172.0], [1030.0, 187.0], [1106.0, 166.0], [1112.0, 193.0], [1148.0, 180.0], [1114.0, 175.0], [5.0, 2752.0], [212.0, 453.5], [221.0, 185.0], [278.0, 218.0], [301.0, 33.0], [315.0, 1167.0], [366.0, 116.5], [397.0, 66.0], [405.0, 46.0], [421.0, 408.0], [425.0, 198.0], [436.0, 135.0], [460.0, 458.0], [473.0, 169.0], [464.0, 312.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1148.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 258.1, "minX": 1.79069454E12, "maxY": 285.05, "series": [{"data": [[1.7906946E12, 285.05], [1.79069454E12, 258.1]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906946E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 254.76666666666668, "minX": 1.79069454E12, "maxY": 288.3833333333333, "series": [{"data": [[1.7906946E12, 288.3833333333333], [1.79069454E12, 254.76666666666668]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906946E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 254.76666666666668, "minX": 1.79069454E12, "maxY": 288.3833333333333, "series": [{"data": [[1.7906946E12, 288.3833333333333], [1.79069454E12, 254.76666666666668]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906946E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 254.76666666666668, "minX": 1.79069454E12, "maxY": 288.3833333333333, "series": [{"data": [[1.7906946E12, 288.3833333333333], [1.79069454E12, 254.76666666666668]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906946E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

