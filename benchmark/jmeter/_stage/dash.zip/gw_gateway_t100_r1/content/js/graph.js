/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 13.0, "minX": 0.0, "maxY": 699.0, "series": [{"data": [[0.0, 13.0], [0.1, 21.0], [0.2, 26.0], [0.3, 29.0], [0.4, 31.0], [0.5, 33.0], [0.6, 34.0], [0.7, 36.0], [0.8, 37.0], [0.9, 39.0], [1.0, 39.0], [1.1, 40.0], [1.2, 42.0], [1.3, 43.0], [1.4, 44.0], [1.5, 45.0], [1.6, 46.0], [1.7, 47.0], [1.8, 48.0], [1.9, 49.0], [2.0, 49.0], [2.1, 50.0], [2.2, 51.0], [2.3, 52.0], [2.4, 53.0], [2.5, 53.0], [2.6, 54.0], [2.7, 55.0], [2.8, 55.0], [2.9, 56.0], [3.0, 56.0], [3.1, 57.0], [3.2, 57.0], [3.3, 58.0], [3.4, 58.0], [3.5, 59.0], [3.6, 60.0], [3.7, 60.0], [3.8, 61.0], [3.9, 61.0], [4.0, 62.0], [4.1, 62.0], [4.2, 62.0], [4.3, 63.0], [4.4, 63.0], [4.5, 64.0], [4.6, 64.0], [4.7, 65.0], [4.8, 65.0], [4.9, 66.0], [5.0, 66.0], [5.1, 67.0], [5.2, 67.0], [5.3, 67.0], [5.4, 68.0], [5.5, 68.0], [5.6, 68.0], [5.7, 69.0], [5.8, 69.0], [5.9, 69.0], [6.0, 70.0], [6.1, 70.0], [6.2, 71.0], [6.3, 71.0], [6.4, 71.0], [6.5, 71.0], [6.6, 72.0], [6.7, 72.0], [6.8, 72.0], [6.9, 73.0], [7.0, 73.0], [7.1, 73.0], [7.2, 73.0], [7.3, 74.0], [7.4, 74.0], [7.5, 74.0], [7.6, 74.0], [7.7, 75.0], [7.8, 75.0], [7.9, 75.0], [8.0, 76.0], [8.1, 76.0], [8.2, 76.0], [8.3, 77.0], [8.4, 77.0], [8.5, 77.0], [8.6, 77.0], [8.7, 78.0], [8.8, 78.0], [8.9, 78.0], [9.0, 79.0], [9.1, 79.0], [9.2, 79.0], [9.3, 79.0], [9.4, 80.0], [9.5, 80.0], [9.6, 80.0], [9.7, 80.0], [9.8, 81.0], [9.9, 81.0], [10.0, 81.0], [10.1, 81.0], [10.2, 81.0], [10.3, 82.0], [10.4, 82.0], [10.5, 82.0], [10.6, 82.0], [10.7, 83.0], [10.8, 83.0], [10.9, 83.0], [11.0, 83.0], [11.1, 83.0], [11.2, 84.0], [11.3, 84.0], [11.4, 84.0], [11.5, 84.0], [11.6, 85.0], [11.7, 85.0], [11.8, 85.0], [11.9, 85.0], [12.0, 85.0], [12.1, 86.0], [12.2, 86.0], [12.3, 86.0], [12.4, 86.0], [12.5, 87.0], [12.6, 87.0], [12.7, 87.0], [12.8, 87.0], [12.9, 88.0], [13.0, 88.0], [13.1, 88.0], [13.2, 88.0], [13.3, 89.0], [13.4, 89.0], [13.5, 89.0], [13.6, 89.0], [13.7, 89.0], [13.8, 90.0], [13.9, 90.0], [14.0, 90.0], [14.1, 90.0], [14.2, 90.0], [14.3, 91.0], [14.4, 91.0], [14.5, 91.0], [14.6, 91.0], [14.7, 91.0], [14.8, 92.0], [14.9, 92.0], [15.0, 92.0], [15.1, 92.0], [15.2, 92.0], [15.3, 92.0], [15.4, 93.0], [15.5, 93.0], [15.6, 93.0], [15.7, 93.0], [15.8, 93.0], [15.9, 94.0], [16.0, 94.0], [16.1, 94.0], [16.2, 94.0], [16.3, 95.0], [16.4, 95.0], [16.5, 95.0], [16.6, 95.0], [16.7, 95.0], [16.8, 95.0], [16.9, 96.0], [17.0, 96.0], [17.1, 96.0], [17.2, 96.0], [17.3, 96.0], [17.4, 97.0], [17.5, 97.0], [17.6, 97.0], [17.7, 97.0], [17.8, 97.0], [17.9, 97.0], [18.0, 98.0], [18.1, 98.0], [18.2, 98.0], [18.3, 98.0], [18.4, 98.0], [18.5, 99.0], [18.6, 99.0], [18.7, 99.0], [18.8, 99.0], [18.9, 99.0], [19.0, 100.0], [19.1, 100.0], [19.2, 100.0], [19.3, 100.0], [19.4, 100.0], [19.5, 100.0], [19.6, 101.0], [19.7, 101.0], [19.8, 101.0], [19.9, 101.0], [20.0, 101.0], [20.1, 101.0], [20.2, 102.0], [20.3, 102.0], [20.4, 102.0], [20.5, 102.0], [20.6, 102.0], [20.7, 102.0], [20.8, 103.0], [20.9, 103.0], [21.0, 103.0], [21.1, 103.0], [21.2, 103.0], [21.3, 103.0], [21.4, 104.0], [21.5, 104.0], [21.6, 104.0], [21.7, 104.0], [21.8, 104.0], [21.9, 105.0], [22.0, 105.0], [22.1, 105.0], [22.2, 105.0], [22.3, 105.0], [22.4, 105.0], [22.5, 106.0], [22.6, 106.0], [22.7, 106.0], [22.8, 106.0], [22.9, 106.0], [23.0, 107.0], [23.1, 107.0], [23.2, 107.0], [23.3, 107.0], [23.4, 107.0], [23.5, 107.0], [23.6, 108.0], [23.7, 108.0], [23.8, 108.0], [23.9, 108.0], [24.0, 108.0], [24.1, 109.0], [24.2, 109.0], [24.3, 109.0], [24.4, 109.0], [24.5, 109.0], [24.6, 109.0], [24.7, 110.0], [24.8, 110.0], [24.9, 110.0], [25.0, 110.0], [25.1, 110.0], [25.2, 111.0], [25.3, 111.0], [25.4, 111.0], [25.5, 111.0], [25.6, 111.0], [25.7, 112.0], [25.8, 112.0], [25.9, 112.0], [26.0, 112.0], [26.1, 112.0], [26.2, 112.0], [26.3, 112.0], [26.4, 113.0], [26.5, 113.0], [26.6, 113.0], [26.7, 113.0], [26.8, 113.0], [26.9, 113.0], [27.0, 114.0], [27.1, 114.0], [27.2, 114.0], [27.3, 114.0], [27.4, 114.0], [27.5, 114.0], [27.6, 115.0], [27.7, 115.0], [27.8, 115.0], [27.9, 115.0], [28.0, 115.0], [28.1, 115.0], [28.2, 115.0], [28.3, 115.0], [28.4, 116.0], [28.5, 116.0], [28.6, 116.0], [28.7, 116.0], [28.8, 116.0], [28.9, 116.0], [29.0, 117.0], [29.1, 117.0], [29.2, 117.0], [29.3, 117.0], [29.4, 117.0], [29.5, 117.0], [29.6, 118.0], [29.7, 118.0], [29.8, 118.0], [29.9, 118.0], [30.0, 118.0], [30.1, 118.0], [30.2, 118.0], [30.3, 119.0], [30.4, 119.0], [30.5, 119.0], [30.6, 119.0], [30.7, 119.0], [30.8, 120.0], [30.9, 120.0], [31.0, 120.0], [31.1, 120.0], [31.2, 120.0], [31.3, 120.0], [31.4, 121.0], [31.5, 121.0], [31.6, 121.0], [31.7, 121.0], [31.8, 121.0], [31.9, 121.0], [32.0, 122.0], [32.1, 122.0], [32.2, 122.0], [32.3, 122.0], [32.4, 122.0], [32.5, 122.0], [32.6, 123.0], [32.7, 123.0], [32.8, 123.0], [32.9, 123.0], [33.0, 123.0], [33.1, 123.0], [33.2, 124.0], [33.3, 124.0], [33.4, 124.0], [33.5, 124.0], [33.6, 124.0], [33.7, 124.0], [33.8, 124.0], [33.9, 125.0], [34.0, 125.0], [34.1, 125.0], [34.2, 125.0], [34.3, 125.0], [34.4, 125.0], [34.5, 126.0], [34.6, 126.0], [34.7, 126.0], [34.8, 126.0], [34.9, 126.0], [35.0, 126.0], [35.1, 126.0], [35.2, 127.0], [35.3, 127.0], [35.4, 127.0], [35.5, 127.0], [35.6, 127.0], [35.7, 127.0], [35.8, 128.0], [35.9, 128.0], [36.0, 128.0], [36.1, 128.0], [36.2, 128.0], [36.3, 128.0], [36.4, 128.0], [36.5, 129.0], [36.6, 129.0], [36.7, 129.0], [36.8, 129.0], [36.9, 129.0], [37.0, 129.0], [37.1, 129.0], [37.2, 130.0], [37.3, 130.0], [37.4, 130.0], [37.5, 130.0], [37.6, 130.0], [37.7, 130.0], [37.8, 131.0], [37.9, 131.0], [38.0, 131.0], [38.1, 131.0], [38.2, 131.0], [38.3, 131.0], [38.4, 132.0], [38.5, 132.0], [38.6, 132.0], [38.7, 132.0], [38.8, 132.0], [38.9, 132.0], [39.0, 132.0], [39.1, 133.0], [39.2, 133.0], [39.3, 133.0], [39.4, 133.0], [39.5, 133.0], [39.6, 133.0], [39.7, 134.0], [39.8, 134.0], [39.9, 134.0], [40.0, 134.0], [40.1, 134.0], [40.2, 134.0], [40.3, 134.0], [40.4, 135.0], [40.5, 135.0], [40.6, 135.0], [40.7, 135.0], [40.8, 135.0], [40.9, 135.0], [41.0, 135.0], [41.1, 136.0], [41.2, 136.0], [41.3, 136.0], [41.4, 136.0], [41.5, 136.0], [41.6, 137.0], [41.7, 137.0], [41.8, 137.0], [41.9, 137.0], [42.0, 137.0], [42.1, 137.0], [42.2, 138.0], [42.3, 138.0], [42.4, 138.0], [42.5, 138.0], [42.6, 138.0], [42.7, 138.0], [42.8, 139.0], [42.9, 139.0], [43.0, 139.0], [43.1, 139.0], [43.2, 139.0], [43.3, 140.0], [43.4, 140.0], [43.5, 140.0], [43.6, 140.0], [43.7, 140.0], [43.8, 140.0], [43.9, 141.0], [44.0, 141.0], [44.1, 141.0], [44.2, 141.0], [44.3, 141.0], [44.4, 141.0], [44.5, 141.0], [44.6, 141.0], [44.7, 142.0], [44.8, 142.0], [44.9, 142.0], [45.0, 142.0], [45.1, 142.0], [45.2, 142.0], [45.3, 143.0], [45.4, 143.0], [45.5, 143.0], [45.6, 143.0], [45.7, 143.0], [45.8, 143.0], [45.9, 144.0], [46.0, 144.0], [46.1, 144.0], [46.2, 144.0], [46.3, 144.0], [46.4, 144.0], [46.5, 145.0], [46.6, 145.0], [46.7, 145.0], [46.8, 145.0], [46.9, 145.0], [47.0, 145.0], [47.1, 146.0], [47.2, 146.0], [47.3, 146.0], [47.4, 146.0], [47.5, 146.0], [47.6, 146.0], [47.7, 146.0], [47.8, 147.0], [47.9, 147.0], [48.0, 147.0], [48.1, 147.0], [48.2, 147.0], [48.3, 148.0], [48.4, 148.0], [48.5, 148.0], [48.6, 148.0], [48.7, 148.0], [48.8, 149.0], [48.9, 149.0], [49.0, 149.0], [49.1, 149.0], [49.2, 149.0], [49.3, 149.0], [49.4, 150.0], [49.5, 150.0], [49.6, 150.0], [49.7, 150.0], [49.8, 150.0], [49.9, 150.0], [50.0, 150.0], [50.1, 151.0], [50.2, 151.0], [50.3, 151.0], [50.4, 151.0], [50.5, 151.0], [50.6, 151.0], [50.7, 152.0], [50.8, 152.0], [50.9, 152.0], [51.0, 152.0], [51.1, 152.0], [51.2, 153.0], [51.3, 153.0], [51.4, 153.0], [51.5, 153.0], [51.6, 153.0], [51.7, 153.0], [51.8, 153.0], [51.9, 154.0], [52.0, 154.0], [52.1, 154.0], [52.2, 154.0], [52.3, 154.0], [52.4, 155.0], [52.5, 155.0], [52.6, 155.0], [52.7, 155.0], [52.8, 155.0], [52.9, 155.0], [53.0, 156.0], [53.1, 156.0], [53.2, 156.0], [53.3, 156.0], [53.4, 156.0], [53.5, 157.0], [53.6, 157.0], [53.7, 157.0], [53.8, 157.0], [53.9, 157.0], [54.0, 158.0], [54.1, 158.0], [54.2, 158.0], [54.3, 158.0], [54.4, 158.0], [54.5, 158.0], [54.6, 159.0], [54.7, 159.0], [54.8, 159.0], [54.9, 159.0], [55.0, 159.0], [55.1, 160.0], [55.2, 160.0], [55.3, 160.0], [55.4, 160.0], [55.5, 160.0], [55.6, 160.0], [55.7, 161.0], [55.8, 161.0], [55.9, 161.0], [56.0, 161.0], [56.1, 161.0], [56.2, 162.0], [56.3, 162.0], [56.4, 162.0], [56.5, 162.0], [56.6, 163.0], [56.7, 163.0], [56.8, 163.0], [56.9, 163.0], [57.0, 163.0], [57.1, 164.0], [57.2, 164.0], [57.3, 164.0], [57.4, 164.0], [57.5, 164.0], [57.6, 165.0], [57.7, 165.0], [57.8, 165.0], [57.9, 165.0], [58.0, 165.0], [58.1, 166.0], [58.2, 166.0], [58.3, 166.0], [58.4, 166.0], [58.5, 166.0], [58.6, 167.0], [58.7, 167.0], [58.8, 167.0], [58.9, 167.0], [59.0, 167.0], [59.1, 167.0], [59.2, 168.0], [59.3, 168.0], [59.4, 168.0], [59.5, 168.0], [59.6, 169.0], [59.7, 169.0], [59.8, 169.0], [59.9, 169.0], [60.0, 169.0], [60.1, 170.0], [60.2, 170.0], [60.3, 170.0], [60.4, 170.0], [60.5, 170.0], [60.6, 171.0], [60.7, 171.0], [60.8, 171.0], [60.9, 171.0], [61.0, 171.0], [61.1, 172.0], [61.2, 172.0], [61.3, 172.0], [61.4, 172.0], [61.5, 172.0], [61.6, 173.0], [61.7, 173.0], [61.8, 173.0], [61.9, 173.0], [62.0, 173.0], [62.1, 174.0], [62.2, 174.0], [62.3, 174.0], [62.4, 175.0], [62.5, 175.0], [62.6, 175.0], [62.7, 175.0], [62.8, 175.0], [62.9, 176.0], [63.0, 176.0], [63.1, 176.0], [63.2, 176.0], [63.3, 176.0], [63.4, 177.0], [63.5, 177.0], [63.6, 177.0], [63.7, 177.0], [63.8, 178.0], [63.9, 178.0], [64.0, 178.0], [64.1, 178.0], [64.2, 178.0], [64.3, 179.0], [64.4, 179.0], [64.5, 179.0], [64.6, 179.0], [64.7, 180.0], [64.8, 180.0], [64.9, 180.0], [65.0, 180.0], [65.1, 180.0], [65.2, 181.0], [65.3, 181.0], [65.4, 181.0], [65.5, 181.0], [65.6, 181.0], [65.7, 182.0], [65.8, 182.0], [65.9, 182.0], [66.0, 183.0], [66.1, 183.0], [66.2, 183.0], [66.3, 183.0], [66.4, 183.0], [66.5, 184.0], [66.6, 184.0], [66.7, 184.0], [66.8, 184.0], [66.9, 185.0], [67.0, 185.0], [67.1, 185.0], [67.2, 185.0], [67.3, 185.0], [67.4, 186.0], [67.5, 186.0], [67.6, 186.0], [67.7, 186.0], [67.8, 187.0], [67.9, 187.0], [68.0, 187.0], [68.1, 187.0], [68.2, 188.0], [68.3, 188.0], [68.4, 188.0], [68.5, 189.0], [68.6, 189.0], [68.7, 189.0], [68.8, 189.0], [68.9, 190.0], [69.0, 190.0], [69.1, 190.0], [69.2, 190.0], [69.3, 191.0], [69.4, 191.0], [69.5, 191.0], [69.6, 191.0], [69.7, 192.0], [69.8, 192.0], [69.9, 192.0], [70.0, 193.0], [70.1, 193.0], [70.2, 193.0], [70.3, 194.0], [70.4, 194.0], [70.5, 194.0], [70.6, 195.0], [70.7, 195.0], [70.8, 195.0], [70.9, 195.0], [71.0, 196.0], [71.1, 196.0], [71.2, 196.0], [71.3, 196.0], [71.4, 197.0], [71.5, 197.0], [71.6, 197.0], [71.7, 198.0], [71.8, 198.0], [71.9, 198.0], [72.0, 198.0], [72.1, 198.0], [72.2, 199.0], [72.3, 199.0], [72.4, 199.0], [72.5, 199.0], [72.6, 200.0], [72.7, 200.0], [72.8, 200.0], [72.9, 200.0], [73.0, 201.0], [73.1, 201.0], [73.2, 201.0], [73.3, 201.0], [73.4, 202.0], [73.5, 202.0], [73.6, 202.0], [73.7, 203.0], [73.8, 203.0], [73.9, 203.0], [74.0, 203.0], [74.1, 204.0], [74.2, 204.0], [74.3, 204.0], [74.4, 204.0], [74.5, 205.0], [74.6, 205.0], [74.7, 205.0], [74.8, 206.0], [74.9, 206.0], [75.0, 206.0], [75.1, 207.0], [75.2, 207.0], [75.3, 207.0], [75.4, 207.0], [75.5, 208.0], [75.6, 208.0], [75.7, 208.0], [75.8, 209.0], [75.9, 209.0], [76.0, 209.0], [76.1, 209.0], [76.2, 210.0], [76.3, 210.0], [76.4, 210.0], [76.5, 211.0], [76.6, 211.0], [76.7, 211.0], [76.8, 212.0], [76.9, 212.0], [77.0, 212.0], [77.1, 213.0], [77.2, 213.0], [77.3, 213.0], [77.4, 214.0], [77.5, 214.0], [77.6, 214.0], [77.7, 214.0], [77.8, 215.0], [77.9, 215.0], [78.0, 215.0], [78.1, 215.0], [78.2, 216.0], [78.3, 216.0], [78.4, 216.0], [78.5, 217.0], [78.6, 217.0], [78.7, 217.0], [78.8, 218.0], [78.9, 218.0], [79.0, 218.0], [79.1, 219.0], [79.2, 219.0], [79.3, 219.0], [79.4, 220.0], [79.5, 220.0], [79.6, 220.0], [79.7, 221.0], [79.8, 221.0], [79.9, 221.0], [80.0, 222.0], [80.1, 222.0], [80.2, 222.0], [80.3, 222.0], [80.4, 223.0], [80.5, 223.0], [80.6, 223.0], [80.7, 224.0], [80.8, 224.0], [80.9, 224.0], [81.0, 225.0], [81.1, 225.0], [81.2, 226.0], [81.3, 226.0], [81.4, 227.0], [81.5, 227.0], [81.6, 227.0], [81.7, 228.0], [81.8, 228.0], [81.9, 229.0], [82.0, 229.0], [82.1, 229.0], [82.2, 230.0], [82.3, 230.0], [82.4, 230.0], [82.5, 231.0], [82.6, 231.0], [82.7, 231.0], [82.8, 232.0], [82.9, 232.0], [83.0, 232.0], [83.1, 233.0], [83.2, 233.0], [83.3, 234.0], [83.4, 234.0], [83.5, 234.0], [83.6, 235.0], [83.7, 235.0], [83.8, 236.0], [83.9, 236.0], [84.0, 236.0], [84.1, 237.0], [84.2, 237.0], [84.3, 238.0], [84.4, 238.0], [84.5, 239.0], [84.6, 239.0], [84.7, 240.0], [84.8, 240.0], [84.9, 241.0], [85.0, 241.0], [85.1, 242.0], [85.2, 242.0], [85.3, 243.0], [85.4, 243.0], [85.5, 244.0], [85.6, 244.0], [85.7, 245.0], [85.8, 245.0], [85.9, 246.0], [86.0, 246.0], [86.1, 246.0], [86.2, 247.0], [86.3, 247.0], [86.4, 248.0], [86.5, 248.0], [86.6, 249.0], [86.7, 249.0], [86.8, 249.0], [86.9, 250.0], [87.0, 250.0], [87.1, 251.0], [87.2, 251.0], [87.3, 252.0], [87.4, 252.0], [87.5, 253.0], [87.6, 254.0], [87.7, 254.0], [87.8, 255.0], [87.9, 255.0], [88.0, 256.0], [88.1, 256.0], [88.2, 257.0], [88.3, 257.0], [88.4, 257.0], [88.5, 258.0], [88.6, 258.0], [88.7, 259.0], [88.8, 260.0], [88.9, 260.0], [89.0, 261.0], [89.1, 261.0], [89.2, 262.0], [89.3, 263.0], [89.4, 263.0], [89.5, 264.0], [89.6, 264.0], [89.7, 265.0], [89.8, 266.0], [89.9, 266.0], [90.0, 267.0], [90.1, 268.0], [90.2, 269.0], [90.3, 270.0], [90.4, 270.0], [90.5, 271.0], [90.6, 272.0], [90.7, 272.0], [90.8, 273.0], [90.9, 274.0], [91.0, 274.0], [91.1, 275.0], [91.2, 275.0], [91.3, 276.0], [91.4, 277.0], [91.5, 278.0], [91.6, 279.0], [91.7, 280.0], [91.8, 281.0], [91.9, 281.0], [92.0, 282.0], [92.1, 283.0], [92.2, 284.0], [92.3, 285.0], [92.4, 285.0], [92.5, 286.0], [92.6, 287.0], [92.7, 288.0], [92.8, 290.0], [92.9, 290.0], [93.0, 291.0], [93.1, 292.0], [93.2, 292.0], [93.3, 293.0], [93.4, 294.0], [93.5, 295.0], [93.6, 296.0], [93.7, 297.0], [93.8, 298.0], [93.9, 299.0], [94.0, 300.0], [94.1, 301.0], [94.2, 302.0], [94.3, 303.0], [94.4, 305.0], [94.5, 306.0], [94.6, 307.0], [94.7, 308.0], [94.8, 309.0], [94.9, 311.0], [95.0, 312.0], [95.1, 313.0], [95.2, 315.0], [95.3, 317.0], [95.4, 318.0], [95.5, 319.0], [95.6, 321.0], [95.7, 322.0], [95.8, 324.0], [95.9, 326.0], [96.0, 327.0], [96.1, 329.0], [96.2, 330.0], [96.3, 333.0], [96.4, 334.0], [96.5, 337.0], [96.6, 339.0], [96.7, 341.0], [96.8, 343.0], [96.9, 345.0], [97.0, 347.0], [97.1, 349.0], [97.2, 352.0], [97.3, 354.0], [97.4, 356.0], [97.5, 358.0], [97.6, 360.0], [97.7, 364.0], [97.8, 365.0], [97.9, 368.0], [98.0, 371.0], [98.1, 376.0], [98.2, 380.0], [98.3, 385.0], [98.4, 389.0], [98.5, 393.0], [98.6, 398.0], [98.7, 403.0], [98.8, 407.0], [98.9, 410.0], [99.0, 415.0], [99.1, 421.0], [99.2, 425.0], [99.3, 433.0], [99.4, 440.0], [99.5, 450.0], [99.6, 457.0], [99.7, 472.0], [99.8, 490.0], [99.9, 511.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 0.0, "maxY": 11340.0, "series": [{"data": [[0.0, 4024.0], [300.0, 984.0], [600.0, 2.0], [100.0, 11340.0], [200.0, 4544.0], [400.0, 262.0], [500.0, 30.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 600.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 31.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 21155.0, "series": [{"data": [[0.0, 21155.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 31.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 89.8549234297551, "minX": 1.7906949E12, "maxY": 99.3829704003129, "series": [{"data": [[1.7906949E12, 89.8549234297551], [1.79069496E12, 99.3829704003129]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069496E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 32.89473684210526, "minX": 4.0, "maxY": 298.1, "series": [{"data": [[4.0, 131.5], [5.0, 65.25], [6.0, 32.89473684210526], [7.0, 36.15384615384615], [8.0, 40.8125], [9.0, 50.86666666666666], [10.0, 46.04166666666665], [11.0, 40.92857142857142], [12.0, 36.34615384615385], [13.0, 58.2], [14.0, 46.645161290322584], [15.0, 45.79310344827586], [16.0, 60.72413793103447], [17.0, 70.50000000000001], [18.0, 63.363636363636374], [19.0, 57.848484848484844], [20.0, 73.91304347826087], [21.0, 86.41935483870967], [22.0, 71.93333333333337], [23.0, 89.78260869565219], [24.0, 65.73333333333332], [25.0, 85.66666666666666], [26.0, 89.3913043478261], [27.0, 96.97222222222221], [28.0, 85.83333333333334], [29.0, 99.03448275862065], [30.0, 136.37037037037038], [31.0, 119.77272727272727], [32.0, 123.27272727272725], [33.0, 118.56666666666665], [34.0, 118.08571428571429], [35.0, 102.3125], [36.0, 103.38095238095238], [37.0, 93.5625], [38.0, 119.77272727272728], [39.0, 102.51851851851853], [40.0, 112.9318181818182], [41.0, 99.57894736842104], [42.0, 161.4186046511628], [43.0, 94.72727272727275], [44.0, 113.14285714285711], [45.0, 145.4375], [46.0, 161.40740740740742], [47.0, 109.84999999999998], [48.0, 129.82978723404253], [49.0, 111.59375], [50.0, 154.31372549019605], [51.0, 126.71428571428571], [52.0, 171.96296296296293], [53.0, 194.0], [54.0, 191.46511627906978], [55.0, 168.75000000000003], [56.0, 173.52941176470586], [57.0, 176.08333333333334], [58.0, 191.42857142857144], [59.0, 187.20000000000002], [60.0, 139.11940298507466], [61.0, 105.32727272727274], [62.0, 132.8028169014085], [63.0, 125.79166666666669], [64.0, 154.58333333333334], [65.0, 202.45454545454544], [66.0, 175.02777777777783], [67.0, 164.78571428571428], [68.0, 220.14516129032253], [69.0, 139.13043478260866], [70.0, 184.1935483870968], [71.0, 193.63265306122446], [72.0, 147.25], [73.0, 140.0238095238095], [74.0, 203.7391304347826], [75.0, 298.1], [76.0, 277.7037037037037], [77.0, 194.10000000000002], [78.0, 202.70833333333334], [79.0, 261.92857142857133], [80.0, 204.2950819672131], [81.0, 163.60759493670895], [82.0, 146.30769230769232], [83.0, 166.33802816901408], [84.0, 167.00000000000006], [85.0, 160.92682926829266], [86.0, 192.71153846153848], [87.0, 186.51562500000006], [88.0, 162.40624999999994], [89.0, 165.6176470588235], [90.0, 184.530612244898], [91.0, 184.36538461538464], [92.0, 188.32258064516128], [93.0, 236.24137931034485], [94.0, 223.7068965517241], [95.0, 199.00000000000006], [96.0, 166.55769230769232], [97.0, 185.54347826086953], [98.0, 192.64285714285717], [99.0, 238.91666666666666], [100.0, 168.60145903479247]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[93.30392712168442, 165.15052393089758]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 59818.2, "minX": 1.7906949E12, "maxY": 123794.35, "series": [{"data": [[1.7906949E12, 123794.35], [1.79069496E12, 70237.55]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.7906949E12, 105432.6], [1.79069496E12, 59818.2]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069496E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 146.4733342026341, "minX": 1.7906949E12, "maxY": 175.74720722053692, "series": [{"data": [[1.7906949E12, 175.74720722053692], [1.79069496E12, 146.4733342026341]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069496E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 145.0739340200805, "minX": 1.7906949E12, "maxY": 173.80276688614407, "series": [{"data": [[1.7906949E12, 173.80276688614407], [1.79069496E12, 145.0739340200805]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069496E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.7906949E12, "maxY": 0.04549826144854624, "series": [{"data": [[1.7906949E12, 0.04549826144854624], [1.79069496E12, 0.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069496E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 13.0, "minX": 1.7906949E12, "maxY": 699.0, "series": [{"data": [[1.7906949E12, 699.0], [1.79069496E12, 621.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.7906949E12, 283.0], [1.79069496E12, 236.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.7906949E12, 427.8199999999997], [1.79069496E12, 366.3000000000002]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.7906949E12, 330.0], [1.79069496E12, 273.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.7906949E12, 13.0], [1.79069496E12, 18.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.7906949E12, 162.0], [1.79069496E12, 132.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069496E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 34.0, "minX": 75.0, "maxY": 257.0, "series": [{"data": [[516.0, 196.0], [569.0, 169.0], [572.0, 156.0], [548.0, 158.0], [564.0, 181.5], [600.0, 160.0], [604.0, 163.0], [591.0, 149.0], [613.0, 149.0], [625.0, 152.0], [637.0, 134.0], [635.0, 141.0], [626.0, 148.0], [644.0, 133.0], [655.0, 125.0], [705.0, 141.0], [764.0, 121.0], [784.0, 120.5], [781.0, 123.0], [783.0, 118.0], [782.0, 110.0], [75.0, 34.0], [135.0, 143.0], [270.0, 47.0], [287.0, 81.0], [302.0, 105.5], [295.0, 162.0], [333.0, 118.0], [335.0, 196.0], [387.0, 257.0], [412.0, 138.0], [413.0, 232.0], [420.0, 203.5], [446.0, 198.5], [436.0, 216.5], [475.0, 196.0], [495.0, 180.0], [485.0, 201.5], [498.0, 160.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 784.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 34.0, "minX": 75.0, "maxY": 257.0, "series": [{"data": [[516.0, 195.0], [569.0, 167.0], [572.0, 155.0], [548.0, 157.0], [564.0, 181.0], [600.0, 157.5], [604.0, 161.0], [591.0, 148.0], [613.0, 147.0], [625.0, 150.0], [637.0, 133.0], [635.0, 139.0], [626.0, 146.5], [644.0, 132.0], [655.0, 124.0], [705.0, 139.0], [764.0, 119.0], [784.0, 120.0], [781.0, 122.0], [783.0, 117.0], [782.0, 109.0], [75.0, 34.0], [135.0, 143.0], [270.0, 46.0], [287.0, 78.0], [302.0, 104.0], [295.0, 162.0], [333.0, 116.0], [335.0, 193.0], [387.0, 257.0], [412.0, 136.5], [413.0, 231.0], [420.0, 199.0], [446.0, 195.0], [436.0, 214.0], [475.0, 192.0], [495.0, 179.0], [485.0, 200.0], [498.0, 157.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 784.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 126.15, "minX": 1.7906949E12, "maxY": 226.95, "series": [{"data": [[1.7906949E12, 226.95], [1.79069496E12, 126.15]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069496E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 127.81666666666666, "minX": 1.7906949E12, "maxY": 225.28333333333333, "series": [{"data": [[1.7906949E12, 225.28333333333333], [1.79069496E12, 127.81666666666666]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069496E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 127.81666666666666, "minX": 1.7906949E12, "maxY": 225.28333333333333, "series": [{"data": [[1.7906949E12, 225.28333333333333], [1.79069496E12, 127.81666666666666]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069496E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 127.81666666666666, "minX": 1.7906949E12, "maxY": 225.28333333333333, "series": [{"data": [[1.7906949E12, 225.28333333333333], [1.79069496E12, 127.81666666666666]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069496E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

