/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 12.0, "minX": 0.0, "maxY": 939.0, "series": [{"data": [[0.0, 12.0], [0.1, 16.0], [0.2, 18.0], [0.3, 20.0], [0.4, 21.0], [0.5, 22.0], [0.6, 23.0], [0.7, 24.0], [0.8, 25.0], [0.9, 26.0], [1.0, 27.0], [1.1, 28.0], [1.2, 28.0], [1.3, 29.0], [1.4, 30.0], [1.5, 31.0], [1.6, 32.0], [1.7, 32.0], [1.8, 33.0], [1.9, 33.0], [2.0, 34.0], [2.1, 34.0], [2.2, 35.0], [2.3, 35.0], [2.4, 36.0], [2.5, 37.0], [2.6, 37.0], [2.7, 38.0], [2.8, 38.0], [2.9, 39.0], [3.0, 39.0], [3.1, 39.0], [3.2, 40.0], [3.3, 40.0], [3.4, 41.0], [3.5, 41.0], [3.6, 41.0], [3.7, 42.0], [3.8, 42.0], [3.9, 43.0], [4.0, 43.0], [4.1, 44.0], [4.2, 44.0], [4.3, 44.0], [4.4, 45.0], [4.5, 45.0], [4.6, 45.0], [4.7, 46.0], [4.8, 46.0], [4.9, 47.0], [5.0, 47.0], [5.1, 47.0], [5.2, 48.0], [5.3, 48.0], [5.4, 48.0], [5.5, 49.0], [5.6, 49.0], [5.7, 49.0], [5.8, 49.0], [5.9, 50.0], [6.0, 50.0], [6.1, 50.0], [6.2, 51.0], [6.3, 51.0], [6.4, 51.0], [6.5, 52.0], [6.6, 52.0], [6.7, 52.0], [6.8, 53.0], [6.9, 53.0], [7.0, 53.0], [7.1, 53.0], [7.2, 54.0], [7.3, 54.0], [7.4, 54.0], [7.5, 55.0], [7.6, 55.0], [7.7, 55.0], [7.8, 55.0], [7.9, 56.0], [8.0, 56.0], [8.1, 56.0], [8.2, 56.0], [8.3, 57.0], [8.4, 57.0], [8.5, 57.0], [8.6, 58.0], [8.7, 58.0], [8.8, 58.0], [8.9, 58.0], [9.0, 59.0], [9.1, 59.0], [9.2, 59.0], [9.3, 60.0], [9.4, 60.0], [9.5, 60.0], [9.6, 60.0], [9.7, 61.0], [9.8, 61.0], [9.9, 61.0], [10.0, 61.0], [10.1, 62.0], [10.2, 62.0], [10.3, 62.0], [10.4, 63.0], [10.5, 63.0], [10.6, 63.0], [10.7, 63.0], [10.8, 63.0], [10.9, 64.0], [11.0, 64.0], [11.1, 64.0], [11.2, 64.0], [11.3, 65.0], [11.4, 65.0], [11.5, 65.0], [11.6, 65.0], [11.7, 66.0], [11.8, 66.0], [11.9, 66.0], [12.0, 66.0], [12.1, 67.0], [12.2, 67.0], [12.3, 67.0], [12.4, 67.0], [12.5, 68.0], [12.6, 68.0], [12.7, 68.0], [12.8, 69.0], [12.9, 69.0], [13.0, 69.0], [13.1, 69.0], [13.2, 69.0], [13.3, 70.0], [13.4, 70.0], [13.5, 70.0], [13.6, 71.0], [13.7, 71.0], [13.8, 71.0], [13.9, 72.0], [14.0, 72.0], [14.1, 72.0], [14.2, 72.0], [14.3, 72.0], [14.4, 73.0], [14.5, 73.0], [14.6, 73.0], [14.7, 73.0], [14.8, 73.0], [14.9, 74.0], [15.0, 74.0], [15.1, 74.0], [15.2, 74.0], [15.3, 74.0], [15.4, 75.0], [15.5, 75.0], [15.6, 75.0], [15.7, 75.0], [15.8, 75.0], [15.9, 75.0], [16.0, 76.0], [16.1, 76.0], [16.2, 76.0], [16.3, 76.0], [16.4, 77.0], [16.5, 77.0], [16.6, 77.0], [16.7, 77.0], [16.8, 77.0], [16.9, 78.0], [17.0, 78.0], [17.1, 78.0], [17.2, 78.0], [17.3, 78.0], [17.4, 79.0], [17.5, 79.0], [17.6, 79.0], [17.7, 79.0], [17.8, 79.0], [17.9, 80.0], [18.0, 80.0], [18.1, 80.0], [18.2, 80.0], [18.3, 81.0], [18.4, 81.0], [18.5, 81.0], [18.6, 81.0], [18.7, 81.0], [18.8, 82.0], [18.9, 82.0], [19.0, 82.0], [19.1, 82.0], [19.2, 82.0], [19.3, 83.0], [19.4, 83.0], [19.5, 83.0], [19.6, 83.0], [19.7, 83.0], [19.8, 84.0], [19.9, 84.0], [20.0, 84.0], [20.1, 84.0], [20.2, 84.0], [20.3, 85.0], [20.4, 85.0], [20.5, 85.0], [20.6, 85.0], [20.7, 85.0], [20.8, 85.0], [20.9, 86.0], [21.0, 86.0], [21.1, 86.0], [21.2, 86.0], [21.3, 86.0], [21.4, 87.0], [21.5, 87.0], [21.6, 87.0], [21.7, 87.0], [21.8, 88.0], [21.9, 88.0], [22.0, 88.0], [22.1, 88.0], [22.2, 88.0], [22.3, 88.0], [22.4, 89.0], [22.5, 89.0], [22.6, 89.0], [22.7, 89.0], [22.8, 89.0], [22.9, 90.0], [23.0, 90.0], [23.1, 90.0], [23.2, 90.0], [23.3, 90.0], [23.4, 90.0], [23.5, 91.0], [23.6, 91.0], [23.7, 91.0], [23.8, 91.0], [23.9, 91.0], [24.0, 92.0], [24.1, 92.0], [24.2, 92.0], [24.3, 92.0], [24.4, 92.0], [24.5, 92.0], [24.6, 93.0], [24.7, 93.0], [24.8, 93.0], [24.9, 93.0], [25.0, 93.0], [25.1, 93.0], [25.2, 94.0], [25.3, 94.0], [25.4, 94.0], [25.5, 94.0], [25.6, 94.0], [25.7, 95.0], [25.8, 95.0], [25.9, 95.0], [26.0, 95.0], [26.1, 95.0], [26.2, 95.0], [26.3, 96.0], [26.4, 96.0], [26.5, 96.0], [26.6, 96.0], [26.7, 96.0], [26.8, 96.0], [26.9, 97.0], [27.0, 97.0], [27.1, 97.0], [27.2, 97.0], [27.3, 97.0], [27.4, 98.0], [27.5, 98.0], [27.6, 98.0], [27.7, 98.0], [27.8, 98.0], [27.9, 98.0], [28.0, 99.0], [28.1, 99.0], [28.2, 99.0], [28.3, 99.0], [28.4, 99.0], [28.5, 99.0], [28.6, 100.0], [28.7, 100.0], [28.8, 100.0], [28.9, 100.0], [29.0, 100.0], [29.1, 101.0], [29.2, 101.0], [29.3, 101.0], [29.4, 101.0], [29.5, 101.0], [29.6, 101.0], [29.7, 101.0], [29.8, 102.0], [29.9, 102.0], [30.0, 102.0], [30.1, 102.0], [30.2, 102.0], [30.3, 102.0], [30.4, 102.0], [30.5, 103.0], [30.6, 103.0], [30.7, 103.0], [30.8, 103.0], [30.9, 103.0], [31.0, 103.0], [31.1, 104.0], [31.2, 104.0], [31.3, 104.0], [31.4, 104.0], [31.5, 104.0], [31.6, 104.0], [31.7, 104.0], [31.8, 105.0], [31.9, 105.0], [32.0, 105.0], [32.1, 105.0], [32.2, 105.0], [32.3, 105.0], [32.4, 105.0], [32.5, 106.0], [32.6, 106.0], [32.7, 106.0], [32.8, 106.0], [32.9, 106.0], [33.0, 107.0], [33.1, 107.0], [33.2, 107.0], [33.3, 107.0], [33.4, 107.0], [33.5, 107.0], [33.6, 108.0], [33.7, 108.0], [33.8, 108.0], [33.9, 108.0], [34.0, 108.0], [34.1, 109.0], [34.2, 109.0], [34.3, 109.0], [34.4, 109.0], [34.5, 109.0], [34.6, 110.0], [34.7, 110.0], [34.8, 110.0], [34.9, 110.0], [35.0, 110.0], [35.1, 110.0], [35.2, 111.0], [35.3, 111.0], [35.4, 111.0], [35.5, 111.0], [35.6, 111.0], [35.7, 111.0], [35.8, 112.0], [35.9, 112.0], [36.0, 112.0], [36.1, 112.0], [36.2, 112.0], [36.3, 112.0], [36.4, 113.0], [36.5, 113.0], [36.6, 113.0], [36.7, 113.0], [36.8, 113.0], [36.9, 114.0], [37.0, 114.0], [37.1, 114.0], [37.2, 114.0], [37.3, 114.0], [37.4, 114.0], [37.5, 115.0], [37.6, 115.0], [37.7, 115.0], [37.8, 115.0], [37.9, 115.0], [38.0, 116.0], [38.1, 116.0], [38.2, 116.0], [38.3, 116.0], [38.4, 116.0], [38.5, 116.0], [38.6, 116.0], [38.7, 117.0], [38.8, 117.0], [38.9, 117.0], [39.0, 117.0], [39.1, 117.0], [39.2, 118.0], [39.3, 118.0], [39.4, 118.0], [39.5, 118.0], [39.6, 118.0], [39.7, 118.0], [39.8, 118.0], [39.9, 119.0], [40.0, 119.0], [40.1, 119.0], [40.2, 119.0], [40.3, 119.0], [40.4, 120.0], [40.5, 120.0], [40.6, 120.0], [40.7, 120.0], [40.8, 120.0], [40.9, 120.0], [41.0, 121.0], [41.1, 121.0], [41.2, 121.0], [41.3, 121.0], [41.4, 121.0], [41.5, 122.0], [41.6, 122.0], [41.7, 122.0], [41.8, 122.0], [41.9, 122.0], [42.0, 122.0], [42.1, 123.0], [42.2, 123.0], [42.3, 123.0], [42.4, 123.0], [42.5, 123.0], [42.6, 124.0], [42.7, 124.0], [42.8, 124.0], [42.9, 124.0], [43.0, 124.0], [43.1, 125.0], [43.2, 125.0], [43.3, 125.0], [43.4, 125.0], [43.5, 125.0], [43.6, 125.0], [43.7, 126.0], [43.8, 126.0], [43.9, 126.0], [44.0, 126.0], [44.1, 126.0], [44.2, 126.0], [44.3, 127.0], [44.4, 127.0], [44.5, 127.0], [44.6, 127.0], [44.7, 127.0], [44.8, 128.0], [44.9, 128.0], [45.0, 128.0], [45.1, 128.0], [45.2, 128.0], [45.3, 128.0], [45.4, 129.0], [45.5, 129.0], [45.6, 129.0], [45.7, 129.0], [45.8, 129.0], [45.9, 130.0], [46.0, 130.0], [46.1, 130.0], [46.2, 130.0], [46.3, 130.0], [46.4, 131.0], [46.5, 131.0], [46.6, 131.0], [46.7, 131.0], [46.8, 132.0], [46.9, 132.0], [47.0, 132.0], [47.1, 132.0], [47.2, 132.0], [47.3, 132.0], [47.4, 133.0], [47.5, 133.0], [47.6, 133.0], [47.7, 133.0], [47.8, 133.0], [47.9, 133.0], [48.0, 134.0], [48.1, 134.0], [48.2, 134.0], [48.3, 134.0], [48.4, 135.0], [48.5, 135.0], [48.6, 135.0], [48.7, 135.0], [48.8, 135.0], [48.9, 136.0], [49.0, 136.0], [49.1, 136.0], [49.2, 136.0], [49.3, 136.0], [49.4, 136.0], [49.5, 137.0], [49.6, 137.0], [49.7, 137.0], [49.8, 137.0], [49.9, 138.0], [50.0, 138.0], [50.1, 138.0], [50.2, 138.0], [50.3, 138.0], [50.4, 138.0], [50.5, 139.0], [50.6, 139.0], [50.7, 139.0], [50.8, 139.0], [50.9, 139.0], [51.0, 139.0], [51.1, 140.0], [51.2, 140.0], [51.3, 140.0], [51.4, 140.0], [51.5, 140.0], [51.6, 141.0], [51.7, 141.0], [51.8, 141.0], [51.9, 141.0], [52.0, 142.0], [52.1, 142.0], [52.2, 142.0], [52.3, 142.0], [52.4, 143.0], [52.5, 143.0], [52.6, 143.0], [52.7, 143.0], [52.8, 143.0], [52.9, 143.0], [53.0, 144.0], [53.1, 144.0], [53.2, 144.0], [53.3, 144.0], [53.4, 145.0], [53.5, 145.0], [53.6, 145.0], [53.7, 145.0], [53.8, 145.0], [53.9, 146.0], [54.0, 146.0], [54.1, 146.0], [54.2, 146.0], [54.3, 146.0], [54.4, 147.0], [54.5, 147.0], [54.6, 147.0], [54.7, 147.0], [54.8, 148.0], [54.9, 148.0], [55.0, 148.0], [55.1, 148.0], [55.2, 148.0], [55.3, 149.0], [55.4, 149.0], [55.5, 149.0], [55.6, 149.0], [55.7, 149.0], [55.8, 150.0], [55.9, 150.0], [56.0, 150.0], [56.1, 150.0], [56.2, 150.0], [56.3, 151.0], [56.4, 151.0], [56.5, 151.0], [56.6, 151.0], [56.7, 152.0], [56.8, 152.0], [56.9, 152.0], [57.0, 152.0], [57.1, 153.0], [57.2, 153.0], [57.3, 153.0], [57.4, 153.0], [57.5, 153.0], [57.6, 154.0], [57.7, 154.0], [57.8, 154.0], [57.9, 154.0], [58.0, 154.0], [58.1, 155.0], [58.2, 155.0], [58.3, 155.0], [58.4, 155.0], [58.5, 156.0], [58.6, 156.0], [58.7, 156.0], [58.8, 156.0], [58.9, 156.0], [59.0, 157.0], [59.1, 157.0], [59.2, 157.0], [59.3, 157.0], [59.4, 158.0], [59.5, 158.0], [59.6, 158.0], [59.7, 158.0], [59.8, 158.0], [59.9, 159.0], [60.0, 159.0], [60.1, 159.0], [60.2, 159.0], [60.3, 159.0], [60.4, 160.0], [60.5, 160.0], [60.6, 160.0], [60.7, 160.0], [60.8, 160.0], [60.9, 161.0], [61.0, 161.0], [61.1, 161.0], [61.2, 161.0], [61.3, 162.0], [61.4, 162.0], [61.5, 162.0], [61.6, 162.0], [61.7, 163.0], [61.8, 163.0], [61.9, 163.0], [62.0, 163.0], [62.1, 164.0], [62.2, 164.0], [62.3, 164.0], [62.4, 164.0], [62.5, 164.0], [62.6, 165.0], [62.7, 165.0], [62.8, 165.0], [62.9, 166.0], [63.0, 166.0], [63.1, 166.0], [63.2, 166.0], [63.3, 167.0], [63.4, 167.0], [63.5, 167.0], [63.6, 167.0], [63.7, 168.0], [63.8, 168.0], [63.9, 168.0], [64.0, 168.0], [64.1, 168.0], [64.2, 169.0], [64.3, 169.0], [64.4, 169.0], [64.5, 169.0], [64.6, 170.0], [64.7, 170.0], [64.8, 170.0], [64.9, 171.0], [65.0, 171.0], [65.1, 171.0], [65.2, 171.0], [65.3, 172.0], [65.4, 172.0], [65.5, 172.0], [65.6, 173.0], [65.7, 173.0], [65.8, 173.0], [65.9, 173.0], [66.0, 174.0], [66.1, 174.0], [66.2, 174.0], [66.3, 174.0], [66.4, 175.0], [66.5, 175.0], [66.6, 175.0], [66.7, 176.0], [66.8, 176.0], [66.9, 176.0], [67.0, 177.0], [67.1, 177.0], [67.2, 177.0], [67.3, 177.0], [67.4, 178.0], [67.5, 178.0], [67.6, 178.0], [67.7, 178.0], [67.8, 179.0], [67.9, 179.0], [68.0, 179.0], [68.1, 179.0], [68.2, 180.0], [68.3, 180.0], [68.4, 180.0], [68.5, 181.0], [68.6, 181.0], [68.7, 181.0], [68.8, 182.0], [68.9, 182.0], [69.0, 182.0], [69.1, 182.0], [69.2, 183.0], [69.3, 183.0], [69.4, 183.0], [69.5, 184.0], [69.6, 184.0], [69.7, 184.0], [69.8, 185.0], [69.9, 185.0], [70.0, 185.0], [70.1, 186.0], [70.2, 186.0], [70.3, 186.0], [70.4, 186.0], [70.5, 187.0], [70.6, 187.0], [70.7, 187.0], [70.8, 188.0], [70.9, 188.0], [71.0, 188.0], [71.1, 189.0], [71.2, 189.0], [71.3, 189.0], [71.4, 190.0], [71.5, 190.0], [71.6, 190.0], [71.7, 191.0], [71.8, 191.0], [71.9, 191.0], [72.0, 192.0], [72.1, 192.0], [72.2, 192.0], [72.3, 193.0], [72.4, 193.0], [72.5, 193.0], [72.6, 194.0], [72.7, 194.0], [72.8, 194.0], [72.9, 195.0], [73.0, 195.0], [73.1, 195.0], [73.2, 196.0], [73.3, 196.0], [73.4, 197.0], [73.5, 197.0], [73.6, 197.0], [73.7, 198.0], [73.8, 198.0], [73.9, 198.0], [74.0, 199.0], [74.1, 199.0], [74.2, 199.0], [74.3, 200.0], [74.4, 200.0], [74.5, 200.0], [74.6, 201.0], [74.7, 201.0], [74.8, 201.0], [74.9, 202.0], [75.0, 202.0], [75.1, 202.0], [75.2, 202.0], [75.3, 203.0], [75.4, 203.0], [75.5, 203.0], [75.6, 204.0], [75.7, 204.0], [75.8, 205.0], [75.9, 205.0], [76.0, 205.0], [76.1, 206.0], [76.2, 206.0], [76.3, 207.0], [76.4, 207.0], [76.5, 208.0], [76.6, 208.0], [76.7, 208.0], [76.8, 209.0], [76.9, 209.0], [77.0, 210.0], [77.1, 210.0], [77.2, 210.0], [77.3, 211.0], [77.4, 211.0], [77.5, 212.0], [77.6, 212.0], [77.7, 213.0], [77.8, 213.0], [77.9, 214.0], [78.0, 214.0], [78.1, 214.0], [78.2, 215.0], [78.3, 215.0], [78.4, 216.0], [78.5, 216.0], [78.6, 217.0], [78.7, 217.0], [78.8, 218.0], [78.9, 218.0], [79.0, 219.0], [79.1, 219.0], [79.2, 219.0], [79.3, 220.0], [79.4, 220.0], [79.5, 220.0], [79.6, 221.0], [79.7, 221.0], [79.8, 222.0], [79.9, 222.0], [80.0, 222.0], [80.1, 223.0], [80.2, 223.0], [80.3, 224.0], [80.4, 224.0], [80.5, 225.0], [80.6, 225.0], [80.7, 226.0], [80.8, 226.0], [80.9, 227.0], [81.0, 227.0], [81.1, 228.0], [81.2, 228.0], [81.3, 229.0], [81.4, 229.0], [81.5, 230.0], [81.6, 230.0], [81.7, 230.0], [81.8, 231.0], [81.9, 232.0], [82.0, 232.0], [82.1, 232.0], [82.2, 233.0], [82.3, 233.0], [82.4, 234.0], [82.5, 235.0], [82.6, 235.0], [82.7, 236.0], [82.8, 236.0], [82.9, 236.0], [83.0, 237.0], [83.1, 238.0], [83.2, 238.0], [83.3, 239.0], [83.4, 239.0], [83.5, 240.0], [83.6, 241.0], [83.7, 241.0], [83.8, 242.0], [83.9, 243.0], [84.0, 243.0], [84.1, 244.0], [84.2, 244.0], [84.3, 245.0], [84.4, 246.0], [84.5, 246.0], [84.6, 247.0], [84.7, 247.0], [84.8, 248.0], [84.9, 248.0], [85.0, 248.0], [85.1, 249.0], [85.2, 250.0], [85.3, 250.0], [85.4, 251.0], [85.5, 252.0], [85.6, 252.0], [85.7, 253.0], [85.8, 254.0], [85.9, 254.0], [86.0, 255.0], [86.1, 255.0], [86.2, 256.0], [86.3, 257.0], [86.4, 257.0], [86.5, 258.0], [86.6, 259.0], [86.7, 260.0], [86.8, 260.0], [86.9, 261.0], [87.0, 262.0], [87.1, 263.0], [87.2, 264.0], [87.3, 264.0], [87.4, 265.0], [87.5, 266.0], [87.6, 266.0], [87.7, 267.0], [87.8, 267.0], [87.9, 268.0], [88.0, 268.0], [88.1, 269.0], [88.2, 270.0], [88.3, 271.0], [88.4, 272.0], [88.5, 273.0], [88.6, 274.0], [88.7, 274.0], [88.8, 275.0], [88.9, 276.0], [89.0, 277.0], [89.1, 278.0], [89.2, 278.0], [89.3, 280.0], [89.4, 281.0], [89.5, 281.0], [89.6, 282.0], [89.7, 283.0], [89.8, 284.0], [89.9, 285.0], [90.0, 285.0], [90.1, 286.0], [90.2, 287.0], [90.3, 288.0], [90.4, 288.0], [90.5, 289.0], [90.6, 290.0], [90.7, 291.0], [90.8, 292.0], [90.9, 293.0], [91.0, 294.0], [91.1, 295.0], [91.2, 296.0], [91.3, 297.0], [91.4, 298.0], [91.5, 300.0], [91.6, 300.0], [91.7, 301.0], [91.8, 302.0], [91.9, 303.0], [92.0, 304.0], [92.1, 305.0], [92.2, 307.0], [92.3, 307.0], [92.4, 309.0], [92.5, 309.0], [92.6, 310.0], [92.7, 311.0], [92.8, 313.0], [92.9, 314.0], [93.0, 315.0], [93.1, 316.0], [93.2, 317.0], [93.3, 319.0], [93.4, 321.0], [93.5, 322.0], [93.6, 323.0], [93.7, 324.0], [93.8, 326.0], [93.9, 327.0], [94.0, 328.0], [94.1, 330.0], [94.2, 331.0], [94.3, 333.0], [94.4, 335.0], [94.5, 337.0], [94.6, 338.0], [94.7, 340.0], [94.8, 342.0], [94.9, 343.0], [95.0, 345.0], [95.1, 346.0], [95.2, 348.0], [95.3, 350.0], [95.4, 352.0], [95.5, 354.0], [95.6, 356.0], [95.7, 358.0], [95.8, 361.0], [95.9, 363.0], [96.0, 366.0], [96.1, 368.0], [96.2, 370.0], [96.3, 372.0], [96.4, 376.0], [96.5, 379.0], [96.6, 381.0], [96.7, 384.0], [96.8, 386.0], [96.9, 390.0], [97.0, 391.0], [97.1, 395.0], [97.2, 398.0], [97.3, 400.0], [97.4, 403.0], [97.5, 407.0], [97.6, 411.0], [97.7, 415.0], [97.8, 419.0], [97.9, 423.0], [98.0, 428.0], [98.1, 432.0], [98.2, 435.0], [98.3, 439.0], [98.4, 446.0], [98.5, 453.0], [98.6, 460.0], [98.7, 467.0], [98.8, 475.0], [98.9, 481.0], [99.0, 486.0], [99.1, 496.0], [99.2, 504.0], [99.3, 520.0], [99.4, 533.0], [99.5, 554.0], [99.6, 575.0], [99.7, 594.0], [99.8, 621.0], [99.9, 681.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 0.0, "maxY": 10033.0, "series": [{"data": [[0.0, 6254.0], [300.0, 1272.0], [600.0, 41.0], [700.0, 11.0], [100.0, 10033.0], [200.0, 3785.0], [400.0, 405.0], [800.0, 3.0], [900.0, 2.0], [500.0, 133.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 900.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 188.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 21751.0, "series": [{"data": [[0.0, 21751.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 188.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 77.8704844750511, "minX": 1.79069484E12, "maxY": 99.63804713804711, "series": [{"data": [[1.7906949E12, 99.63804713804711], [1.79069484E12, 77.8704844750511]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906949E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 26.33333333333333, "minX": 1.0, "maxY": 323.0, "series": [{"data": [[3.0, 323.0], [5.0, 43.0625], [6.0, 32.28], [7.0, 42.78787878787879], [8.0, 38.040000000000006], [9.0, 39.800000000000004], [10.0, 26.33333333333333], [11.0, 28.325000000000006], [12.0, 31.55999999999999], [13.0, 51.073170731707314], [14.0, 46.44444444444445], [15.0, 40.175], [16.0, 50.257142857142846], [17.0, 51.137931034482754], [18.0, 71.17857142857142], [19.0, 53.81395348837209], [20.0, 45.4642857142857], [21.0, 59.84090909090909], [22.0, 58.02777777777777], [23.0, 69.0], [24.0, 50.70454545454545], [25.0, 53.62499999999999], [26.0, 45.966101694915274], [27.0, 66.05882352941177], [28.0, 78.75555555555555], [29.0, 64.22000000000003], [30.0, 68.47368421052632], [31.0, 109.88000000000001], [32.0, 69.24561403508773], [33.0, 57.04081632653061], [34.0, 58.35849056603774], [35.0, 64.58064516129033], [36.0, 85.06666666666666], [37.0, 60.16901408450703], [38.0, 55.499999999999986], [39.0, 63.621212121212096], [40.0, 64.86666666666665], [41.0, 82.51063829787233], [42.0, 87.98181818181818], [43.0, 97.40540540540542], [44.0, 86.05128205128206], [45.0, 137.7948717948718], [46.0, 130.75], [47.0, 159.2195121951219], [48.0, 130.7727272727273], [49.0, 158.58064516129036], [50.0, 160.88636363636365], [51.0, 158.4090909090909], [52.0, 135.86666666666667], [53.0, 162.15384615384613], [54.0, 144.85937500000003], [55.0, 114.0263157894737], [56.0, 113.79104477611945], [57.0, 118.43749999999999], [58.0, 139.89999999999995], [59.0, 89.56410256410255], [60.0, 114.51111111111109], [61.0, 97.231884057971], [62.0, 107.78947368421052], [63.0, 170.00000000000006], [64.0, 128.39999999999995], [65.0, 110.4], [66.0, 149.01785714285714], [67.0, 108.75], [68.0, 250.28124999999997], [69.0, 200.0], [70.0, 118.82758620689656], [71.0, 163.86666666666667], [72.0, 142.578125], [73.0, 210.31578947368416], [74.0, 231.11111111111111], [75.0, 219.05263157894737], [76.0, 204.1851851851852], [77.0, 209.41666666666666], [78.0, 145.4242424242424], [79.0, 127.29999999999997], [80.0, 140.03174603174605], [81.0, 130.19696969696972], [82.0, 122.10958904109589], [83.0, 107.94230769230771], [84.0, 133.1764705882353], [85.0, 134.85416666666663], [86.0, 221.375], [87.0, 182.33962264150952], [88.0, 165.36842105263153], [89.0, 173.4883720930233], [90.0, 186.54054054054058], [91.0, 122.55294117647057], [92.0, 118.38636363636364], [93.0, 163.05797101449278], [94.0, 159.30769230769232], [95.0, 129.7441860465117], [96.0, 204.54411764705887], [97.0, 206.35294117647055], [98.0, 262.54166666666674], [99.0, 203.04225352112667], [100.0, 169.48317212512015], [1.0, 174.0]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[91.42572587629355, 159.43060303568845]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 64008.8, "minX": 1.79069484E12, "maxY": 135416.25, "series": [{"data": [[1.7906949E12, 135416.25], [1.79069484E12, 82067.2]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.7906949E12, 105652.8], [1.79069484E12, 64008.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906949E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 159.00146391450753, "minX": 1.79069484E12, "maxY": 160.13893922918948, "series": [{"data": [[1.7906949E12, 159.00146391450753], [1.79069484E12, 160.13893922918948]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906949E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 156.7755819060182, "minX": 1.79069484E12, "maxY": 157.20200555756898, "series": [{"data": [[1.7906949E12, 156.7755819060182], [1.79069484E12, 157.20200555756898]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906949E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.018811301419997078, "minX": 1.79069484E12, "maxY": 0.0769602512987798, "series": [{"data": [[1.7906949E12, 0.018811301419997078], [1.79069484E12, 0.0769602512987798]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906949E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 12.0, "minX": 1.79069484E12, "maxY": 939.0, "series": [{"data": [[1.7906949E12, 871.0], [1.79069484E12, 939.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.7906949E12, 271.0], [1.79069484E12, 306.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.7906949E12, 474.0], [1.79069484E12, 506.8799999999974]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.7906949E12, 327.0], [1.79069484E12, 373.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.7906949E12, 12.0], [1.79069484E12, 12.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.7906949E12, 139.0], [1.79069484E12, 135.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906949E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 29.0, "minX": 264.0, "maxY": 333.0, "series": [{"data": [[542.0, 129.5], [536.0, 148.0], [523.0, 160.0], [541.0, 186.0], [514.0, 166.5], [559.0, 168.0], [575.0, 152.0], [580.0, 162.0], [604.0, 142.0], [594.0, 163.5], [577.0, 159.0], [605.0, 133.0], [626.0, 153.5], [624.0, 118.0], [664.0, 127.0], [656.0, 131.5], [644.0, 146.0], [673.0, 131.0], [684.0, 126.0], [713.0, 123.0], [704.0, 130.0], [720.0, 137.5], [714.0, 122.0], [751.0, 112.0], [742.0, 128.0], [858.0, 114.5], [264.0, 333.0], [285.0, 29.0], [281.0, 330.0], [365.0, 50.0], [359.0, 137.0], [353.0, 274.0], [386.0, 156.5], [390.0, 201.0], [439.0, 254.0], [443.0, 178.0], [464.0, 60.0], [498.0, 67.0], [499.0, 106.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 858.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 28.0, "minX": 264.0, "maxY": 325.0, "series": [{"data": [[542.0, 125.5], [536.0, 141.0], [523.0, 157.0], [541.0, 182.0], [514.0, 165.0], [559.0, 163.0], [575.0, 149.0], [580.0, 160.0], [604.0, 141.0], [594.0, 161.0], [577.0, 155.0], [605.0, 132.0], [626.0, 151.5], [624.0, 117.0], [664.0, 125.5], [656.0, 129.0], [644.0, 145.5], [673.0, 128.0], [684.0, 125.0], [713.0, 121.0], [704.0, 128.5], [720.0, 135.0], [714.0, 119.0], [751.0, 110.0], [742.0, 127.0], [858.0, 113.0], [264.0, 325.0], [285.0, 28.0], [281.0, 320.0], [365.0, 49.0], [359.0, 134.0], [353.0, 274.0], [386.0, 152.0], [390.0, 198.0], [439.0, 249.0], [443.0, 176.0], [464.0, 59.0], [498.0, 65.0], [499.0, 104.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 858.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 139.58333333333334, "minX": 1.79069484E12, "maxY": 226.06666666666666, "series": [{"data": [[1.7906949E12, 226.06666666666666], [1.79069484E12, 139.58333333333334]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906949E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 137.95, "minX": 1.79069484E12, "maxY": 227.7, "series": [{"data": [[1.7906949E12, 227.7], [1.79069484E12, 137.95]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7906949E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 137.95, "minX": 1.79069484E12, "maxY": 227.7, "series": [{"data": [[1.7906949E12, 227.7], [1.79069484E12, 137.95]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906949E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 137.95, "minX": 1.79069484E12, "maxY": 227.7, "series": [{"data": [[1.7906949E12, 227.7], [1.79069484E12, 137.95]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7906949E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

