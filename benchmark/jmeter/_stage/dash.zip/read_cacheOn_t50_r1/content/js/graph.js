/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 8.0, "minX": 0.0, "maxY": 780.0, "series": [{"data": [[0.0, 8.0], [0.1, 10.0], [0.2, 10.0], [0.3, 11.0], [0.4, 11.0], [0.5, 12.0], [0.6, 13.0], [0.7, 14.0], [0.8, 15.0], [0.9, 16.0], [1.0, 17.0], [1.1, 17.0], [1.2, 18.0], [1.3, 18.0], [1.4, 19.0], [1.5, 19.0], [1.6, 20.0], [1.7, 20.0], [1.8, 21.0], [1.9, 21.0], [2.0, 22.0], [2.1, 22.0], [2.2, 23.0], [2.3, 23.0], [2.4, 24.0], [2.5, 24.0], [2.6, 24.0], [2.7, 24.0], [2.8, 25.0], [2.9, 25.0], [3.0, 25.0], [3.1, 26.0], [3.2, 26.0], [3.3, 26.0], [3.4, 27.0], [3.5, 27.0], [3.6, 27.0], [3.7, 28.0], [3.8, 28.0], [3.9, 28.0], [4.0, 28.0], [4.1, 29.0], [4.2, 29.0], [4.3, 29.0], [4.4, 30.0], [4.5, 30.0], [4.6, 30.0], [4.7, 30.0], [4.8, 31.0], [4.9, 31.0], [5.0, 31.0], [5.1, 31.0], [5.2, 32.0], [5.3, 32.0], [5.4, 32.0], [5.5, 32.0], [5.6, 32.0], [5.7, 33.0], [5.8, 33.0], [5.9, 33.0], [6.0, 33.0], [6.1, 33.0], [6.2, 34.0], [6.3, 34.0], [6.4, 34.0], [6.5, 34.0], [6.6, 34.0], [6.7, 34.0], [6.8, 35.0], [6.9, 35.0], [7.0, 35.0], [7.1, 35.0], [7.2, 35.0], [7.3, 35.0], [7.4, 36.0], [7.5, 36.0], [7.6, 36.0], [7.7, 36.0], [7.8, 36.0], [7.9, 36.0], [8.0, 37.0], [8.1, 37.0], [8.2, 37.0], [8.3, 37.0], [8.4, 37.0], [8.5, 37.0], [8.6, 37.0], [8.7, 38.0], [8.8, 38.0], [8.9, 38.0], [9.0, 38.0], [9.1, 38.0], [9.2, 38.0], [9.3, 38.0], [9.4, 39.0], [9.5, 39.0], [9.6, 39.0], [9.7, 39.0], [9.8, 39.0], [9.9, 39.0], [10.0, 39.0], [10.1, 39.0], [10.2, 40.0], [10.3, 40.0], [10.4, 40.0], [10.5, 40.0], [10.6, 40.0], [10.7, 40.0], [10.8, 40.0], [10.9, 41.0], [11.0, 41.0], [11.1, 41.0], [11.2, 41.0], [11.3, 41.0], [11.4, 41.0], [11.5, 41.0], [11.6, 41.0], [11.7, 42.0], [11.8, 42.0], [11.9, 42.0], [12.0, 42.0], [12.1, 42.0], [12.2, 42.0], [12.3, 42.0], [12.4, 42.0], [12.5, 43.0], [12.6, 43.0], [12.7, 43.0], [12.8, 43.0], [12.9, 43.0], [13.0, 43.0], [13.1, 43.0], [13.2, 43.0], [13.3, 44.0], [13.4, 44.0], [13.5, 44.0], [13.6, 44.0], [13.7, 44.0], [13.8, 44.0], [13.9, 44.0], [14.0, 44.0], [14.1, 44.0], [14.2, 45.0], [14.3, 45.0], [14.4, 45.0], [14.5, 45.0], [14.6, 45.0], [14.7, 45.0], [14.8, 45.0], [14.9, 45.0], [15.0, 45.0], [15.1, 46.0], [15.2, 46.0], [15.3, 46.0], [15.4, 46.0], [15.5, 46.0], [15.6, 46.0], [15.7, 46.0], [15.8, 46.0], [15.9, 46.0], [16.0, 47.0], [16.1, 47.0], [16.2, 47.0], [16.3, 47.0], [16.4, 47.0], [16.5, 47.0], [16.6, 47.0], [16.7, 47.0], [16.8, 47.0], [16.9, 47.0], [17.0, 48.0], [17.1, 48.0], [17.2, 48.0], [17.3, 48.0], [17.4, 48.0], [17.5, 48.0], [17.6, 48.0], [17.7, 48.0], [17.8, 48.0], [17.9, 48.0], [18.0, 49.0], [18.1, 49.0], [18.2, 49.0], [18.3, 49.0], [18.4, 49.0], [18.5, 49.0], [18.6, 49.0], [18.7, 49.0], [18.8, 49.0], [18.9, 49.0], [19.0, 50.0], [19.1, 50.0], [19.2, 50.0], [19.3, 50.0], [19.4, 50.0], [19.5, 50.0], [19.6, 50.0], [19.7, 50.0], [19.8, 50.0], [19.9, 50.0], [20.0, 50.0], [20.1, 51.0], [20.2, 51.0], [20.3, 51.0], [20.4, 51.0], [20.5, 51.0], [20.6, 51.0], [20.7, 51.0], [20.8, 51.0], [20.9, 51.0], [21.0, 52.0], [21.1, 52.0], [21.2, 52.0], [21.3, 52.0], [21.4, 52.0], [21.5, 52.0], [21.6, 52.0], [21.7, 52.0], [21.8, 52.0], [21.9, 53.0], [22.0, 53.0], [22.1, 53.0], [22.2, 53.0], [22.3, 53.0], [22.4, 53.0], [22.5, 53.0], [22.6, 53.0], [22.7, 53.0], [22.8, 53.0], [22.9, 53.0], [23.0, 54.0], [23.1, 54.0], [23.2, 54.0], [23.3, 54.0], [23.4, 54.0], [23.5, 54.0], [23.6, 54.0], [23.7, 54.0], [23.8, 54.0], [23.9, 54.0], [24.0, 54.0], [24.1, 55.0], [24.2, 55.0], [24.3, 55.0], [24.4, 55.0], [24.5, 55.0], [24.6, 55.0], [24.7, 55.0], [24.8, 55.0], [24.9, 55.0], [25.0, 55.0], [25.1, 55.0], [25.2, 55.0], [25.3, 55.0], [25.4, 56.0], [25.5, 56.0], [25.6, 56.0], [25.7, 56.0], [25.8, 56.0], [25.9, 56.0], [26.0, 56.0], [26.1, 56.0], [26.2, 56.0], [26.3, 56.0], [26.4, 56.0], [26.5, 57.0], [26.6, 57.0], [26.7, 57.0], [26.8, 57.0], [26.9, 57.0], [27.0, 57.0], [27.1, 57.0], [27.2, 57.0], [27.3, 57.0], [27.4, 57.0], [27.5, 57.0], [27.6, 57.0], [27.7, 58.0], [27.8, 58.0], [27.9, 58.0], [28.0, 58.0], [28.1, 58.0], [28.2, 58.0], [28.3, 58.0], [28.4, 58.0], [28.5, 58.0], [28.6, 58.0], [28.7, 58.0], [28.8, 58.0], [28.9, 59.0], [29.0, 59.0], [29.1, 59.0], [29.2, 59.0], [29.3, 59.0], [29.4, 59.0], [29.5, 59.0], [29.6, 59.0], [29.7, 59.0], [29.8, 59.0], [29.9, 59.0], [30.0, 59.0], [30.1, 60.0], [30.2, 60.0], [30.3, 60.0], [30.4, 60.0], [30.5, 60.0], [30.6, 60.0], [30.7, 60.0], [30.8, 60.0], [30.9, 60.0], [31.0, 60.0], [31.1, 60.0], [31.2, 61.0], [31.3, 61.0], [31.4, 61.0], [31.5, 61.0], [31.6, 61.0], [31.7, 61.0], [31.8, 61.0], [31.9, 61.0], [32.0, 61.0], [32.1, 61.0], [32.2, 61.0], [32.3, 61.0], [32.4, 62.0], [32.5, 62.0], [32.6, 62.0], [32.7, 62.0], [32.8, 62.0], [32.9, 62.0], [33.0, 62.0], [33.1, 62.0], [33.2, 62.0], [33.3, 62.0], [33.4, 63.0], [33.5, 63.0], [33.6, 63.0], [33.7, 63.0], [33.8, 63.0], [33.9, 63.0], [34.0, 63.0], [34.1, 63.0], [34.2, 63.0], [34.3, 63.0], [34.4, 63.0], [34.5, 63.0], [34.6, 63.0], [34.7, 64.0], [34.8, 64.0], [34.9, 64.0], [35.0, 64.0], [35.1, 64.0], [35.2, 64.0], [35.3, 64.0], [35.4, 64.0], [35.5, 64.0], [35.6, 64.0], [35.7, 64.0], [35.8, 65.0], [35.9, 65.0], [36.0, 65.0], [36.1, 65.0], [36.2, 65.0], [36.3, 65.0], [36.4, 65.0], [36.5, 65.0], [36.6, 65.0], [36.7, 65.0], [36.8, 65.0], [36.9, 66.0], [37.0, 66.0], [37.1, 66.0], [37.2, 66.0], [37.3, 66.0], [37.4, 66.0], [37.5, 66.0], [37.6, 66.0], [37.7, 66.0], [37.8, 66.0], [37.9, 66.0], [38.0, 67.0], [38.1, 67.0], [38.2, 67.0], [38.3, 67.0], [38.4, 67.0], [38.5, 67.0], [38.6, 67.0], [38.7, 67.0], [38.8, 67.0], [38.9, 67.0], [39.0, 67.0], [39.1, 68.0], [39.2, 68.0], [39.3, 68.0], [39.4, 68.0], [39.5, 68.0], [39.6, 68.0], [39.7, 68.0], [39.8, 68.0], [39.9, 68.0], [40.0, 68.0], [40.1, 68.0], [40.2, 69.0], [40.3, 69.0], [40.4, 69.0], [40.5, 69.0], [40.6, 69.0], [40.7, 69.0], [40.8, 69.0], [40.9, 69.0], [41.0, 69.0], [41.1, 69.0], [41.2, 69.0], [41.3, 69.0], [41.4, 70.0], [41.5, 70.0], [41.6, 70.0], [41.7, 70.0], [41.8, 70.0], [41.9, 70.0], [42.0, 70.0], [42.1, 70.0], [42.2, 70.0], [42.3, 70.0], [42.4, 70.0], [42.5, 70.0], [42.6, 71.0], [42.7, 71.0], [42.8, 71.0], [42.9, 71.0], [43.0, 71.0], [43.1, 71.0], [43.2, 71.0], [43.3, 71.0], [43.4, 71.0], [43.5, 71.0], [43.6, 72.0], [43.7, 72.0], [43.8, 72.0], [43.9, 72.0], [44.0, 72.0], [44.1, 72.0], [44.2, 72.0], [44.3, 72.0], [44.4, 72.0], [44.5, 72.0], [44.6, 72.0], [44.7, 72.0], [44.8, 73.0], [44.9, 73.0], [45.0, 73.0], [45.1, 73.0], [45.2, 73.0], [45.3, 73.0], [45.4, 73.0], [45.5, 73.0], [45.6, 73.0], [45.7, 73.0], [45.8, 73.0], [45.9, 74.0], [46.0, 74.0], [46.1, 74.0], [46.2, 74.0], [46.3, 74.0], [46.4, 74.0], [46.5, 74.0], [46.6, 74.0], [46.7, 74.0], [46.8, 74.0], [46.9, 74.0], [47.0, 75.0], [47.1, 75.0], [47.2, 75.0], [47.3, 75.0], [47.4, 75.0], [47.5, 75.0], [47.6, 75.0], [47.7, 75.0], [47.8, 75.0], [47.9, 75.0], [48.0, 75.0], [48.1, 75.0], [48.2, 76.0], [48.3, 76.0], [48.4, 76.0], [48.5, 76.0], [48.6, 76.0], [48.7, 76.0], [48.8, 76.0], [48.9, 76.0], [49.0, 76.0], [49.1, 76.0], [49.2, 77.0], [49.3, 77.0], [49.4, 77.0], [49.5, 77.0], [49.6, 77.0], [49.7, 77.0], [49.8, 77.0], [49.9, 77.0], [50.0, 77.0], [50.1, 77.0], [50.2, 77.0], [50.3, 78.0], [50.4, 78.0], [50.5, 78.0], [50.6, 78.0], [50.7, 78.0], [50.8, 78.0], [50.9, 78.0], [51.0, 78.0], [51.1, 79.0], [51.2, 79.0], [51.3, 79.0], [51.4, 79.0], [51.5, 79.0], [51.6, 79.0], [51.7, 79.0], [51.8, 79.0], [51.9, 79.0], [52.0, 79.0], [52.1, 80.0], [52.2, 80.0], [52.3, 80.0], [52.4, 80.0], [52.5, 80.0], [52.6, 80.0], [52.7, 80.0], [52.8, 80.0], [52.9, 80.0], [53.0, 80.0], [53.1, 81.0], [53.2, 81.0], [53.3, 81.0], [53.4, 81.0], [53.5, 81.0], [53.6, 81.0], [53.7, 81.0], [53.8, 81.0], [53.9, 81.0], [54.0, 82.0], [54.1, 82.0], [54.2, 82.0], [54.3, 82.0], [54.4, 82.0], [54.5, 82.0], [54.6, 82.0], [54.7, 82.0], [54.8, 82.0], [54.9, 82.0], [55.0, 83.0], [55.1, 83.0], [55.2, 83.0], [55.3, 83.0], [55.4, 83.0], [55.5, 83.0], [55.6, 83.0], [55.7, 83.0], [55.8, 84.0], [55.9, 84.0], [56.0, 84.0], [56.1, 84.0], [56.2, 84.0], [56.3, 84.0], [56.4, 84.0], [56.5, 84.0], [56.6, 84.0], [56.7, 84.0], [56.8, 85.0], [56.9, 85.0], [57.0, 85.0], [57.1, 85.0], [57.2, 85.0], [57.3, 85.0], [57.4, 85.0], [57.5, 85.0], [57.6, 85.0], [57.7, 86.0], [57.8, 86.0], [57.9, 86.0], [58.0, 86.0], [58.1, 86.0], [58.2, 86.0], [58.3, 86.0], [58.4, 86.0], [58.5, 86.0], [58.6, 87.0], [58.7, 87.0], [58.8, 87.0], [58.9, 87.0], [59.0, 87.0], [59.1, 87.0], [59.2, 87.0], [59.3, 87.0], [59.4, 87.0], [59.5, 87.0], [59.6, 88.0], [59.7, 88.0], [59.8, 88.0], [59.9, 88.0], [60.0, 88.0], [60.1, 88.0], [60.2, 88.0], [60.3, 88.0], [60.4, 88.0], [60.5, 89.0], [60.6, 89.0], [60.7, 89.0], [60.8, 89.0], [60.9, 89.0], [61.0, 89.0], [61.1, 89.0], [61.2, 90.0], [61.3, 90.0], [61.4, 90.0], [61.5, 90.0], [61.6, 90.0], [61.7, 90.0], [61.8, 90.0], [61.9, 90.0], [62.0, 90.0], [62.1, 91.0], [62.2, 91.0], [62.3, 91.0], [62.4, 91.0], [62.5, 91.0], [62.6, 91.0], [62.7, 91.0], [62.8, 92.0], [62.9, 92.0], [63.0, 92.0], [63.1, 92.0], [63.2, 92.0], [63.3, 92.0], [63.4, 92.0], [63.5, 92.0], [63.6, 93.0], [63.7, 93.0], [63.8, 93.0], [63.9, 93.0], [64.0, 93.0], [64.1, 93.0], [64.2, 93.0], [64.3, 93.0], [64.4, 94.0], [64.5, 94.0], [64.6, 94.0], [64.7, 94.0], [64.8, 94.0], [64.9, 94.0], [65.0, 94.0], [65.1, 94.0], [65.2, 95.0], [65.3, 95.0], [65.4, 95.0], [65.5, 95.0], [65.6, 95.0], [65.7, 95.0], [65.8, 95.0], [65.9, 95.0], [66.0, 96.0], [66.1, 96.0], [66.2, 96.0], [66.3, 96.0], [66.4, 96.0], [66.5, 96.0], [66.6, 97.0], [66.7, 97.0], [66.8, 97.0], [66.9, 97.0], [67.0, 97.0], [67.1, 97.0], [67.2, 97.0], [67.3, 98.0], [67.4, 98.0], [67.5, 98.0], [67.6, 98.0], [67.7, 98.0], [67.8, 98.0], [67.9, 98.0], [68.0, 99.0], [68.1, 99.0], [68.2, 99.0], [68.3, 99.0], [68.4, 99.0], [68.5, 99.0], [68.6, 99.0], [68.7, 100.0], [68.8, 100.0], [68.9, 100.0], [69.0, 100.0], [69.1, 100.0], [69.2, 100.0], [69.3, 100.0], [69.4, 101.0], [69.5, 101.0], [69.6, 101.0], [69.7, 101.0], [69.8, 101.0], [69.9, 102.0], [70.0, 102.0], [70.1, 102.0], [70.2, 102.0], [70.3, 102.0], [70.4, 102.0], [70.5, 103.0], [70.6, 103.0], [70.7, 103.0], [70.8, 103.0], [70.9, 103.0], [71.0, 103.0], [71.1, 104.0], [71.2, 104.0], [71.3, 104.0], [71.4, 104.0], [71.5, 104.0], [71.6, 104.0], [71.7, 105.0], [71.8, 105.0], [71.9, 105.0], [72.0, 105.0], [72.1, 105.0], [72.2, 105.0], [72.3, 106.0], [72.4, 106.0], [72.5, 106.0], [72.6, 106.0], [72.7, 106.0], [72.8, 106.0], [72.9, 107.0], [73.0, 107.0], [73.1, 107.0], [73.2, 107.0], [73.3, 107.0], [73.4, 107.0], [73.5, 108.0], [73.6, 108.0], [73.7, 108.0], [73.8, 108.0], [73.9, 108.0], [74.0, 108.0], [74.1, 109.0], [74.2, 109.0], [74.3, 109.0], [74.4, 109.0], [74.5, 109.0], [74.6, 110.0], [74.7, 110.0], [74.8, 110.0], [74.9, 110.0], [75.0, 110.0], [75.1, 111.0], [75.2, 111.0], [75.3, 111.0], [75.4, 111.0], [75.5, 111.0], [75.6, 111.0], [75.7, 112.0], [75.8, 112.0], [75.9, 112.0], [76.0, 112.0], [76.1, 112.0], [76.2, 113.0], [76.3, 113.0], [76.4, 113.0], [76.5, 113.0], [76.6, 113.0], [76.7, 114.0], [76.8, 114.0], [76.9, 114.0], [77.0, 114.0], [77.1, 114.0], [77.2, 114.0], [77.3, 115.0], [77.4, 115.0], [77.5, 115.0], [77.6, 115.0], [77.7, 116.0], [77.8, 116.0], [77.9, 116.0], [78.0, 116.0], [78.1, 116.0], [78.2, 116.0], [78.3, 117.0], [78.4, 117.0], [78.5, 117.0], [78.6, 117.0], [78.7, 118.0], [78.8, 118.0], [78.9, 118.0], [79.0, 118.0], [79.1, 118.0], [79.2, 119.0], [79.3, 119.0], [79.4, 119.0], [79.5, 119.0], [79.6, 120.0], [79.7, 120.0], [79.8, 120.0], [79.9, 120.0], [80.0, 121.0], [80.1, 121.0], [80.2, 121.0], [80.3, 121.0], [80.4, 122.0], [80.5, 122.0], [80.6, 122.0], [80.7, 123.0], [80.8, 123.0], [80.9, 123.0], [81.0, 123.0], [81.1, 123.0], [81.2, 124.0], [81.3, 124.0], [81.4, 124.0], [81.5, 124.0], [81.6, 125.0], [81.7, 125.0], [81.8, 125.0], [81.9, 125.0], [82.0, 126.0], [82.1, 126.0], [82.2, 126.0], [82.3, 126.0], [82.4, 127.0], [82.5, 127.0], [82.6, 127.0], [82.7, 128.0], [82.8, 128.0], [82.9, 128.0], [83.0, 128.0], [83.1, 129.0], [83.2, 129.0], [83.3, 129.0], [83.4, 130.0], [83.5, 130.0], [83.6, 130.0], [83.7, 130.0], [83.8, 130.0], [83.9, 131.0], [84.0, 131.0], [84.1, 131.0], [84.2, 132.0], [84.3, 132.0], [84.4, 132.0], [84.5, 133.0], [84.6, 133.0], [84.7, 133.0], [84.8, 134.0], [84.9, 134.0], [85.0, 134.0], [85.1, 134.0], [85.2, 135.0], [85.3, 135.0], [85.4, 135.0], [85.5, 135.0], [85.6, 136.0], [85.7, 136.0], [85.8, 136.0], [85.9, 137.0], [86.0, 137.0], [86.1, 138.0], [86.2, 138.0], [86.3, 138.0], [86.4, 139.0], [86.5, 139.0], [86.6, 140.0], [86.7, 140.0], [86.8, 140.0], [86.9, 141.0], [87.0, 141.0], [87.1, 141.0], [87.2, 141.0], [87.3, 142.0], [87.4, 142.0], [87.5, 143.0], [87.6, 143.0], [87.7, 143.0], [87.8, 144.0], [87.9, 144.0], [88.0, 145.0], [88.1, 145.0], [88.2, 145.0], [88.3, 146.0], [88.4, 146.0], [88.5, 147.0], [88.6, 147.0], [88.7, 147.0], [88.8, 148.0], [88.9, 148.0], [89.0, 149.0], [89.1, 149.0], [89.2, 150.0], [89.3, 150.0], [89.4, 151.0], [89.5, 151.0], [89.6, 152.0], [89.7, 152.0], [89.8, 153.0], [89.9, 153.0], [90.0, 154.0], [90.1, 154.0], [90.2, 154.0], [90.3, 155.0], [90.4, 155.0], [90.5, 156.0], [90.6, 156.0], [90.7, 157.0], [90.8, 157.0], [90.9, 158.0], [91.0, 158.0], [91.1, 159.0], [91.2, 160.0], [91.3, 160.0], [91.4, 161.0], [91.5, 161.0], [91.6, 162.0], [91.7, 162.0], [91.8, 163.0], [91.9, 164.0], [92.0, 164.0], [92.1, 165.0], [92.2, 165.0], [92.3, 166.0], [92.4, 166.0], [92.5, 167.0], [92.6, 168.0], [92.7, 169.0], [92.8, 169.0], [92.9, 170.0], [93.0, 171.0], [93.1, 171.0], [93.2, 172.0], [93.3, 172.0], [93.4, 173.0], [93.5, 173.0], [93.6, 174.0], [93.7, 175.0], [93.8, 176.0], [93.9, 177.0], [94.0, 178.0], [94.1, 178.0], [94.2, 179.0], [94.3, 180.0], [94.4, 181.0], [94.5, 182.0], [94.6, 183.0], [94.7, 183.0], [94.8, 184.0], [94.9, 185.0], [95.0, 186.0], [95.1, 187.0], [95.2, 189.0], [95.3, 190.0], [95.4, 191.0], [95.5, 191.0], [95.6, 192.0], [95.7, 193.0], [95.8, 194.0], [95.9, 196.0], [96.0, 198.0], [96.1, 199.0], [96.2, 200.0], [96.3, 202.0], [96.4, 203.0], [96.5, 204.0], [96.6, 206.0], [96.7, 208.0], [96.8, 209.0], [96.9, 211.0], [97.0, 212.0], [97.1, 214.0], [97.2, 216.0], [97.3, 217.0], [97.4, 219.0], [97.5, 220.0], [97.6, 223.0], [97.7, 225.0], [97.8, 227.0], [97.9, 229.0], [98.0, 232.0], [98.1, 235.0], [98.2, 237.0], [98.3, 240.0], [98.4, 245.0], [98.5, 248.0], [98.6, 251.0], [98.7, 255.0], [98.8, 259.0], [98.9, 263.0], [99.0, 269.0], [99.1, 274.0], [99.2, 281.0], [99.3, 294.0], [99.4, 305.0], [99.5, 323.0], [99.6, 341.0], [99.7, 378.0], [99.8, 434.0], [99.9, 531.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 7.0, "minX": 0.0, "maxY": 15315.0, "series": [{"data": [[0.0, 15315.0], [300.0, 89.0], [600.0, 10.0], [700.0, 9.0], [100.0, 6147.0], [200.0, 712.0], [400.0, 28.0], [500.0, 7.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 700.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 26.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 22291.0, "series": [{"data": [[0.0, 22291.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 26.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 36.620338983050836, "minX": 1.79069448E12, "maxY": 49.9015219337511, "series": [{"data": [[1.79069448E12, 36.620338983050836], [1.79069454E12, 49.9015219337511]], "isOverall": false, "label": "readers", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069454E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 11.714285714285714, "minX": 1.0, "maxY": 214.70689655172413, "series": [{"data": [[2.0, 11.714285714285714], [3.0, 13.089887640449444], [4.0, 18.83544303797468], [5.0, 25.740740740740744], [6.0, 24.55913978494623], [7.0, 26.520000000000007], [8.0, 27.593220338983034], [9.0, 30.81081081081081], [10.0, 34.39495798319329], [11.0, 32.6124031007752], [12.0, 36.30769230769229], [13.0, 59.1264367816092], [14.0, 61.82022471910108], [15.0, 56.32710280373832], [16.0, 86.58620689655172], [17.0, 80.39175257731961], [18.0, 83.97777777777776], [19.0, 82.40229885057471], [20.0, 86.28125], [21.0, 72.52777777777776], [22.0, 62.85314685314688], [23.0, 49.41621621621621], [24.0, 89.83999999999997], [25.0, 71.8231292517007], [26.0, 62.56363636363638], [27.0, 70.75496688741723], [28.0, 69.40506329113923], [29.0, 75.05769230769228], [30.0, 74.47826086956526], [31.0, 80.42105263157896], [32.0, 90.78048780487808], [33.0, 60.383333333333326], [34.0, 132.5612903225806], [35.0, 103.45652173913041], [36.0, 72.61734693877554], [37.0, 75.93157894736842], [38.0, 100.99337748344372], [39.0, 123.05511811023624], [40.0, 96.60465116279073], [41.0, 90.94252873563222], [42.0, 214.70689655172413], [43.0, 150.7042253521127], [44.0, 156.3085106382978], [45.0, 137.64788732394356], [46.0, 97.13402061855668], [47.0, 162.5833333333333], [48.0, 110.01807228915662], [49.0, 117.84177215189872], [50.0, 93.3620062850449], [1.0, 24.25]], "isOverall": false, "label": "GET product detail", "isController": false}, {"data": [[43.932517811533764, 89.62226105659357]], "isOverall": false, "label": "GET product detail-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 78234.0, "minX": 1.79069448E12, "maxY": 113759.05, "series": [{"data": [[1.79069448E12, 92869.8], [1.79069454E12, 113759.05]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79069448E12, 78234.0], [1.79069454E12, 95838.6]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069454E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 83.15821600065112, "minX": 1.79069448E12, "maxY": 97.5408773678963, "series": [{"data": [[1.79069448E12, 97.5408773678963], [1.79069454E12, 83.15821600065112]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069454E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 82.05452917717928, "minX": 1.79069448E12, "maxY": 96.1697906281154, "series": [{"data": [[1.79069448E12, 96.1697906281154], [1.79069454E12, 82.05452917717928]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069454E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79069448E12, "maxY": 0.01864406779661012, "series": [{"data": [[1.79069448E12, 0.01864406779661012], [1.79069454E12, 0.0]], "isOverall": false, "label": "GET product detail", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069454E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 8.0, "minX": 1.79069448E12, "maxY": 780.0, "series": [{"data": [[1.79069448E12, 780.0], [1.79069454E12, 428.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79069448E12, 170.0], [1.79069454E12, 136.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79069448E12, 313.6900000000005], [1.79069454E12, 240.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79069448E12, 207.0], [1.79069454E12, 166.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79069448E12, 8.0], [1.79069454E12, 11.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79069448E12, 85.0], [1.79069454E12, 73.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069454E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 11.5, "minX": 26.0, "maxY": 138.5, "series": [{"data": [[518.0, 88.0], [526.0, 87.0], [560.0, 76.0], [546.0, 80.0], [552.0, 87.0], [584.0, 75.5], [576.0, 82.0], [635.0, 72.0], [622.0, 74.0], [609.0, 75.0], [640.0, 73.5], [703.0, 65.0], [707.0, 65.0], [708.0, 61.0], [735.0, 63.0], [766.0, 59.5], [757.0, 60.0], [26.0, 11.5], [205.0, 12.0], [211.0, 62.0], [221.0, 22.0], [229.0, 75.0], [246.0, 47.5], [269.0, 27.0], [262.0, 76.5], [278.0, 138.5], [302.0, 32.0], [310.0, 68.5], [330.0, 90.0], [338.0, 135.5], [351.0, 115.0], [367.0, 54.0], [374.0, 61.0], [382.0, 70.0], [380.0, 76.5], [373.0, 94.0], [375.0, 83.0], [372.0, 111.0], [369.0, 123.0], [383.0, 119.0], [386.0, 111.0], [414.0, 113.5], [412.0, 116.0], [421.0, 89.5], [419.0, 112.0], [420.0, 111.0], [423.0, 108.0], [470.0, 88.0], [504.0, 74.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 766.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 11.0, "minX": 26.0, "maxY": 138.0, "series": [{"data": [[518.0, 87.0], [526.0, 86.0], [560.0, 74.0], [546.0, 79.0], [552.0, 86.5], [584.0, 75.0], [576.0, 81.0], [635.0, 71.0], [622.0, 73.0], [609.0, 73.0], [640.0, 72.0], [703.0, 64.0], [707.0, 64.0], [708.0, 60.0], [735.0, 62.0], [766.0, 58.5], [757.0, 59.0], [26.0, 11.0], [205.0, 12.0], [211.0, 61.0], [221.0, 22.0], [229.0, 73.0], [246.0, 47.0], [269.0, 27.0], [262.0, 74.0], [278.0, 138.0], [302.0, 31.0], [310.0, 67.0], [330.0, 87.5], [338.0, 134.0], [351.0, 112.0], [367.0, 52.0], [374.0, 60.0], [382.0, 69.0], [380.0, 75.5], [373.0, 93.0], [375.0, 83.0], [372.0, 107.5], [369.0, 121.0], [383.0, 118.0], [386.0, 108.5], [414.0, 113.0], [412.0, 114.0], [421.0, 88.5], [419.0, 111.0], [420.0, 111.0], [423.0, 107.0], [470.0, 86.5], [504.0, 72.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 766.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 168.0, "minX": 1.79069448E12, "maxY": 203.95, "series": [{"data": [[1.79069448E12, 168.0], [1.79069454E12, 203.95]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069454E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 167.16666666666666, "minX": 1.79069448E12, "maxY": 204.78333333333333, "series": [{"data": [[1.79069448E12, 167.16666666666666], [1.79069454E12, 204.78333333333333]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79069454E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 167.16666666666666, "minX": 1.79069448E12, "maxY": 204.78333333333333, "series": [{"data": [[1.79069448E12, 167.16666666666666], [1.79069454E12, 204.78333333333333]], "isOverall": false, "label": "GET product detail-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069454E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 167.16666666666666, "minX": 1.79069448E12, "maxY": 204.78333333333333, "series": [{"data": [[1.79069448E12, 167.16666666666666], [1.79069454E12, 204.78333333333333]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79069454E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 25200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

